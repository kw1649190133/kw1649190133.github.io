# Vision 1.4
# 添加MDB数据库检查功能。
# 添加MDB管线图绘制功能。  
# 主界面选项卡分组排列优化。
# 修复错误输入导致管径识别的错误，添加设计表读取后的自动分类。
# 保留对比表设计和施工两种井类型

# Vision 1.5
import tkinter as tk
from tkinter import ttk, filedialog, scrolledtext
import os
import threading
import sys
import subprocess
import datetime
# 添加项目根目录到系统路径
sys.path.append(os.path.dirname(os.path.abspath(__file__)))
from modules import *

# 功能实现函数
def db_to_output_table(buried_depth_path, coord_path, template_path, log_callback):
    """数据库转成果表功能"""
    log_callback(f"开始执行: 数据库转成果表")
    log_callback(f"埋深表路径: {buried_depth_path}")
    log_callback(f"坐标表路径: {coord_path}")
    log_callback(f"模板路径: {template_path}")
    
    # 功能模块导入
    try:
        database_to_cgb_v3.database_to_cgb(buried_depth_path,coord_path,template_path,output_path = None)
    except Exception as e:
        print(f"出现异常: {e}" + "请检查xls表sheet名称、csv表编码格式")
    output_file = buried_depth_path + '_成果表.xlsx'
    log_callback("处理完成! 结果已保存到: " + output_file)
    return True

def batch_output_to_db(output_dir, template_path, log_callback):
    """成果表批量转数据库功能"""
    log_callback(f"开始执行: 成果表批量转数据库")
    log_callback(f"成果表目录: {output_dir}")
    log_callback(f"模板路径: {template_path}")
    
    # 功能模块导入
    cgb_to_database.cgb_to_database(output_dir,template_path,search_keyword="成果表")

    # 处理过程
    files = [f for f in os.listdir(output_dir) if f.endswith('.xlsx')]
    total = len(files)
    
    for i, file in enumerate(files):
        time.sleep(0.3)
        log_callback(f"处理文件: {file} ({i+1}/{total})")
    log_callback(f"批量处理完成! 共处理 {total} 个文件")
    return True

def adjust_slope_ratio(input_path, log_callback):
    """坡比自动调整功能"""
    log_callback(f"开始执行: 坡比自动调整")
    log_callback(f"成果表路径: {input_path}")
    
    # 功能模块导入
    pobi_modification.pobi_modification(input_path,output_path = None,baimingdan_path = None)

    # 处理过程    
    output_path = input_path + '_result.xlsx'
    log_callback("坡比调整完成! 结果已保存到：" + output_path)
    return True

# 新增功能函数（需要您实现实际逻辑）
def read_design_data_inmain(design_table_path, log_callback):
    """读取设计数据功能 - 实际实现"""
    log_callback(f"开始读取设计数据: {design_table_path}")
    # 功能模块导入
    read_design_data.read_design_data(design_table_path,output_file =None)
    output_file = design_table_path + '_load.xlsx'
    log_callback("设计数据读取完成!  结果保存：" + output_file)

def read_construction_data_inmain(template_path, result_table_path, log_callback):
    """读取施工数据功能 - 实际实现"""
    log_callback(f"开始读取施工数据")
    log_callback(f"模板路径: {template_path}")
    log_callback(f"成果表路径: {result_table_path}")
    # 功能模块导入
    read_construction_data.read_construction_data(template_path,result_table_path,output_path =None)
    output_file = result_table_path + '_load.xlsx'
    log_callback("施工数据读取完成! 结果保存：" + output_file)

def generate_comparison_table_inmain(result_table_path, design_table_path, log_callback):
    """生成数据对照表功能 - 实际实现"""
    log_callback(f"开始生成数据对照表")
    log_callback(f"成果表路径: {result_table_path}")
    log_callback(f"设计表路径: {design_table_path}")
    # 功能模块导入
    generate_comparison_table.generate_comparison_table(result_table_path,design_table_path,output_path=None)
    output_file = result_table_path + '_processed.xlsx'
    log_callback("数据对照表生成完成! 结果保存：" + output_file)

def save_original_data_main(input_path,log_callback):
    """保存原始数据"""
    log_callback(f"保存成果表原始数据")
    log_callback(f"成果表路径: {input_path}")
    # 保存原始数据的函数
    save_original_data.save_original_data(input_path)
    log_callback("原始数据已保存到原文件")

def slope_pre_treatment_main(input_path,txt_path,log_callback):
    """坡比预处理"""
    log_callback(f"预先处理问题节点")
    log_callback(f"成果表路径: {input_path}")
    # 坡比预处理的函数
    slope_pre_treatment.slope_pre_treatment(input_path,txt_path)
    output_file = input_path + '_pre.xlsx'
    log_callback("数据对照表生成完成! 结果保存：" + output_file)

def draw_change_diagram(input_path,log_callback):
    """绘制高程变化图"""
    log_callback(f"绘制变化图")
    log_callback(f"输入文件: {input_path}")
    # 绘制高程变化图的函数
    pipe_elevation_visualizer_compact.pipe_elevation_visualizer_compact(input_path)
    log_callback("高程变化图绘制完成! 结果保存到同名文件夹")

def MDB_chake_1_inmain(input_path,log_callback):
    """执行MDB检查1——单井逆流和井深错误"""
    log_callback(f"MDB检查1 - 单井逆流和井深错误")
    log_callback(f"输入文件: {input_path}")
    # 功能模块导入
    MDB_check_1.MDB_check_1(input_path)
    log_callback("检查完成，结果保存到mdb路径下")

def MDB_plot_inmain(input_path, log_callback):
    """执行MDB管线图绘制"""
    log_callback(f"MDB管线图绘制")
    log_callback(f"输入文件: {input_path}")
    # 功能模块导入
    MDB_plot.MDB_plot(input_path)
    log_callback("管线图绘制完成，结果保存到mdb路径下plot文件夹")

def comparison_of_design_and_construction_inmain(file_path_cgb,file_path_sjb,log_callback):
    """执行施工与设计的匹配"""
    log_callback(f"执行施工与设计数据匹配")
    log_callback(f"输入成果表: {file_path_cgb}")
    log_callback(f"输入格式化设计表: {file_path_sjb}")
    # 功能模块导入
    comparison_of_design_and_construction.comparison_of_design_and_construction(file_path_cgb, file_path_sjb)
    log_callback("施工与设计数据匹配完成")

def mandatory_data_correction_inmain(input_path_cgb, input_max_error, input_save_error, log_callback):
    """执行施工与设计的强制数据整改"""
    log_callback(f"执行施工与设计数据整改")
    log_callback(f"输入成果表: {input_path_cgb}")
    log_callback(f"输入最大误差: {input_max_error}")
    log_callback(f"输入保留误差: {input_save_error}")
    # 功能模块导入
    mandatory_data_correction.mandatory_data_correction(input_path_cgb, input_max_error, input_save_error)
    log_callback("施工与设计数据整改完成")

def comparison_plot_inmain(input_path, log_callback):
    """执行施工与设计对比图绘制"""
    log_callback(f"施工与设计对比图绘制")
    log_callback(f"输入文件: {input_path}")
    # 功能模块导入
    comparison_plot.comparison_plot(input_path)
    log_callback("管线图绘制完成，结果保存到同路径下路径下construction_plot文件夹")

class Application(tk.Tk):
    """主应用程序窗口"""
    
    def __init__(self):
        super().__init__()
        self.title("管网工具v1.5")
        self.geometry("800x600")
        self.resizable(True, True)
        
        # 创建日志区域
        self.create_log_widget()
        
        # 创建功能选项卡
        self.create_tabs()
        
        # 初始化日志
        self.log("应用程序启动")
        self.log(f"当前时间: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        
        # 启动命令行窗口
        self.start_command_window()
    
    def create_log_widget(self):
        """创建日志输出区域"""
        log_frame = ttk.LabelFrame(self, text="处理日志")
        log_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        self.log_text = scrolledtext.ScrolledText(
            log_frame, wrap=tk.WORD, height=15, state='normal'
        )
        self.log_text.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        self.log_text.configure(font=("Consolas", 10))
        
        # 添加清除日志按钮
        clear_btn = ttk.Button(
            log_frame, text="清除日志", command=self.clear_log
        )
        clear_btn.pack(side=tk.RIGHT, padx=5, pady=5)
    
    def create_tabs(self):
        """创建功能选项卡"""
        tab_control = ttk.Notebook(self)
        
        # 创建三个主分类
        tab_group1 = ttk.Frame(tab_control)
        tab_group2 = ttk.Frame(tab_control)
        tab_group3 = ttk.Frame(tab_control)
        
        tab_control.add(tab_group1, text="成果表处理")
        tab_control.add(tab_group2, text="对比表生成")
        tab_control.add(tab_group3, text="MDB处理")

        # --- 成果表处理子选项卡 ---
        subtabs1 = ttk.Notebook(tab_group1)
        tab1 = ttk.Frame(subtabs1)  # 数据库转成果表
        tab2 = ttk.Frame(subtabs1)  # 成果表批量转数据库
        tab3 = ttk.Frame(subtabs1)  # 坡比预处理
        tab4 = ttk.Frame(subtabs1)  # 坡比自动调整
        tab5 = ttk.Frame(subtabs1)  # 断面图生成
        subtabs1.add(tab1, text="数据库转成果表")
        subtabs1.add(tab2, text="成果表批量转数据库")
        subtabs1.add(tab3, text="坡比预处理") 
        subtabs1.add(tab4, text="坡比自动调整")
        subtabs1.add(tab5, text="断面图绘制")
        subtabs1.pack(expand=1, fill="both")

        # --- 对比表生成子选项卡 ---
        subtabs2 = ttk.Notebook(tab_group2)
        tab6 = ttk.Frame(subtabs2)  # 读取设计数据
        tab7 = ttk.Frame(subtabs2)  # 读取施工数据
        tab8 = ttk.Frame(subtabs2)  # 数据对照表生成
        tab11 = ttk.Frame(subtabs2) # 施工与设计对比
        tab12 = ttk.Frame(subtabs2) # 深度不足整改
        tab13 = ttk.Frame(subtabs2) # 生成对比图
        subtabs2.add(tab6, text="读取设计数据")       # 新增
        subtabs2.add(tab7, text="读取施工数据")       # 新增
        subtabs2.add(tab8, text="数据对照表生成")     # 新增
        subtabs2.add(tab11, text="施工与设计对比")
        subtabs2.add(tab12, text="超限自动调整bate")
        subtabs2.add(tab13, text="生成对比图")
        subtabs2.pack(expand=1, fill="both")

        # --- MDB处理子选项卡 ---
        subtabs3 = ttk.Notebook(tab_group3)
        tab9 = ttk.Frame(subtabs3)  # MDB检查1
        tab10 = ttk.Frame(subtabs3)  # MDB绘图
        subtabs3.add(tab9, text="MDB检查1")          # 新增
        subtabs3.add(tab10, text="MDB绘图") 
        subtabs3.pack(expand=1, fill="both")

        tab_control.pack(fill=tk.BOTH, expand=True, padx=10, pady=(0, 10))
        
        # 填充各个标签页
        self.create_tab1_content(tab1)
        self.create_tab2_content(tab2)
        self.create_tab3_content(tab3)
        self.create_tab4_content(tab4)  # 新增
        self.create_tab5_content(tab5)  # 新增
        self.create_tab6_content(tab6)  # 新增
        self.create_tab7_content(tab7)  # 新增
        self.create_tab8_content(tab8)  # 新增
        self.create_tab9_content(tab9)  # 新增
        self.create_tab10_content(tab10)  # 新增
        self.create_tab11_content(tab11)  # 新增
        self.create_tab12_content(tab12)  # 新增
        self.create_tab13_content(tab13)  # 新增

    def create_tab1_content(self, parent):
        """数据库转成果表界面内容"""
        frame = ttk.Frame(parent)
        frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # 埋深表路径
        ttk.Label(frame, text="埋深表路径 (.xls):").grid(row=0, column=0, sticky=tk.W, pady=5)
        self.buried_depth_entry = ttk.Entry(frame, width=60)
        self.buried_depth_entry.grid(row=0, column=1, padx=5, pady=5, sticky=tk.EW)
        ttk.Button(frame, text="浏览...", command=self.browse_buried_depth).grid(row=0, column=2, padx=5, pady=5)
        
        # 坐标表路径
        ttk.Label(frame, text="坐标表路径 (.csv):").grid(row=1, column=0, sticky=tk.W, pady=5)
        self.coord_entry = ttk.Entry(frame, width=60)
        self.coord_entry.grid(row=1, column=1, padx=5, pady=5, sticky=tk.EW)
        ttk.Button(frame, text="浏览...", command=self.browse_coord).grid(row=1, column=2, padx=5, pady=5)
        
        # 参考模板路径
        ttk.Label(frame, text="成果表模板 (.xlsx):").grid(row=2, column=0, sticky=tk.W, pady=5)
        self.template_entry = ttk.Entry(frame, width=60)
        self.template_entry.grid(row=2, column=1, padx=5, pady=5, sticky=tk.EW)
        ttk.Button(frame, text="浏览...", command=self.browse_template).grid(row=2, column=2, padx=5, pady=5)
        
        # 执行按钮
        execute_btn = ttk.Button(frame, text="执行转换", command=self.execute_db_to_output)
        execute_btn.grid(row=3, column=1, pady=15, sticky=tk.E)
        
        # 配置列权重
        frame.columnconfigure(1, weight=1)
    
    def create_tab2_content(self, parent):
        """成果表批量转数据库界面内容"""
        frame = ttk.Frame(parent)
        frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # 成果表目录
        ttk.Label(frame, text="成果表目录:").grid(row=0, column=0, sticky=tk.W, pady=5)
        self.output_dir_entry = ttk.Entry(frame, width=60)
        self.output_dir_entry.grid(row=0, column=1, padx=5, pady=5, sticky=tk.EW)
        ttk.Button(frame, text="浏览...", command=self.browse_output_dir).grid(row=0, column=2, padx=5, pady=5)
        
        # 埋深表模板路径
        ttk.Label(frame, text="埋深表模板路径 (.xls):").grid(row=1, column=0, sticky=tk.W, pady=5)
        self.depth_template_entry = ttk.Entry(frame, width=60)
        self.depth_template_entry.grid(row=1, column=1, padx=5, pady=5, sticky=tk.EW)
        ttk.Button(frame, text="浏览...", command=self.browse_depth_template).grid(row=1, column=2, padx=5, pady=5)
        
        # 执行按钮
        execute_btn = ttk.Button(frame, text="批量转换", command=self.execute_batch_output_to_db)
        execute_btn.grid(row=2, column=1, pady=15, sticky=tk.E)
        
        # 配置列权重
        frame.columnconfigure(1, weight=1)

    def create_tab3_content(self, parent):
        """坡比预处理界面内容"""
        frame = ttk.Frame(parent)
        frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        # 成果表路径
        ttk.Label(frame, text="成果表路径 (.xlsx):").grid(row=0, column=0, sticky=tk.W, pady=5)
        self.output_entry_tab3 = ttk.Entry(frame, width=60)
        self.output_entry_tab3.grid(row=0, column=1, padx=5, pady=5, sticky=tk.EW)
        ttk.Button(frame, text="浏览...",command=lambda: self.browse_file(self.output_entry_tab3, "选择成果表文件", [("Excel 文件", "*.xlsx")])).grid(row=0, column=2, padx=5, pady=5)

        # TXT文件路径
        ttk.Label(frame, text="预调整节点 (.txt):").grid(row=1, column=0, sticky=tk.W, pady=5,)
        self.txt_entry_tab3 = ttk.Entry(frame, width=60)
        self.txt_entry_tab3.grid(row=1, column=1, padx=5, pady=5, sticky=tk.EW)
        ttk.Button(frame, text="浏览...",command=lambda: self.browse_file(self.txt_entry_tab3, "选择成果表文件", [("txt 文件", "*.txt")])).grid(row=1, column=2, padx=5, pady=5)

        # 执行按钮
        execute_btn = ttk.Button(frame, text="坡比预调", command=self.execute_pre_treatment_slope)
        execute_btn.grid(row=2, column=1, pady=15, sticky=tk.E)

        # 配置列权重
        frame.columnconfigure(1, weight=1)
    
    def create_tab4_content(self, parent):
        """坡比自动调整界面内容"""
        frame = ttk.Frame(parent)
        frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # 成果表路径
        ttk.Label(frame, text="成果表路径 (.xlsx):").grid(row=0, column=0, sticky=tk.W, pady=5)
        self.output_entry = ttk.Entry(frame, width=60)
        self.output_entry.grid(row=0, column=1, padx=5, pady=5, sticky=tk.EW)
        ttk.Button(frame, text="浏览...",command=lambda: self.browse_file(self.output_entry, "选择成果表文件", [("Excel 文件", "*.xlsx")])).grid(row=0, column=2, padx=5, pady=5)

        # 初始化按钮
        execute_btn = ttk.Button(frame, text="记录原数据", command=self.execute_save_original_data)
        execute_btn.grid(row=1, column=1, pady=15, sticky=tk.E)
        
        # 执行按钮
        execute_btn = ttk.Button(frame, text="调整坡比", command=self.execute_adjust_slope)
        execute_btn.grid(row=1, column=2, pady=15, sticky=tk.E)
        
        # 配置列权重
        frame.columnconfigure(1, weight=1)



    def create_tab5_content(self, parent):
        """绘制高程变化调整图"""
        frame = ttk.Frame(parent)
        frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        # 成果表路径
        ttk.Label(frame, text="成果表路径 (.xlsx):").grid(row=0, column=0, sticky=tk.W, pady=5)
        self.output_entry_tab5 = ttk.Entry(frame, width=60)
        self.output_entry_tab5.grid(row=0, column=1, padx=5, pady=5, sticky=tk.EW)
        ttk.Button(frame, text="浏览...",command=lambda: self.browse_file(self.output_entry_tab5, "选择成果表文件", [("Excel 文件", "*.xlsx")])).grid(row=0, column=2, padx=5, pady=5)

        # 执行按钮
        execute_btn = ttk.Button(frame, text="绘制图像", command=self.execute_draw_change_diagram)
        execute_btn.grid(row=1, column=1, pady=15, sticky=tk.E)

        # 配置列权重
        frame.columnconfigure(1, weight=1)

    def create_tab6_content(self, parent):
        """读取设计数据界面内容"""
        frame = ttk.Frame(parent)
        frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # 设计表路径
        ttk.Label(frame, text="设计表路径 (.xlsx):").grid(row=0, column=0, sticky=tk.W, pady=5)
        self.design_table_entry = ttk.Entry(frame, width=60)  # 新增输入框
        self.design_table_entry.grid(row=0, column=1, padx=5, pady=5, sticky=tk.EW)
        ttk.Button(
            frame, text="浏览...", 
            command=lambda: self.browse_file(self.design_table_entry, "选择设计表文件", [("Excel 文件", "*.xlsx")])
        ).grid(row=0, column=2, padx=5, pady=5)
        
        # 执行按钮
        execute_btn = ttk.Button(frame, text="读取设计数据", command=self.execute_read_design)
        execute_btn.grid(row=1, column=1, pady=15, sticky=tk.E)
        
        # 配置列权重
        frame.columnconfigure(1, weight=1)
    
    def create_tab7_content(self, parent):
        """读取施工数据界面内容"""
        frame = ttk.Frame(parent)
        frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # 设计施工对比表模板路径
        ttk.Label(frame, text="对比表模板路径 (.xlsx):").grid(row=0, column=0, sticky=tk.W, pady=5)
        self.comparison_template_entry = ttk.Entry(frame, width=60)  # 新增输入框
        self.comparison_template_entry.grid(row=0, column=1, padx=5, pady=5, sticky=tk.EW)
        ttk.Button(
            frame, text="浏览...", 
            command=lambda: self.browse_file(self.comparison_template_entry, "选择对比表模板", [("Excel 文件", "*.xlsx")])
        ).grid(row=0, column=2, padx=5, pady=5)
        
        # 成果表路径
        ttk.Label(frame, text="成果表路径 (.xlsx):").grid(row=1, column=0, sticky=tk.W, pady=5)
        self.result_table_entry = ttk.Entry(frame, width=60)  # 新增输入框
        self.result_table_entry.grid(row=1, column=1, padx=5, pady=5, sticky=tk.EW)
        ttk.Button(
            frame, text="浏览...", 
            command=lambda: self.browse_file(self.result_table_entry, "选择成果表文件", [("Excel 文件", "*.xlsx")])
        ).grid(row=1, column=2, padx=5, pady=5)
        
        # 执行按钮
        execute_btn = ttk.Button(frame, text="读取施工数据", command=self.execute_read_construction)
        execute_btn.grid(row=2, column=1, pady=15, sticky=tk.E)
        
        # 配置列权重
        frame.columnconfigure(1, weight=1)
    
    def create_tab8_content(self, parent):
        """数据对照表生成界面内容"""
        frame = ttk.Frame(parent)
        frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # 成果表路径
        ttk.Label(frame, text="成果表路径 (.xlsx):").grid(row=0, column=0, sticky=tk.W, pady=5)
        self.result_table_entry2 = ttk.Entry(frame, width=60)  # 新增输入框
        self.result_table_entry2.grid(row=0, column=1, padx=5, pady=5, sticky=tk.EW)
        ttk.Button(
            frame, text="浏览...", 
            command=lambda: self.browse_file(self.result_table_entry2, "选择成果表文件", [("Excel 文件", "*.xlsx")])
        ).grid(row=0, column=2, padx=5, pady=5)
        
        # 设计表路径
        ttk.Label(frame, text="设计表路径 (.xlsx):").grid(row=1, column=0, sticky=tk.W, pady=5)
        self.design_table_entry2 = ttk.Entry(frame, width=60)  # 新增输入框
        self.design_table_entry2.grid(row=1, column=1, padx=5, pady=5, sticky=tk.EW)
        ttk.Button(
            frame, text="浏览...", 
            command=lambda: self.browse_file(self.design_table_entry2, "选择设计表文件", [("Excel 文件", "*.xlsx")])
        ).grid(row=1, column=2, padx=5, pady=5)
        
        # 执行按钮
        execute_btn = ttk.Button(frame, text="生成对照表", command=self.execute_generate_comparison)
        execute_btn.grid(row=2, column=1, pady=15, sticky=tk.E)
        
        # 配置列权重
        frame.columnconfigure(1, weight=1)

    def create_tab9_content(self, parent):
        """MDB检查1界面内容"""
        frame = ttk.Frame(parent)
        frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        # MDB输入路径
        ttk.Label(frame, text="MDB输入路径 (.mdb):").grid(row=0, column=0, sticky=tk.W, pady=5)
        self.input_entry_tab9 = ttk.Entry(frame, width=60)
        self.input_entry_tab9.grid(row=0, column=1, padx=5, pady=5, sticky=tk.EW)
        ttk.Button(frame, text="浏览...", command=lambda: self.browse_file(self.input_entry_tab9, "选择MDB输入文件", [("MDB 文件", "*.mdb")])).grid(row=0, column=2, padx=5, pady=5)

        # 执行按钮
        execute_btn = ttk.Button(frame, text="执行MDB检查1", command=self.execute_mdb_check_1)
        execute_btn.grid(row=1, column=1, pady=15, sticky=tk.E)

        # 配置列权重
        frame.columnconfigure(1, weight=1)

    def create_tab10_content(self, parent):
        """MDB绘图界面内容"""
        frame = ttk.Frame(parent)
        frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        # MDB输入路径
        ttk.Label(frame, text="MDB输入路径 (.mdb):").grid(row=0, column=0, sticky=tk.W, pady=5)
        self.input_entry_tab10 = ttk.Entry(frame, width=60)
        self.input_entry_tab10.grid(row=0, column=1, padx=5, pady=5, sticky=tk.EW)
        ttk.Button(frame, text="浏览...", command=lambda: self.browse_file(self.input_entry_tab10, "选择MDB输入文件", [("MDB 文件", "*.mdb")])).grid(row=0, column=2, padx=5, pady=5)
        # 执行按钮
        execute_btn = ttk.Button(frame, text="绘制图像", command=self.execute_mdb_plot)
        execute_btn.grid(row=1, column=1, pady=15, sticky=tk.E)

        # 配置列权重
        frame.columnconfigure(1, weight=1)

    def create_tab11_content(self, parent):
        """施工成果与设计数据对比"""
        frame = ttk.Frame(parent)
        frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        # 成果表路径
        ttk.Label(frame, text="成果表路径 (.xlsx):").grid(row=0, column=0, sticky=tk.W, pady=5)
        self.input_cgb_tab11 = ttk.Entry(frame, width=60)  # 输入框
        self.input_cgb_tab11.grid(row=0, column=1, padx=5, pady=5, sticky=tk.EW)
        ttk.Button(
            frame, text="浏览...", 
            command=lambda: self.browse_file(self.input_cgb_tab11, "选择成果表文件", [("Excel 文件", "*.xlsx")])
        ).grid(row=0, column=2, padx=5, pady=5)
        
        # 设计表路径
        ttk.Label(frame, text="设计表路径 (.xlsx):").grid(row=1, column=0, sticky=tk.W, pady=5)
        self.input_sjb_tab11 = ttk.Entry(frame, width=60)  # 输入框
        self.input_sjb_tab11.grid(row=1, column=1, padx=5, pady=5, sticky=tk.EW)
        ttk.Button(
            frame, text="浏览...", 
            command=lambda: self.browse_file(self.input_sjb_tab11, "选择设计表文件", [("Excel 文件", "*.xlsx")])
        ).grid(row=1, column=2, padx=5, pady=5)

        execute_btn = ttk.Button(frame, text="记录原数据", command=self.execute_save_original_data_tab11)
        execute_btn.grid(row=2, column=1, pady=15, sticky=tk.E)

        execute_btn = ttk.Button(frame, text="生成对比", command=self.execute_comparison_of_design_and_construction)
        execute_btn.grid(row=2, column=2, pady=15, sticky=tk.E)

        # 配置列权重
        frame.columnconfigure(1, weight=1)

    def create_tab12_content(self, parent):
        """强制误差改正"""
        frame = ttk.Frame(parent)
        frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        # 成果表路径
        ttk.Label(frame, text="加入设计对比的成果表路径 (.xlsx):").grid(row=0, column=0, sticky=tk.W, pady=5)
        self.input_cgb_tab12 = ttk.Entry(frame, width=60)  # 输入框
        self.input_cgb_tab12.grid(row=0, column=1, padx=5, pady=5, sticky=tk.EW)
        ttk.Button(
            frame, text="浏览...", 
            command=lambda: self.browse_file(self.input_cgb_tab12, "选择文件", [("Excel 文件", "*.xlsx")])
        ).grid(row=0, column=2, padx=5, pady=5)
        
        # 改正参数
        ttk.Label(frame, text="改正阈值(m):").grid(row=1, column=0, sticky=tk.W, pady=5)
        self.input_max_error_tab12 = ttk.Entry(frame, width=60)  # 输入修改条件，超过d的部分进行调整
        self.input_max_error_tab12.grid(row=1, column=1, padx=5, pady=5, sticky=tk.EW)
        ttk.Label(frame, text="保留误差(m):").grid(row=2, column=0, sticky=tk.W, pady=5)
        self.input_save_error_tab12 = ttk.Entry(frame, width=60)  # 输入保留误差，改正到离设计值多少
        self.input_save_error_tab12.grid(row=2, column=1, padx=5, pady=5, sticky=tk.EW)

        #只修改超过改正阈值且比设计值浅的部分。保留误差调整修改幅度，保留误差为0则改正后与设计值一致
        execute_btn = ttk.Button(frame, text="数据修改", command=self.execute_mandatory_data_correction)
        execute_btn.grid(row=4, column=1, pady=15, sticky=tk.E)

        # 配置列权重
        frame.columnconfigure(1, weight=1)

    def create_tab13_content(self, parent):
        """绘制对比图"""
        frame = ttk.Frame(parent)
        frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        # 成果表输入
        ttk.Label(frame, text="包含设计对比的成果表 (.xlsx):").grid(row=0, column=0, sticky=tk.W, pady=5)
        self.input_tab13 = ttk.Entry(frame, width=60)
        self.input_tab13.grid(row=0, column=1, padx=5, pady=5, sticky=tk.EW)
        ttk.Button(frame, text="浏览...", command=lambda: self.browse_file(self.input_tab13, "选择xlsx输入文件", [("xlsx 文件", "*.xlsx")])).grid(row=0, column=2, padx=5, pady=5)
        # 执行按钮
        execute_btn = ttk.Button(frame, text="绘制图像", command=self.execute_comparison_plot)
        execute_btn.grid(row=1, column=1, pady=15, sticky=tk.E)
        # 配置列权重
        frame.columnconfigure(1, weight=1)
    
    def start_command_window(self):
        """启动命令行窗口"""
        # 创建新线程来启动命令行窗口
        threading.Thread(target=self.open_command_window, daemon=True).start()
    
    def open_command_window(self):
        """打开命令行窗口"""
        if sys.platform == "win32":
            # Windows 系统
            subprocess.Popen(["cmd.exe"])
        else:
            # Linux/Mac 系统
            subprocess.Popen(["x-terminal-emulator"])

    # 通用文件浏览方法（优化版）
    def browse_file(self, entry_widget, title, filetypes):
        """通用文件浏览方法"""
        file_path = filedialog.askopenfilename(title=title, filetypes=filetypes)
        if file_path:
            entry_widget.delete(0, tk.END)
            entry_widget.insert(0, file_path)

    def browse_txt(self):
        """浏览txt文件"""
        file_path = filedialog.askopenfilename(
            title="选择埋深表文件",
            filetypes=[("txt 文件", "*.txt"), ("所有文件", "*.*")]
        )
        if file_path:
            self.txt_entry_tab3.delete(0, tk.END)
            self.txt_entry_tab3.delete(0, file_path)
    
    def browse_buried_depth(self):
        """浏览埋深表文件"""
        file_path = filedialog.askopenfilename(
            title="选择埋深表文件",
            filetypes=[("Excel 文件", "*.xls *.xlsx"), ("所有文件", "*.*")]
        )
        if file_path:
            self.buried_depth_entry.delete(0, tk.END)
            self.buried_depth_entry.insert(0, file_path)
    
    def browse_coord(self):
        """浏览坐标表文件"""
        file_path = filedialog.askopenfilename(
            title="选择坐标表文件",
            filetypes=[("CSV 文件", "*.csv"), ("所有文件", "*.*")]
        )
        if file_path:
            self.coord_entry.delete(0, tk.END)
            self.coord_entry.insert(0, file_path)
    
    def browse_template(self):
        """浏览参考模板文件"""
        file_path = filedialog.askopenfilename(
            title="选择参考模板文件",
            filetypes=[("Excel 文件", "*.xls *.xlsx"), ("所有文件", "*.*")]
        )
        if file_path:
            self.template_entry.delete(0, tk.END)
            self.template_entry.insert(0, file_path)
    
    def browse_output_dir(self):
        """浏览成果表目录"""
        dir_path = filedialog.askdirectory(title="选择成果表目录")
        if dir_path:
            self.output_dir_entry.delete(0, tk.END)
            self.output_dir_entry.insert(0, dir_path)
    
    def browse_depth_template(self):
        """浏览埋深表模板文件"""
        file_path = filedialog.askopenfilename(
            title="选择埋深表模板文件",
            filetypes=[("Excel 文件", "*.xls *.xlsx"), ("所有文件", "*.*")]
        )
        if file_path:
            self.depth_template_entry.delete(0, tk.END)
            self.depth_template_entry.insert(0, file_path)
    
    def browse_output(self):
        """浏览成果表文件"""
        file_path = filedialog.askopenfilename(
            title="选择成果表文件",
            filetypes=[("Excel 文件", "*.xls *.xlsx"), ("所有文件", "*.*")]
        )
        if file_path:
            self.output_entry.delete(0, tk.END)
            self.output_entry.insert(0, file_path)
    
    def execute_db_to_output(self):
        """执行数据库转成果表功能"""
        buried_depth = self.buried_depth_entry.get()
        coord = self.coord_entry.get()
        template = self.template_entry.get()
        
        # 验证输入
        if not all([buried_depth, coord, template]):
            self.log("错误: 请填写所有必填字段!")
            return
        
        # 启动新线程执行任务
        threading.Thread(
            target=db_to_output_table,
            args=(buried_depth, coord, template, self.log),
            daemon=True
        ).start()
    
    def execute_batch_output_to_db(self):
        """执行成果表批量转数据库功能"""
        output_dir = self.output_dir_entry.get()
        depth_template = self.depth_template_entry.get()
        
        # 验证输入
        if not all([output_dir, depth_template]):
            self.log("错误: 请填写所有必填字段!")
            return
        
        # 启动新线程执行任务
        threading.Thread(
            target=batch_output_to_db,
            args=(output_dir, depth_template, self.log),
            daemon=True
        ).start()
    
    def execute_adjust_slope(self):
        """执行坡比自动调整功能"""
        output_path = self.output_entry.get()
        
        # 验证输入
        if not output_path:
            self.log("错误: 请选择成果表文件!")
            return
        
        # 启动新线程执行任务
        threading.Thread(
            target=adjust_slope_ratio,
            args=(output_path, self.log),
            daemon=True
        ).start()

    def execute_save_original_data(self):
        """执行成果表初始化功能"""
        output_path = self.output_entry.get()
        # 验证输入
        if not output_path:
            self.log("错误: 请选择成果表文件!")
            return
        
        # 启动新线程执行任务
        threading.Thread(
            target=save_original_data_main,
            args=(output_path, self.log),
            daemon=True
        ).start()

    def execute_pre_treatment_slope(self): 
        """执行坡比预调整功能"""
        output_path = self.output_entry_tab3.get()
        txt_path= self.txt_entry_tab3.get()
        # 验证输入
        if not output_path:
            self.log("错误: 请选择成果表文件!")
            return
        
        # 启动新线程执行任务
        threading.Thread(
            target=slope_pre_treatment_main,
            args=(output_path,txt_path,self.log),
            daemon=True
        ).start()
    def execute_draw_change_diagram(self): 
        """执行绘制变化图功能"""
        output_path = self.output_entry_tab5.get()
        
        # 验证输入
        if not output_path:
            self.log("错误: 请选择成果表文件!")
            return
        
        # 启动新线程执行任务
        threading.Thread(
            target=draw_change_diagram,
            args=(output_path, self.log),
            daemon=True
        ).start()

    def execute_read_design(self):
        """执行读取设计数据功能"""
        design_table_path = self.design_table_entry.get()
        
        if not design_table_path:
            self.log("错误: 请选择设计表文件!")
            return
        
        # 启动新线程执行任务
        threading.Thread(
            target=read_design_data_inmain,
            args=(design_table_path, self.log),
            daemon=True
        ).start()
    
    def execute_read_construction(self):
        """执行读取施工数据功能"""
        template_path = self.comparison_template_entry.get()
        result_table_path = self.result_table_entry.get()
        
        if not all([template_path, result_table_path]):
            self.log("错误: 请填写所有必填字段!")
            return
        
        # 启动新线程执行任务
        threading.Thread(
            target=read_construction_data_inmain,
            args=(template_path, result_table_path, self.log),
            daemon=True
        ).start()
    
    def execute_generate_comparison(self):
        """执行生成数据对照表功能"""
        result_table_path = self.result_table_entry2.get()
        design_table_path = self.design_table_entry2.get()
        
        if not all([result_table_path, design_table_path]):
            self.log("错误: 请填写所有必填字段!")
            return
        
        # 启动新线程执行任务
        threading.Thread(
            target=generate_comparison_table_inmain,
            args=(result_table_path, design_table_path, self.log),
            daemon=True
        ).start()

    def execute_mdb_check_1(self):
        """执行MDB检查1功能"""
        input_path = self.input_entry_tab9.get()
        
        if not input_path:
            self.log("错误: 请选择MDB输入文件!")
            return
        
        # 启动新线程执行任务
        threading.Thread(
            target=MDB_chake_1_inmain,
            args=(input_path, self.log),
            daemon=True
        ).start()

    def execute_mdb_plot(self):
        """执行MDB管线图绘制"""
        input_path = self.input_entry_tab10.get()
        if not input_path:
            self.log("错误: 请选择MDB输入文件!")
            return
        
        # 启动新线程执行任务
        threading.Thread(
            target=MDB_plot_inmain,
            args=(input_path, self.log),
            daemon=True
        ).start()
    
    def execute_save_original_data_tab11(self):
        """执行成果表初始化功能"""
        input_path_cgb = self.input_cgb_tab11.get()
        # 验证输入
        if not input_path_cgb:
            self.log("错误: 请选择成果表文件!")
            return
        
        # 启动新线程执行任务
        threading.Thread(
            target=save_original_data_main,
            args=(input_path_cgb, self.log),
            daemon=True
        ).start()

    def execute_comparison_of_design_and_construction(self):
        """执行施工与设计数据对比"""
        input_path_cgb = self.input_cgb_tab11.get()
        input_path_sjb = self.input_sjb_tab11.get()
        if not input_path_cgb or not input_path_sjb:
            self.log("错误: 请选择正确的xlsx文件!")
            return
        # 启动新线程执行任务
        threading.Thread(
            target=comparison_of_design_and_construction_inmain,
            args=(input_path_cgb,input_path_sjb, self.log),
            daemon=True
        ).start()

    def execute_mandatory_data_correction(self):
        """执行施工与设计数据对比"""
        input_path_cgb = self.input_cgb_tab12.get()
        input_max_error = self.input_max_error_tab12.get()
        input_save_error = self.input_save_error_tab12.get()
        if not input_path_cgb or not input_max_error:
            self.log("错误: 请选择正确的xlsx文件!")
            return
        if not input_save_error:
            input_save_error="0"
        # 启动新线程执行任务
        threading.Thread(
            target=mandatory_data_correction_inmain,
            args=(input_path_cgb,input_max_error,input_save_error, self.log),
            daemon=True
        ).start()
        

    def execute_comparison_plot(self):
        """执行施工与设计对比图绘制"""
        input_path = self.input_tab13.get()
        if not input_path:
            self.log("错误: 请选择成果表xlsx文件!")
            return
        
        # 启动新线程执行任务
        threading.Thread(
            target=comparison_plot_inmain,
            args=(input_path, self.log),
            daemon=True
        ).start()
    
    def log(self, message):
        """添加日志消息"""
        timestamp = datetime.datetime.now().strftime("%H:%M:%S")
        log_message = f"[{timestamp}] {message}"
        
        # 更新日志文本框
        self.log_text.configure(state='normal')
        self.log_text.insert(tk.END, log_message + "\n")
        self.log_text.see(tk.END)  # 滚动到底部
        self.log_text.configure(state='disabled')
        
        # 同时在控制台打印
        print(log_message)
    
    def clear_log(self):
        """清除日志"""
        self.log_text.configure(state='normal')
        self.log_text.delete(1.0, tk.END)
        self.log_text.configure(state='disabled')
        self.log("日志已清除")

if __name__ == "__main__":
    # 添加时间处理函数所需的模块
    import time
    
    # 创建并运行应用程序
    app = Application()
    app.mainloop()