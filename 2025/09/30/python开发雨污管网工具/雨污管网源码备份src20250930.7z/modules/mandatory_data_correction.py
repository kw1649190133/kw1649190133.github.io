import os
from openpyxl import Workbook, load_workbook
from openpyxl.utils import get_column_letter

# 根据误差阈值参数修改成果表

# 字符串清理空格
def strc(s):
    if not isinstance(s, str) or not s:
        return s
    return s.replace(" ","")

# 字符串比较不区分大小写
def strcompare_lower(a,b):
    if strc(a).lower() ==strc(b).lower():
        return 1
    else:
        return 0

# 执行函数-管底修正
def data_correction(cgb,max_error,save_error):
    max_error = float(max_error)
    save_error = float(save_error)
    for i in range(6,cgb.max_row+1):
        if (cgb[f"BA{i}"].value) is not None and cgb[f"J{i}"].value is not None and cgb[f"H{i}"].value is not None:
            start_name = cgb[f"B{i}"].value
            #gdbg_sj = cgb[f"AU{i}"].value
            gdbg_d = float(cgb[f"BA{i}"].value) #管底标高差
            if gdbg_d is not None and gdbg_d > max_error: 
                gdbg_sg = float(cgb[f"J{i}"].value) #当前施工管底
                gdxz_d = round(gdbg_d - save_error,3) #管底标高差修正值
                new_gdbg = round(gdbg_sg - gdxz_d,3) #新的管底
                new_ms = round(float(cgb[f"H{i}"].value) - new_gdbg,3) #新的埋深 = 地面-管底
                cgb[f"J{i}"] = new_gdbg
                cgb[f"K{i}"] = new_ms
                cgb[f"BD{i}"] = - gdxz_d 
                cgb[f"BE{i}"] = round(new_ms - float(cgb[f"K{i}"].value),3) #埋深变化值

                cgb = lxj_change(start_name,new_gdbg,cgb)
                continue

    return cgb

# 流向井管底同步修正
def lxj_change(name,new_gdbg,cgb):
    for j in range(6,cgb.max_row+1):
        if name is not None and cgb[f"C{j}"].value is not None and strcompare_lower(name,cgb[f"C{j}"].value):
            cgb[f"O{j}"] = new_gdbg
            continue
    return cgb

# 功能封装
def mandatory_data_correction(file_path_cgb,max_error,save_error):
    if file_path_cgb.endswith('.xlsx'):
        output_file = file_path_cgb.replace('.xlsx', '_数据修改.xlsx')
    else:
        output_file = file_path_cgb + '_数据修改.xlsx'

    # 读取Excel文件
    cgb = load_workbook(file_path_cgb)

    if "W" in cgb :
        print('__Loading W sheet__')
        cgb_w = cgb["W"] # 按名称获取
        cgb_w = data_correction(cgb_w,max_error,save_error)
    else:
        print("成果数据未找到W表")

    if "Y" in cgb :
        print('__Loading Y sheet__')
        cgb_y = cgb["Y"] # 按名称获取
        cgb_y = data_correction(cgb_y,max_error,save_error)
    else:
        print("成果数据未找到Y表")

    # 保存结果
    cgb.save(output_file)
    print("———————————分割线———————————")
    print(f"处理完成！结果已保存到: {output_file}")

# 主函数
def main():

    # 获取输入文件路径
    file_path_cgb = input("请输入成果表Excel文件路径: ").strip()
    if not os.path.exists(file_path_cgb):
        print("成果表文件不存在，请检查路径")
        return
    max_error = float(input("请输入误差阈值(m): ").strip())
    if not max_error:
        print("误差阈值不能为空，请重新输入")
        return
    save_error = float(input("请输入保留误差(m): ").strip())
    if not save_error:
        save_error = 0
    mandatory_data_correction(file_path_cgb,max_error,save_error)

if __name__ == "__main__":
    main()