# MDB直接统计单井逆流和井底异常。
"""
现在需要设计一个程序，检查排水管道数据中的问题，输入MDB数据库，其中有名称为管点调查表和管线调查表的两张表，需要检查其中的内容并在相同路径输出一个txt作为检查报告。
管线调查表记录的是每一段管线的数据，其中S_POINT字段是起点井名称，E_POINT是终点井名称，S_H是起点井面高程，E_H是终点井面高程，S_DEEP是起点埋设深度，E_DEEP是终点埋设深度。
管点表中，EXP_NO是井名称，SUR_H是井面高程。WellDeep是井深。
目前需要检查两项内容：1.是否有井的进水口低于出水口的情况。进水口高程是管线的终点井面-终点埋深，出水口高程是管线的起点井面-起点埋深。也就是说，根据点名匹配管线的连接关系，管线终点的高度如果低于下一段管线的起点，就要汇报异常2.是否有井深小于管深的情况，就是按照名称匹配将管表中起点和终点的埋设深度与井表的井深比较。如果有则在txt中报告异常井的名称、异常管道的两个节点、异常的偏差值。
"""

import pypyodbc
import os
import sys

def check_drainage_data(mdb_path):
    """
    检查排水管道数据中的问题
    
    参数:
    mdb_path (str): Access数据库(.mdb)文件路径
    
    返回:
    str: 检查报告文件路径
    """
    # 检查文件是否存在
    if not os.path.exists(mdb_path):
        raise FileNotFoundError(f"数据库文件不存在: {mdb_path}")
    
    # 设置输出报告路径
    report_path = os.path.splitext(mdb_path)[0] + "_检查报告.txt"
    
    try:
        # 连接Access数据库
        conn_str = (
            r"DRIVER={Microsoft Access Driver (*.mdb, *.accdb)};"
            f"DBQ={mdb_path};"
        )
        conn = pypyodbc.connect(conn_str)
        cursor = conn.cursor()
        
        # 读取管点调查表数据
        cursor.execute("SELECT EXP_NO, SUR_H, WellDeep FROM [管点调查表]")
        manhole_data = {}
        for row in cursor.fetchall():
            exp_no, sur_h, well_deep = row
            # 处理可能的空值
            sur_h = float(sur_h) if sur_h is not None and str(sur_h).strip() else None
            well_deep = float(well_deep) if well_deep is not None and str(well_deep).strip() else None
            
            manhole_data[exp_no] = {
                'surface_elevation': sur_h,
                'well_depth': well_deep
            }
        
        # 读取管线调查表数据
        cursor.execute("SELECT S_POINT, E_POINT, S_H, E_H, S_DEEP, E_DEEP FROM [管线调查表]")
        pipeline_data = []
        for row in cursor.fetchall():
            s_point, e_point, s_h, e_h, s_deep, e_deep = row
            
            # 转换数据类型并处理空值
            s_h = float(s_h) if s_h is not None and str(s_h).strip() else None
            e_h = float(e_h) if e_h is not None and str(e_h).strip() else None
            s_deep = float(s_deep) if s_deep is not None and str(s_deep).strip() else None
            e_deep = float(e_deep) if e_deep is not None and str(e_deep).strip() else None
            
            pipeline_data.append({
                'start_point': s_point,
                'end_point': e_point,
                'start_surface_elevation': s_h,
                'end_surface_elevation': e_h,
                'start_depth': s_deep,
                'end_depth': e_deep,
                'start_elevation': s_h - s_deep if s_h is not None and s_deep is not None else None,
                'end_elevation': e_h - e_deep if e_h is not None and e_deep is not None else None
            })
        
        # 关闭数据库连接
        cursor.close()
        conn.close()
        
        # 构建管道网络图
        network = {}
        for pipe in pipeline_data:
            start = pipe['start_point']
            end = pipe['end_point']
            
            if start not in network:
                network[start] = {'outgoing': [], 'incoming': []}
            if end not in network:
                network[end] = {'outgoing': [], 'incoming': []}
            
            network[start]['outgoing'].append(pipe)
            network[end]['incoming'].append(pipe)
        
        # 检查问题
        elevation_issues = []  # 进水口低于出水口问题
        depth_issues = []      # 井深小于管深问题
        
        # 1. 检查进水口低于出水口问题
        for node, connections in network.items():
            # 该节点作为终点(进水口)的管道
            incoming_pipes = connections['incoming']
            # 该节点作为起点(出水口)的管道
            outgoing_pipes = connections['outgoing']
            
            # 对于每个流入管道(进水口)和流出管道(出水口)的组合
            for in_pipe in incoming_pipes:
                for out_pipe in outgoing_pipes:
                    # 获取进水口高程(流入管道的终点高程)
                    in_elevation = in_pipe['end_elevation']
                    # 获取出水口高程(流出管道的起点高程)
                    out_elevation = out_pipe['start_elevation']
                    
                    # 检查是否有有效数据
                    if in_elevation is None or out_elevation is None:
                        continue
                    
                    # 检查进水口是否低于出水口
                    if in_elevation < out_elevation:
                        deviation = out_elevation - in_elevation
                        elevation_issues.append({
                            'node': node,
                            'in_pipe': in_pipe,
                            'out_pipe': out_pipe,
                            'deviation': deviation
                        })
        
        # 2. 检查井深小于管深问题
        for pipe in pipeline_data:
            # 检查起点井
            start_point = pipe['start_point']
            if start_point in manhole_data:
                well_depth = manhole_data[start_point]['well_depth']
                pipe_depth = pipe['start_depth']
                
                if well_depth is not None and pipe_depth is not None:
                    if well_depth < pipe_depth:
                        depth_issues.append({
                            'well': start_point,
                            'pipe': pipe,
                            'location': '起点',
                            'required_depth': pipe_depth,
                            'actual_depth': well_depth,
                            'deviation': pipe_depth - well_depth
                        })
            
            # 检查终点井
            end_point = pipe['end_point']
            if end_point in manhole_data:
                well_depth = manhole_data[end_point]['well_depth']
                pipe_depth = pipe['end_depth']
                
                if well_depth is not None and pipe_depth is not None:
                    if well_depth < pipe_depth:
                        depth_issues.append({
                            'well': end_point,
                            'pipe': pipe,
                            'location': '终点',
                            'required_depth': pipe_depth,
                            'actual_depth': well_depth,
                            'deviation': pipe_depth - well_depth
                        })
        
        # 生成检查报告
        with open(report_path, 'w', encoding='utf-8') as report:
            report.write("=" * 80 + "\n")
            report.write("排水管道数据检查报告\n")
            report.write("=" * 80 + "\n\n")
            
            # 报告进水口低于出水口问题
            report.write("一、进水口低于出水口问题检查\n")
            report.write("-" * 80 + "\n")
            
            if elevation_issues:
                report.write(f"发现 {len(elevation_issues)} 处进水口低于出水口的问题:\n\n")
                for i, issue in enumerate(elevation_issues, 1):
                    report.write(f"问题 {i}: \n")
                    report.write(f"  异常井: {issue['node']}\n")
                    report.write(f"  流入管道: {issue['in_pipe']['start_point']} → {issue['in_pipe']['end_point']}\n")
                    report.write(f"  流出管道: {issue['out_pipe']['start_point']} → {issue['out_pipe']['end_point']}\n")
                    report.write(f"  进水口高程: {issue['in_pipe']['end_elevation']:.3f}\n")
                    report.write(f"  出水口高程: {issue['out_pipe']['start_elevation']:.3f}\n")
                    report.write(f"  高程偏差: +{issue['deviation']:.3f} (出水口高于进水口)\n\n")
            else:
                report.write("未发现进水口低于出水口的问题。\n\n")
            
            # 报告井深小于管深问题
            report.write("二、井深小于管深问题检查\n")
            report.write("-" * 80 + "\n")
            
            if depth_issues:
                report.write(f"发现 {len(depth_issues)} 处井深小于管深的问题:\n\n")
                for i, issue in enumerate(depth_issues, 1):
                    report.write(f"问题 {i}: \n")
                    report.write(f"  异常井: {issue['well']}\n")
                    report.write(f"  相关管道: {issue['pipe']['start_point']} → {issue['pipe']['end_point']}\n")
                    report.write(f"  问题位置: {issue['location']}\n")
                    report.write(f"  要求井深: {issue['required_depth']:.3f}\n")
                    report.write(f"  实际井深: {issue['actual_depth']:.3f}\n")
                    report.write(f"  深度偏差: -{issue['deviation']:.3f} (井深不足)\n\n")
            else:
                report.write("未发现井深小于管深的问题。\n\n")
            
            # 添加总结
            report.write("=" * 80 + "\n")
            report.write("检查总结:\n")
            report.write(f"进水口低于出水口问题: {len(elevation_issues)} 处\n")
            report.write(f"井深小于管深问题: {len(depth_issues)} 处\n")
            report.write(f"总问题数: {len(elevation_issues) + len(depth_issues)} 处\n")
            report.write("=" * 80 + "\n")
        
        print(f"检查完成! 报告已保存至: {report_path}")
        return report_path
    
    except pypyodbc.Error as e:
        raise RuntimeError(f"数据库连接错误: {str(e)}")
    except Exception as e:
        raise RuntimeError(f"处理过程中发生错误: {str(e)}")

# 功能封装
def MDB_check_1(input_mdb):

    mdb_file = input_mdb
    
    try:
        report_file = check_drainage_data(mdb_file)
        print(f"成功生成检查报告: {report_file}")
    except Exception as e:
        print(f"错误: {str(e)}")

if __name__ == "__main__":
    try:
        mdb_file = input("输入MDB数据库文件路径: ").strip()
        if not os.path.exists(mdb_file):
            print("文件不存在，请检查路径")
        report_file = check_drainage_data(mdb_file)
        print(f"成功生成检查报告: {report_file}")
    except Exception as e:
        print(f"错误: {str(e)}")