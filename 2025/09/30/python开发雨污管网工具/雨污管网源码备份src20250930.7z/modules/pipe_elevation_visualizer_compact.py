# 成果表绘图模块
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import os
from typing import Dict, List, Tuple, Set
from collections import defaultdict, deque
import matplotlib
matplotlib.use('Agg')  # 使用非交互式后端
matplotlib.rcParams['font.sans-serif'] = ['SimHei', 'Arial Unicode MS', 'DejaVu Sans']
matplotlib.rcParams['axes.unicode_minus'] = False

class PipeElevationVisualizerCompact:
    """简化布局版管道高程可视化工具"""
    
    def __init__(self):
        self.pipes = []
        self.nodes = {}
        self.all_paths = []  # 存储所有完整路径
        
    def load_data_from_excel(self, file_path: str):
        """从Excel文件加载数据"""
        try:
            sheet_names = ['W', 'Y']
            
            for sheet_name in sheet_names:
                try:
                    df = pd.read_excel(file_path, sheet_name=sheet_name, header=None)
                    
                    if len(df) > 5:
                        self._process_sheet_data(df, sheet_name)
                        
                except Exception as e:
                    print(f"读取表 {sheet_name} 时出错: {e}")
                    continue
                    
            print(f"成功加载 {len(self.pipes)} 条管道数据")
            self._build_network_structure()
            
        except Exception as e:
            print(f"加载Excel文件时出错: {e}")
    
    def _process_sheet_data(self, df: pd.DataFrame, sheet_name: str):
        """处理单个表的数据"""
        for idx in range(5, len(df)):
            row = df.iloc[idx]
            
            # 检查是否有有效数据
            if pd.isna(row.iloc[1]):  # B列（节点名称）为空则跳过
                continue
                
            try:
                # 提取基本信息
                pipe_id = int(row.iloc[0]) if not pd.isna(row.iloc[0]) else idx + 1  # A列：序号
                start_node = str(row.iloc[1])  # B列：节点名称
                end_node = str(row.iloc[2]) if not pd.isna(row.iloc[2]) else None  # C列：流向节点名称
                
                # 如果有流向节点，说明这是一条管道
                if end_node and not pd.isna(row.iloc[9]) and not pd.isna(row.iloc[14]):
                    # 修改后的高程
                    current_inlet = float(row.iloc[9])   # J列：修改后管道入口高程
                    current_outlet = float(row.iloc[14]) # O列：修改后管道出口高程
                    
                    # 原始高程
                    original_inlet = None
                    original_outlet = None
                    
                    # AC列（第29列）：原始管底入口高程
                    if len(row) > 28 and not pd.isna(row.iloc[28]):
                        original_inlet = float(row.iloc[28])
                    
                    # AE列（第31列）：原始管底出口高程  
                    if len(row) > 30 and not pd.isna(row.iloc[30]):
                        original_outlet = float(row.iloc[30])
                    
                    pipe_data = {
                        'pipe_id': pipe_id,
                        'start_node': start_node,
                        'end_node': end_node,
                        'current_inlet': current_inlet,
                        'current_outlet': current_outlet,
                        'original_inlet': original_inlet if original_inlet is not None else current_inlet,
                        'original_outlet': original_outlet if original_outlet is not None else current_outlet,
                        'sheet_name': sheet_name
                    }
                    
                    self.pipes.append(pipe_data)
                    
            except Exception as e:
                print(f"处理第 {idx + 1} 行数据时出错: {e}")
                continue
    
    def _build_network_structure(self):
        """构建管网结构"""
        # 初始化节点字典
        for pipe in self.pipes:
            if pipe['start_node'] not in self.nodes:
                self.nodes[pipe['start_node']] = {'outgoing': [], 'incoming': []}
            if pipe['end_node'] not in self.nodes:
                self.nodes[pipe['end_node']] = {'outgoing': [], 'incoming': []}
            
            self.nodes[pipe['start_node']]['outgoing'].append(pipe)
            self.nodes[pipe['end_node']]['incoming'].append(pipe)
    
    def find_all_paths(self):
        """找到所有从源头到终点的完整路径"""
        # 识别源头节点（没有上游管道）和终点节点（没有下游管道）
        source_nodes = [node for node, data in self.nodes.items() if not data['incoming']]
        terminal_nodes = [node for node, data in self.nodes.items() if not data['outgoing']]
        
        print(f"识别出 {len(source_nodes)} 个源头节点: {source_nodes}")
        print(f"识别出 {len(terminal_nodes)} 个终点节点: {terminal_nodes}")
        
        self.all_paths = []
        
        # 对每个源头节点，找到所有到达终点的路径
        for source in source_nodes:
            for terminal in terminal_nodes:
                paths = self._find_paths_between_nodes(source, terminal)
                self.all_paths.extend(paths)
        
        print(f"识别出 {len(self.all_paths)} 条完整路径")
    
    def _find_paths_between_nodes(self, start_node: str, end_node: str) -> List[List]:
        """使用DFS找到两个节点之间的所有路径"""
        all_paths = []
        
        def dfs(current_node, target_node, current_path, visited_pipes):
            if current_node == target_node:
                all_paths.append(current_path.copy())
                return
            
            # 遍历当前节点的所有出水管道
            for pipe in self.nodes[current_node]['outgoing']:
                if pipe['pipe_id'] not in visited_pipes:
                    visited_pipes.add(pipe['pipe_id'])
                    current_path.append(pipe)
                    dfs(pipe['end_node'], target_node, current_path, visited_pipes)
                    current_path.pop()
                    visited_pipes.remove(pipe['pipe_id'])
        
        dfs(start_node, end_node, [], set())
        return all_paths
    
    def create_elevation_charts(self, output_folder: str):
        """为每条路径创建高程图表"""
        if not os.path.exists(output_folder):
            os.makedirs(output_folder)
        
        for i, path in enumerate(self.all_paths):
            if not path:
                continue
            
            try:
                # 生成图表
                fig, ax = plt.subplots(figsize=(14, 8))
                
                # 构建节点数据结构
                node_data = self._build_node_elevation_data(path)
                
                # 准备绘图数据
                node_names = list(node_data.keys())
                x_positions = list(range(len(node_names)))
                
                # 绘制每个节点的高程点
                current_inlet_elevations = []
                current_outlet_elevations = []
                original_inlet_elevations = []
                original_outlet_elevations = []
                
                for node_name in node_names:
                    node_info = node_data[node_name]
                    
                    # 获取节点的入口和出口高程
                    current_inlet = node_info.get('current_inlet')
                    current_outlet = node_info.get('current_outlet')
                    original_inlet = node_info.get('original_inlet')
                    original_outlet = node_info.get('original_outlet')
                    
                    current_inlet_elevations.append(current_inlet)
                    current_outlet_elevations.append(current_outlet)
                    original_inlet_elevations.append(original_inlet)
                    original_outlet_elevations.append(original_outlet)
                
                # 绘制调整前的高程点
                for j, x_pos in enumerate(x_positions):
                    # 入口点（圆形标记）
                    if original_inlet_elevations[j] is not None:
                        ax.plot(x_pos, original_inlet_elevations[j], 'bo', markersize=8, 
                               alpha=0.8, zorder=4, label='调整前入口' if j == 0 else "")
                    
                    # 出口点（方形标记）
                    if original_outlet_elevations[j] is not None:
                        ax.plot(x_pos, original_outlet_elevations[j], 'bs', markersize=8, 
                               alpha=0.8, zorder=4, label='调整前出口' if j == 0 else "")
                
                # 绘制调整后的高程点
                for j, x_pos in enumerate(x_positions):
                    # 入口点（圆形标记）
                    if current_inlet_elevations[j] is not None:
                        ax.plot(x_pos, current_inlet_elevations[j], 'o', color='orange', markersize=8, 
                               alpha=0.8, zorder=4, label='调整后入口' if j == 0 else "")
                    
                    # 出口点（方形标记）
                    if current_outlet_elevations[j] is not None:
                        ax.plot(x_pos, current_outlet_elevations[j], 's', color='orange', markersize=8, 
                               alpha=0.8, zorder=4, label='调整后出口' if j == 0 else "")
                
                # 绘制管道段连线
                for j, pipe in enumerate(path):
                    start_node_idx = node_names.index(pipe['start_node'])
                    end_node_idx = node_names.index(pipe['end_node'])
                    
                    # 绘制调整前管道段（蓝色实线）
                    ax.plot([start_node_idx, end_node_idx], 
                           [pipe['original_inlet'], pipe['original_outlet']], 
                           'b-', linewidth=3, alpha=0.6, zorder=2)
                    
                    # 绘制调整后管道段（橙色实线）
                    ax.plot([start_node_idx, end_node_idx], 
                           [pipe['current_inlet'], pipe['current_outlet']], 
                           'orange', linewidth=3, alpha=0.6, zorder=2)
                    
                    # 在管道中点添加管道ID标注
                    mid_x = (start_node_idx + end_node_idx) / 2
                    mid_y = (pipe['current_inlet'] + pipe['current_outlet']) / 2
                    ax.annotate(f"P{pipe['pipe_id']}", (mid_x, mid_y), 
                               xytext=(0, 15), textcoords='offset points', 
                               ha='center', fontsize=9, alpha=0.8, 
                               bbox=dict(boxstyle="round,pad=0.3", facecolor="white", alpha=0.7))
                
                # 绘制节点内部连接（出口到入口的虚线）
                for j, x_pos in enumerate(x_positions):
                    # 调整前的节点内连接
                    if (original_inlet_elevations[j] is not None and 
                        original_outlet_elevations[j] is not None and
                        abs(original_inlet_elevations[j] - original_outlet_elevations[j]) > 0.001):
                        ax.plot([x_pos, x_pos], 
                               [original_outlet_elevations[j], original_inlet_elevations[j]], 
                               'b--', linewidth=2, alpha=0.5, zorder=1)
                    
                    # 调整后的节点内连接
                    if (current_inlet_elevations[j] is not None and 
                        current_outlet_elevations[j] is not None and
                        abs(current_inlet_elevations[j] - current_outlet_elevations[j]) > 0.001):
                        ax.plot([x_pos, x_pos], 
                               [current_outlet_elevations[j], current_inlet_elevations[j]], 
                               'orange', linestyle='--', linewidth=2, alpha=0.5, zorder=1)
                
                # 设置图表属性
                ax.set_xlabel('节点名称', fontsize=12)
                ax.set_ylabel('高程 (m)', fontsize=12)
                
                # 生成标题
                path_name = f"{path[0]['start_node']}-{path[-1]['end_node']}"
                ax.set_title(f'管道高程对比图: {path_name}', fontsize=14, fontweight='bold')
                
                # 设置x轴标签
                ax.set_xticks(x_positions)
                ax.set_xticklabels(node_names, rotation=45, ha='right', fontsize=10)
                
                # 设置y轴范围（自适应）
                all_elevations = []
                for elev_list in [current_inlet_elevations, current_outlet_elevations, 
                                original_inlet_elevations, original_outlet_elevations]:
                    all_elevations.extend([e for e in elev_list if e is not None])
                
                if all_elevations:
                    y_min = min(all_elevations) - 0.5
                    y_max = max(all_elevations) + 0.5
                    ax.set_ylim(y_min, y_max)
                
                # 添加网格
                ax.grid(True, alpha=0.3, zorder=0)
                
                # 添加图例
                ax.legend(loc='upper right', fontsize=9)
                
                # 添加高程数值标注
                for j, (x_pos, node_name) in enumerate(zip(x_positions, node_names)):
                    # 调整后入口高程标注
                    if current_inlet_elevations[j] is not None:
                        ax.annotate(f'{current_inlet_elevations[j]:.2f}', 
                                   (x_pos, current_inlet_elevations[j]), 
                                   xytext=(10, 5), textcoords='offset points', 
                                   ha='left', fontsize=8, color='darkorange', fontweight='bold')
                    
                    # 调整后出口高程标注
                    if current_outlet_elevations[j] is not None:
                        ax.annotate(f'{current_outlet_elevations[j]:.2f}', 
                                   (x_pos, current_outlet_elevations[j]), 
                                   xytext=(-10, 5), textcoords='offset points', 
                                   ha='right', fontsize=8, color='darkorange', fontweight='bold')
                    
                    # 调整前高程标注（只有当有明显变化时才显示）
                    if (original_inlet_elevations[j] is not None and 
                        current_inlet_elevations[j] is not None and
                        abs(current_inlet_elevations[j] - original_inlet_elevations[j]) > 0.01):
                        ax.annotate(f'{original_inlet_elevations[j]:.2f}', 
                                   (x_pos, original_inlet_elevations[j]), 
                                   xytext=(10, -10), textcoords='offset points', 
                                   ha='left', fontsize=8, color='blue', fontweight='bold')
                    
                    if (original_outlet_elevations[j] is not None and 
                        current_outlet_elevations[j] is not None and
                        abs(current_outlet_elevations[j] - original_outlet_elevations[j]) > 0.01):
                        ax.annotate(f'{original_outlet_elevations[j]:.2f}', 
                                   (x_pos, original_outlet_elevations[j]), 
                                   xytext=(-10, -10), textcoords='offset points', 
                                   ha='right', fontsize=8, color='blue', fontweight='bold')
                
                # 调整布局
                plt.tight_layout()
                
                # 保存图片
                filename = f"{path_name}_{i+1}.png"
                filepath = os.path.join(output_folder, filename)
                plt.savefig(filepath, dpi=300, bbox_inches='tight')
                plt.close()
                
                print(f"已生成图表: {filename}")
                
            except Exception as e:
                print(f"生成路径 {i+1} 图表时出错: {e}")
                if 'fig' in locals():
                    plt.close(fig)
                continue
    
    def _build_node_elevation_data(self, path: List[Dict]) -> Dict:
        """构建节点高程数据结构"""
        node_data = {}
        
        # 收集路径中所有节点
        all_nodes = []
        for pipe in path:
            if pipe['start_node'] not in all_nodes:
                all_nodes.append(pipe['start_node'])
            if pipe['end_node'] not in all_nodes:
                all_nodes.append(pipe['end_node'])
        
        # 为每个节点初始化数据
        for node in all_nodes:
            node_data[node] = {
                'current_inlet': None,
                'current_outlet': None,
                'original_inlet': None,
                'original_outlet': None
            }
        
        # 填充节点数据
        for pipe in path:
            start_node = pipe['start_node']
            end_node = pipe['end_node']
            
            # 起始节点的出口高程就是管道的入口高程
            node_data[start_node]['current_inlet'] = pipe['current_inlet']
            node_data[start_node]['original_inlet'] = pipe['original_inlet']
            
            # 终止节点的入口高程就是管道的出口高程
            node_data[end_node]['current_outlet'] = pipe['current_outlet']
            node_data[end_node]['original_outlet'] = pipe['original_outlet']
        
        return node_data
    
    def generate_summary_report(self, output_folder: str):
        """生成汇总报告"""
        report_path = os.path.join(output_folder, "elevation_changes_summary.txt")
        
        try:
            with open(report_path, 'w', encoding='utf-8') as f:
                f.write("=== 简化布局版管道高程调整汇总报告 ===\n\n")
                
                f.write(f"总管道数量: {len(self.pipes)}\n")
                f.write(f"完整路径数量: {len(self.all_paths)}\n\n")
                
                # 统计调整情况
                adjusted_pipes = 0
                total_inlet_change = 0
                total_outlet_change = 0
                
                for pipe in self.pipes:
                    inlet_change = abs(pipe['current_inlet'] - pipe['original_inlet'])
                    outlet_change = abs(pipe['current_outlet'] - pipe['original_outlet'])
                    
                    if inlet_change > 0.01 or outlet_change > 0.01:
                        adjusted_pipes += 1
                        total_inlet_change += inlet_change
                        total_outlet_change += outlet_change
                
                f.write(f"调整的管道数量: {adjusted_pipes}\n")
                if adjusted_pipes > 0:
                    f.write(f"平均入口高程调整量: {total_inlet_change/adjusted_pipes:.3f} m\n")
                    f.write(f"平均出口高程调整量: {total_outlet_change/adjusted_pipes:.3f} m\n\n")
                
                # 详细路径信息
                f.write("=== 各路径详细信息 ===\n\n")
                for i, path in enumerate(self.all_paths):
                    if not path:
                        continue
                        
                    path_name = f"{path[0]['start_node']}-{path[-1]['end_node']}"
                    f.write(f"路径 {i+1}: {path_name}\n")
                    f.write(f"  包含管道数量: {len(path)}\n")
                    f.write(f"  管道ID序列: {[pipe['pipe_id'] for pipe in path]}\n")
                    f.write(f"  节点序列: {[pipe['start_node'] for pipe in path] + [path[-1]['end_node']]}\n")
                    
                    # 计算路径的总高程变化
                    start_elev_current = path[0]['current_inlet']
                    end_elev_current = path[-1]['current_outlet']
                    total_drop_current = start_elev_current - end_elev_current
                    
                    start_elev_original = path[0]['original_inlet']
                    end_elev_original = path[-1]['original_outlet']
                    total_drop_original = start_elev_original - end_elev_original
                    
                    f.write(f"  总高程降落 - 调整前: {total_drop_original:.3f} m, 调整后: {total_drop_current:.3f} m\n")
                    f.write(f"  高程降落变化: {total_drop_current - total_drop_original:.3f} m\n")
                    
                    # 检查路径中的问题
                    problems = []
                    for pipe in path:
                        if pipe['current_inlet'] < pipe['current_outlet']:
                            problems.append(f"管道{pipe['pipe_id']}逆流")
                    
                    if problems:
                        f.write(f"  发现问题: {', '.join(problems)}\n")
                    
                    f.write("\n")
            
            print(f"汇总报告已保存: {report_path}")
            
        except Exception as e:
            print(f"生成汇总报告时出错: {e}")

# 功能封装函数
def pipe_elevation_visualizer_compact(file_path):
    if not os.path.exists(file_path):
        print("文件不存在，请检查路径")
        return
    filename = os.path.basename(file_path)
    file_name_without_extension = os.path.splitext(filename)[0]
    # 创建可视化工具
    visualizer = PipeElevationVisualizerCompact()
    
    # 加载数据
    print("正在加载数据...")
    visualizer.load_data_from_excel(file_path)
    
    if not visualizer.pipes:
        print("未找到有效的管道数据")
        return
    
    # 识别所有完整路径
    print("正在识别完整路径...")
    visualizer.find_all_paths()
    
    if not visualizer.all_paths:
        print("未找到有效的完整路径")
        return
    
    # 创建输出文件夹
    base_path = os.path.dirname(file_path)
    # output_folder = os.path.join(base_path, "pipe_elevation_charts")
    output_folder = os.path.join(base_path,file_name_without_extension)
    
    # 生成图表
    print("正在生成高程对比图表...")
    visualizer.create_elevation_charts(output_folder)
    
    # 生成汇总报告
    print("正在生成汇总报告...")
    visualizer.generate_summary_report(output_folder)
    
    print(f"\n所有图表和报告已保存到: {output_folder}")
    print("程序执行完成！")

def main():
    """主函数"""
    # 获取输入文件路径
    file_path = input("请输入Excel文件路径: ").strip()
    
    if not os.path.exists(file_path):
        print("文件不存在，请检查路径")
        return
    filename = os.path.basename(file_path)
    file_name_without_extension = os.path.splitext(filename)[0]
    # 创建可视化工具
    visualizer = PipeElevationVisualizerCompact()
    
    # 加载数据
    print("正在加载数据...")
    visualizer.load_data_from_excel(file_path)
    
    if not visualizer.pipes:
        print("未找到有效的管道数据")
        return
    
    # 识别所有完整路径
    print("正在识别完整路径...")
    visualizer.find_all_paths()
    
    if not visualizer.all_paths:
        print("未找到有效的完整路径")
        return
    
    # 创建输出文件夹
    base_path = os.path.dirname(file_path)
    # output_folder = os.path.join(base_path, "pipe_elevation_charts")
    output_folder = os.path.join(base_path,file_name_without_extension)
    
    # 生成图表
    print("正在生成高程对比图表...")
    visualizer.create_elevation_charts(output_folder)
    
    # 生成汇总报告
    print("正在生成汇总报告...")
    visualizer.generate_summary_report(output_folder)
    
    print(f"\n所有图表和报告已保存到: {output_folder}")
    print("程序执行完成！")

if __name__ == "__main__":
    main()
