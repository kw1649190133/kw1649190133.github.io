﻿# python 3
# 20250630
# 1.完成核心函数，字段名匹配机制
# 2.文件读取函数

# 20250701
# 1.转为python3环境，使用openpyxl重构文件读写，替换xlrd
# 2.完善检测逻辑，核对数据条目，对齐行列

# 20250702
# 1.去重算法 【完成】
# 2.自动表格修整（文字大小、居中、表格框线）。【完成】
# 3.自动公式填写【完成】
# 4.完善了数据检索机制，使用down标签确保没有遗漏或重复数据。

# 20250703
# 1.更改匹配机制，改为以施工成果表为准，匹配设计数据。
# 2.设计数据的自动读取和整理机制
# 3.添加W表和Y表是否存在的检测

# 20250715
# 1.有的表簿没有Y表，添加一个表格是否存在的检测机制【完成】
# 2.设计数据和实际数据都有带横线和不带横线两种情况，添加一个自动检测机制
# 3.制作简单启动界面，通过按钮和文件选择框来选择对应的文件。
# 4.添加异常处理机制，让程序不会崩溃。

import openpyxl
import re
import math
import os
from openpyxl.styles import Font, Alignment, Border, Side

# 字符串清理空格
def strc(s):
    if not isinstance(s, str) or not s:
        return s
    return s.replace(" ","")

# 字符串比较不区分大小写
def strcompare_lower(a,b):
    if strc(a).lower() ==strc(b).lower():
        return 1
    else:
        return 0
    
# 字符串比较区分大小写
def strcompare(a,b):
    if strc(a) ==strc(b):
        return 1
    else:
        return 0

# 添加横杠
def adddash(s):
    if not isinstance(s, str) or not s:
        return s
    if s[0].isdigit():
        return s
    match = re.search(r'\d', s)
    if match:
        # 在第一个数字前插入'-'
        pos = match.start()
        return s[:pos] + '-' + s[pos:]
# 如果没有找到数字，原样返回
    return s
    #return re.sub(r'(\d+)',r'-\1',s,count=1)

def remove_first_hyphen_before_digits(sheet):
    """
    处理表格中的ID字段：移除第一次出现数字之前的第一个横杠
    
    参数:
    sheet: openpyxl Worksheet对象
    
    返回:
    处理后的Worksheet对象
    """
    # 定义检测和处理的函数
    def process_id(id_str):
        """
        处理单个ID字符串：只移除第一个数字前的第一个横杠
        """
        if not isinstance(id_str, str) or not id_str:
            return id_str
        
        # 查找第一个数字的位置
        match = re.search(r'\d', id_str)
        if not match:
            return id_str  # 没有数字，直接返回
        
        first_digit_pos = match.start()
        
        # 在数字前部分查找第一个横杠的位置
        prefix = id_str[:first_digit_pos]
        hyphen_pos = prefix.find('-')
        
        # 如果找到横杠，只移除第一个横杠
        if hyphen_pos != -1:
            # 构建新字符串：横杠前部分 + 横杠后部分 + 数字及之后部分
            new_prefix = prefix[:hyphen_pos] + prefix[hyphen_pos+1:]
            return new_prefix + id_str[first_digit_pos:]
        
        return id_str
    
    # 处理B列（第二列）的所有单元格
    for row in range(2, sheet.max_row + 1):  # 从第二行开始
        cell = sheet.cell(row=row, column=2)  # 第二列是B列
        
        # 处理当前单元格的ID
        original_id = cell.value
        processed_id = process_id(original_id)
        
        # 如果ID有变化，更新单元格值
        if original_id != processed_id:
            cell.value = processed_id
            print(f"行 {row}: '{original_id}' -> '{processed_id}'")
    
    return sheet

# 坐标比较,误差小于d返回正确
def xycompare(dy,dx,ry,rx,d):
    if math.sqrt((float(dy)-float(ry))**2+(float(dx)-float(rx))**2)<d:
        return 1
    else :return 0

# 检查测量成果是否重复
def dataisonly(unique_id, y_str, x_str, data_array):
    for item in data_array:
        if ((item[0]) == unique_id and (item[1]) == y_str and (item[2]) == x_str ):
            return 0
    # 如果未发现重复，则返回1
    return 1

# 自动填公式
def fill_conditional_formulas(sheet):
    """
    智能填充公式（仅当引用单元格非空时）：
    - M列：计算二维距离 =((I-D)^2+(H-C)^2)^0.5
    - N列：计算差值 =J-E
    - O列：计算差值 =K-F
    - P列：计算差值 =L-G
    
    参数:
    sheet: openpyxl的Worksheet对象
    """
    # 列字母到索引的映射（A=1, B=2,...）
    col_map = {'C':3, 'D':4, 'E':5, 'F':6, 'G':7, 
               'H':8, 'I':9, 'J':10, 'K':11, 'L':12}
    
    for row in range(3, sheet.max_row + 1):
        # 检查M列公式所需单元格是否非空
        if (sheet.cell(row=row, column=col_map['I']).value is not None and \
           sheet.cell(row=row, column=col_map['D']).value is not None and \
           sheet.cell(row=row, column=col_map['H']).value is not None and \
           sheet.cell(row=row, column=col_map['C']).value is not None):         
            sheet[f'M{row}'] = f"=round(((I{row}-D{row})^2+(H{row}-C{row})^2)^0.5,3)"
        # 检查N列公式所需单元格
        if (sheet.cell(row=row, column=col_map['J']).value is not None and \
           sheet.cell(row=row, column=col_map['E']).value is not None):
            
            sheet[f'N{row}'] = f"=J{row}-E{row}"   
        # 检查O列公式所需单元格
        if (sheet.cell(row=row, column=col_map['K']).value is not None and \
           sheet.cell(row=row, column=col_map['F']).value is not None):
            
            sheet[f'O{row}'] = f"=K{row}-F{row}"
        # 检查P列公式所需单元格
        if (sheet.cell(row=row, column=col_map['L']).value is not None and \
           sheet.cell(row=row, column=col_map['G']).value is not None):
            
            sheet[f'P{row}'] = f"=L{row}-G{row}"
    return sheet

# 表格美化
def format_sheet(sheet):
    """
    统一格式化工作表：
    1. 字体：Calibri 10
    2. 对齐：上下左右居中
    3. 边框：A-P列，从第1行到最后一行添加线框
    
    参数:
    sheet: openpyxl的Worksheet对象
    
    返回:
    格式化后的Worksheet对象
    """
    # 定义字体样式
    font = Font(name='Calibri', size=10)
    
    # 定义对齐样式
    alignment = Alignment(horizontal='center', vertical='center')
    
    # 定义边框样式（细线）
    thin_border = Border(
        left=Side(style='thin'),
        right=Side(style='thin'),
        top=Side(style='thin'),
        bottom=Side(style='thin')
    )
    
    # 获取工作表的最大行数
    max_row = sheet.max_row
    
    # 遍历A-P列，从第1行到最后一行
    for row in sheet.iter_rows(min_row=1, max_row=max_row, 
                              min_col=1, max_col=16):  # A=1, P=16
        for cell in row:
            # 应用字体
            cell.font = font  
            # 应用对齐
            cell.alignment = alignment        
            # 应用边框
            cell.border = thin_border

    # 遍历R-S列，从第1行到最后一行
    for row in sheet.iter_rows(min_row=2, max_row=max_row, 
                              min_col=18, max_col=19):  # A=1, P=16
        for cell in row:
            # 应用字体
            cell.font = font
            # 应用对齐
            cell.alignment = alignment
            # 应用边框
            cell.border = thin_border    
    
    return sheet

def biaogaobuquan(sheet):
    if sheet[f"E{2}"].value is None:
        for i in range(2,sheet.max_row+1):
            biaogao=float(sheet[f"F{i}"].value)+float(sheet[f"G{i}"].value)
            sheet[f"E{i}"].value=str(round(biaogao,3))
    return sheet

# 输入对比表、设计数据
def sheet_link(sheet_com,sheet_des):
    remove_first_hyphen_before_digits(sheet_des)
    # 补全标高
    sheet_des = biaogaobuquan(sheet_des)
    # 记录初始的行数，用于后面添加数据
    row0 = sheet_com.max_row
    print("原始数据行数 row0 = " + str(row0))
#设计已有的进行匹配
    print('_______________施工与设计匹配________________')
    count_des = 0 # 统计设计已有的匹配数据

    # 因为在导入施工数据时做过了去重，这里不考虑重复问题。
    #print("com起始检查 —— "+ sheet_com[f'B{3}'].value)
    for i in range(3,sheet_com.max_row+1):
        sheet_com[f'A{i}'].value = str(i-2) #序号   
        for j in range(2,sheet_des.max_row+1):
            #进行名称核对，当名称相同时,且坐标一致，执行赋值
            # 有的加横杠有的又不加
            aid=sheet_com[f'B{i}'].value
            #aid=adddash(sheet_com[f'B{i}'].value)          
            bid=sheet_des[f'B{j}'].value
            #bid=adddash(sheet_des[f'B{j}'].value)
            # 检测编号和坐标是否一致
            if strcompare_lower(aid,bid):
                # 检测该数据是否已经被标记。
                if (sheet_des[f'T{j}'].value != 'down'):
                    count_des+=1 #计数器+1
                    # 横坐标Y 纵坐标X 井面高 井底高 计算井深 （补充一个井底标高）
                    sheet_com[f'C{i}'].value = sheet_des[f'C{j}'].value #横坐标Y
                    sheet_com[f'D{i}'].value = sheet_des[f'D{j}'].value #纵坐标X
                    sheet_com[f'E{i}'].value = sheet_des[f'E{j}'].value #井面标高
                    sheet_com[f'F{i}'].value = sheet_des[f'F{j}'].value #管底标高
                    sheet_com[f'G{i}'].value = sheet_des[f'G{j}'].value #井深
                    sheet_com[f'R{i}'].value = sheet_des[f'H{j}'].value #设计节点类型
                    #sheet_com[f'T{i}'].value = sheet_m[f'B{j}'].value #核对井编号用的，不用的时候注释掉
                    #对使用过的数据进行标记，避免下一次调用
                    sheet_des[f'T{j}'].value = 'down'
            # 当名称大小写不同，但是坐标一致时
            #if strcompare_lower(aid,bid) and xycompare(sheet_com[f'C{i}'].value,sheet_com[f'D{i}'].value,sheet_m[f'G{j}'].value,sheet_m[f'F{j}'].value,1):
                #print("大小写不同但坐标相似")
    #剩下名称不匹配的，追加到表格末端
    print("添加已匹配的数据： " + str(count_des) + " 条记录")
    print('_______________设计没有但实际存在的________________')
    count_des_rest = 0 #统计设计剩下的
    #将指针指向原数据的末行
    row=row0+1
    #print("m起始检查 —— "+ sheet_m[f'B{6}'].value)

    # 循环一遍设计表，将未标记的数据添加到末尾
    for j in range(2,sheet_des.max_row+1):
        # 检测该数据是否在前面的匹配中使用过。
        if sheet_des[f'T{j}'].value != 'down':
        # 检测是否重复，未发现重复则进行下一步比较
            # 开始赋值
            # 序号，名称
            sheet_com[f'A{row}'].value = row-2 #序号
            sheet_com[f'B{row}'].value = sheet_des[f'B{j}'].value #井名称

            # 横坐标Y 纵坐标X 井面高 井底高 计算井深 （补充一个井底标高）
            sheet_com[f'C{row}'].value = sheet_des[f'C{j}'].value #横坐标Y
            sheet_com[f'D{row}'].value = sheet_des[f'D{j}'].value #纵坐标X
            sheet_com[f'E{row}'].value = sheet_des[f'E{j}'].value #井面标高
            sheet_com[f'F{row}'].value = sheet_des[f'F{j}'].value #管底标高
            sheet_com[f'G{row}'].value = sheet_des[f'G{j}'].value #井深
            sheet_com[f'R{i}'].value = sheet_des[f'H{j}'].value #设计节点类型
            count_des_rest+=1 #计数器+1
            row+=1 #指针+1        
        
    print("添加未匹配的数据： " + str(count_des_rest) + " 条记录")      
    return sheet_com

# 封装函数
def generate_comparison_table(input_path1,input_path2,output_path=None):
    # 读取文件
    workbook1 = openpyxl.load_workbook(input_path1)
    workbook2 = openpyxl.load_workbook(input_path2)
    # 表格1是对比表,表2是设计表
    output_path=None
    # 自动决定输出文件名
    if not output_path:
        if input_path1.endswith('.xlsx'):
            output_path = input_path1.replace('.xlsx', '_processed.xlsx')
        else:
            output_path = input_path1 + '_processed.xlsx'
    # 获取设计表的表名，检查W和Y是否存在
    sheet_names2 = workbook2.sheetnames
    print(sheet_names2)

    sheet1w = workbook1["W"] # 按名称获取
    sheet1y = workbook1["Y"] # 按名称获取

    if "W" in sheet_names2 :
        print('__Loading W sheet__')
        sheet2w = workbook2["W"] # 按名称获取
        #数据处理
        sheet1w=sheet_link(sheet1w,sheet2w)
        # 自动填写公式
        sheet1w=fill_conditional_formulas(sheet1w)
        print("W表自动公式填写完成")        
    else:
        print("设计数据未找到W表")
    # 表格美化
    sheet1w=format_sheet(sheet1w)
    print("W表格美化完成")
    if "Y" in sheet_names2 :
        print('__Loading Y sheet__')
        sheet2y = workbook2["Y"] # 按名称获取
        #数据处理
        sheet1y=sheet_link(sheet1y,sheet2y)
        # 自动填写公式
        sheet1y=fill_conditional_formulas(sheet1y)
        print("Y表自动公式填写完成")
    else :
        print("设计数据未找到Y表")
    sheet1y=format_sheet(sheet1y)
    print("Y表格美化完成")
    # 保存结果
    workbook1.save(output_path)
    print("———————————分割线———————————")
    print(f"处理完成！结果已保存到: {output_path}")

if __name__ == "__main__":
    try:
        #输入和输出（对比表，设计数据）
        input_path1 = input("输入对比表路径: ").strip()
        if not os.path.exists(input_path1):
            print("路径错误，请检查路径")
        input_path2 = input("输入设计表路径: ").strip()
        if not os.path.exists(input_path2):
            print("路径错误，请检查路径")
        output_path=None
        # 自动决定输出文件名
        if not output_path:
            if input_path1.endswith('.xlsx'):
                output_path = input_path1.replace('.xlsx', '_processed.xlsx')
            else:
                output_path = input_path1 + '_processed.xlsx'
        # 读取文件
        workbook1 = openpyxl.load_workbook(input_path1)
        workbook2 = openpyxl.load_workbook(input_path2)
        # 表格1是对比表,表2是设计表

        # 获取设计表的表名，检查W和Y是否存在
        sheet_names2 = workbook2.sheetnames
        print(sheet_names2)

        sheet1w = workbook1["W"] # 按名称获取
        sheet1y = workbook1["Y"] # 按名称获取

        if "W" in sheet_names2 :
            print('__Loading W sheet__')
            sheet2w = workbook2["W"] # 按名称获取
            #数据处理
            sheet1w=sheet_link(sheet1w,sheet2w)
            # 自动填写公式
            sheet1w=fill_conditional_formulas(sheet1w)
            print("W表自动公式填写完成")     
        else:
            print("设计数据未找到W表")
        # 表格美化
        sheet1w=format_sheet(sheet1w)
        print("W表格美化完成")

        if "Y" in sheet_names2 :
            print('__Loading Y sheet__')
            sheet2y = workbook2["Y"] # 按名称获取
            #数据处理
            sheet1y=sheet_link(sheet1y,sheet2y)
            # 自动填写公式
            sheet1y=fill_conditional_formulas(sheet1y)
            print("Y表自动公式填写完成")
        else :
            print("设计数据未找到Y表")

        sheet1y=format_sheet(sheet1y)
        print("Y表格美化完成")

        # 保存结果
        workbook1.save(output_path)
        print("———————————分割线———————————")
        print(f"处理完成！结果已保存到: {output_path}")
    except Exception as e:
        print(f"错误: {str(e)}")
