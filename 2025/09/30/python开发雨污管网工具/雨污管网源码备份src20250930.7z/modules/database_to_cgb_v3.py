# csv和xls中读取数据，生成成果表。
# 20250711  实现成果表自动生成
# 20250712  读取CSV文件时会遇到问题，加入自动编码检测机制
import os
import openpyxl
from records import Database
import re
from openpyxl import load_workbook
from openpyxl import Workbook
import pandas as pd
from typing import List, Tuple
import csv
import math
from openpyxl.styles import Font, Alignment, Border, Side
import chardet
import logging
from typing import List, Tuple, Optional

# 获取白名单
def baimingdan_get(text_file_path):
        # 添加标题行
        # 创建DataFrame
    wb = Workbook()
    sheet = wb.active
    sheet.title = "白名单"
    sheet.append(["井1", "流向井2", "数值"])

    data = [["井1", "流向井2", "数值"]]

    # 正则表达式匹配模式
    pattern = r'(.+?)-->(.+?):.+?(\d+)'
    # 行计数器
    row_count = 1  # 标题行已占用第1行  
    with open(text_file_path, 'r') as file:
        for line in file:
            line = line.strip()
            if not line:
                continue          
            # 匹配数据
            match = re.search(pattern, line)
            if match:
                well1, well2, value = match.groups()
                data['井1'].append(well1.strip())
                data['流向井2'].append(well2.strip())
                data['数值'].append(int(value))
                #well1, well2, value = match.groups()
                # 写入工作表
                row_count += 1
                #sheet.append([well1.strip(), well2.strip(), int(value)])
    
    
    print(data)
    for row in data:
        print (row)
    return sheet

# 设置日志
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def detect_file_encoding(file_path: str, sample_size: int = 4096) -> Optional[str]:
    """
    检测文件的编码格式
    
    参数:
        file_path (str): 文件路径
        sample_size (int): 用于检测的样本大小（字节）
    
    返回:
        str: 检测到的编码格式，如果失败则返回 None
    """
    try:
        with open(file_path, 'rb') as f:
            raw_data = f.read(sample_size)
            result = chardet.detect(raw_data)
            
            confidence = result.get('confidence', 0)
            encoding = result.get('encoding', None)
            
            if encoding and confidence > 0.5:
                logger.info(f"检测到编码: {encoding} (置信度: {confidence:.2%})")
                return encoding.lower()
            
            logger.warning(f"编码检测置信度过低 ({confidence:.2%})，使用备选方案")
            return 'latin1'  # 最通用的备选编码
    
    except Exception as e:
        logger.error(f"检测文件编码时出错: {e}")
        return None

def read_points_from_csv(csv_path: str) -> List[Tuple[str, float, float, float]]:
    """
    从 CSV 文件读取点数据，自动处理编码和 BOM
    
    参数:
        csv_path (str): CSV 文件路径
        
    返回:
        List[Tuple[str, float, float, float]]: 点数据数组
    """
    if not os.path.exists(csv_path):
        raise FileNotFoundError(f"CSV 文件不存在: {csv_path}")
    
    # 1. 检测文件编码
    detected_encoding = detect_file_encoding(csv_path)
    
    # 优先使用检测到的编码，否则尝试常见编码
    encodings_to_try = []
    if detected_encoding:
        encodings_to_try.append(detected_encoding)
    
    # 添加常见编码（特别是中文环境）
    encodings_to_try.extend([
        'gbk',          # 中文简体 (Windows)
        'gb2312',       # 中文简体 (较旧系统)
        'big5',         # 中文繁体
        'utf-8-sig',    # 带 BOM 的 UTF-8
        'utf-8',        # 标准 UTF-8
        'latin1',       # ISO-8859-1 (通用备选)
        'cp1252',       # Windows 西欧编码
    ])
    
    # 移除重复项
    encodings_to_try = list(dict.fromkeys(encodings_to_try))
    
    points_data = []
    successful_read = False
    
    # 2. 尝试不同编码打开文件
    for encoding in encodings_to_try:
        try:
            logger.info(f"尝试使用编码: {encoding}")
            with open(csv_path, mode='r', newline='', encoding=encoding) as csv_file:
                # 检查 BOM (仅对 UTF 编码)
                if encoding.startswith('utf'):
                    bom_char = '\ufeff'
                    first_char = csv_file.read(1)
                    if first_char == bom_char:
                        logger.info("检测到 BOM，已跳过")
                    else:
                        # 如果不是 BOM，回退到文件开头
                        csv_file.seek(0)
                
                csv_reader = csv.reader(csv_file)
                points_data = []  # 重置数据
                
                for row_idx, row in enumerate(csv_reader, start=1):
                    if not row:
                        continue
                    
                    # 处理第一行可能的 BOM 残留
                    if row_idx == 1 and row and row[0].startswith('\ufeff'):
                        row[0] = row[0].lstrip('\ufeff')
                    
                    if len(row) < 5:
                        logger.warning(f"第 {row_idx} 行列数不足(需要5列，实际{len(row)}列)，已跳过")
                        continue
                    
                    try:
                        point_name = row[0].strip()
                        y_coord = float(row[2])
                        x_coord = float(row[3])
                        elevation = float(row[4])
                        
                        points_data.append((point_name, y_coord, x_coord, elevation))
                    
                    except ValueError as e:
                        logger.warning(f"第 {row_idx} 行数据格式不正确 - {e}")
                        logger.debug(f"行内容: {row}")
                
                # 成功读取至少一行数据
                if points_data:
                    successful_read = True
                    logger.info(f"成功使用 {encoding} 编码读取 {len(points_data)} 行数据")
                    break
                
        except UnicodeDecodeError as ude:
            logger.warning(f"编码 {encoding} 失败: {ude}")
        except Exception as e:
            logger.error(f"使用编码 {encoding} 读取时出错: {e}")
    
    if not successful_read:
        raise RuntimeError("无法使用任何编码读取文件，请检查文件格式")
    
    return points_data

# 字符串清理空格
def strc(s):
    if not isinstance(s, str) or not s:
        return s
    return s.replace(" ","")
# 字符串比较不区分大小写
def strcompare_lower(a,b):
    if strc(a).lower() ==strc(b).lower():
        return 1
    else:
        return 0

# 坐标比较,误差小于d返回正确
def xy_to_dis(dy,dx,ry,rx):
    dis = math.sqrt((float(dy)-float(ry))**2+(float(dx)-float(rx))**2)
    return dis

def read_points_from_csv(csv_path: str) -> List[Tuple[str, str, str, str]]:
    """
    从 CSV 文件读取点数据并保存到数组中
    
    参数:
        csv_path (str): CSV 文件路径
        
    返回:
        List[Tuple[str, float, float, float]]: 
        包含点数据的数组，每个元素为 (点名称, y坐标, x坐标, 高程)
        
    文件格式要求:
        A列: 点名称 (字符串)
        B列: 空列 (忽略)
        C列: y坐标 (数值)
        D列: x坐标 (数值)
        E列: 高程 (数值)
    """
    # 检查文件是否存在
    if not os.path.exists(csv_path):
        raise FileNotFoundError(f"CSV 文件不存在: {csv_path}")
    
    # 确保是 CSV 文件
    if not csv_path.lower().endswith('.csv'):
        raise ValueError("文件必须是 CSV 格式")
    
    # 1. 检测文件编码
    detected_encoding = detect_file_encoding(csv_path)
    
    # 优先使用检测到的编码，否则尝试常见编码
    encodings_to_try = []
    if detected_encoding:
        encodings_to_try.append(detected_encoding)
    
    # 添加常见编码（特别是中文环境）
    encodings_to_try.extend([
        'gbk',          # 中文简体 (Windows)
        'gb2312',       # 中文简体 (较旧系统)
        'big5',         # 中文繁体
        'utf-8-sig',    # 带 BOM 的 UTF-8
        'utf-8',        # 标准 UTF-8
        'latin1',       # ISO-8859-1 (通用备选)
        'cp1252',       # Windows 西欧编码
    ])
    
    # 移除重复项
    encodings_to_try = list(dict.fromkeys(encodings_to_try))

    successful_read = False
    
    points_data = []  # 存储点数据的数组
    for encoding in encodings_to_try:
        try:
            logger.info(f"尝试使用编码: {encoding}")
            with open(csv_path, mode='r', newline='', encoding=encoding) as csv_file:
                csv_reader = csv.reader(csv_file)
                
                # 跳过空行和标题行（如果需要）
                # 这里假设第一行是数据，如果第一行是标题，请取消注释下面两行
                # headers = next(csv_reader)  # 跳过标题行
                # print(f"标题行: {headers}")
                
                for row_idx, row in enumerate(csv_reader, start=1):
                    # 跳过空行
                    if not row:
                        continue
                    
                    # 检查列数是否足够
                    if len(row) < 5:
                        print(f"警告: 第 {row_idx} 行列数不足(需要5列，实际{len(row)}列)，已跳过")
                        continue
                    
                    try:
                        # 解析各列数据
                        point_name = row[0].strip()  # A列: 点名称
                        # B列为空，跳过
                        y_coord = (row[2])      # C列: y坐标
                        x_coord = (row[3])      # D列: x坐标
                        elevation = (row[4])    # E列: 高程
                        
                        # 添加到数组
                        points_data.append((point_name, y_coord, x_coord, elevation))
                        
                    except ValueError as e:
                        print(f"错误: 第 {row_idx} 行数据格式不正确 - {e}")
                        print(f"行内容: {row}")
            # 成功读取至少一行数据
                if points_data:
                    successful_read = True
                    logger.info(f"成功使用 {encoding} 编码读取 {len(points_data)} 行数据")
                    break   
        except UnicodeDecodeError as ude:
            logger.warning(f"编码 {encoding} 失败: {ude}")
        except Exception as e:
            logger.error(f"使用编码 {encoding} 读取时出错: {e}")
    if not successful_read:
        raise RuntimeError("无法使用任何编码读取文件，请检查文件格式")
    return points_data

# 数据库到成果表
def copy_df_to_existing_sheet(sheet,df, start_row=6):

    # 定义列映射关系 (源列索引 -> 目标列字母)
    # 注意: Pandas 列索引从0开始
    column_mapping = {
        1: 'B',  # df_w B列 (索引1) -> sheet B列
        2: 'C',  # df_w C列 (索引2) -> sheet C列
        3: 'M',  # df_w D列 (索引3) -> sheet M列
        5: 'L',  # df_w F列 (索引5) -> sheet L列
        10: 'N', # df_w K列 (索引10) -> sheet N列
        11: 'D', # df_w L列 (索引11) -> sheet D列
        12: 'E', # df_w M列 (索引12) -> sheet E列
        13: 'K', # df_w N列 (索引13) -> sheet K列
        14: 'X', # df_w O列 (索引14) -> sheet X列
        20: 'Z', # df_w U列 (索引20) -> sheet Z列
        21: 'AM',# df_w V列 (索引21) -> sheet AM列
        22: 'AN' # df_w W列 (索引22) -> sheet AN列
    }
    
    # 验证 df_w 是否有足够的列
    max_col_index = max(column_mapping.keys())
    print ("当前DF表列数：" + str(max_col_index))
    #if len(df.columns) <= max_col_index:
        #print(f"错误: df_w 只有 {len(df.columns)} 列，但需要至少 {max_col_index+1} 列")
        #return
    
    # 遍历 df_w 的每一行
    for row_idx, (_, row) in enumerate(df.iloc[1:].iterrows()):
        # 计算目标行号 (从 start_row 开始)
        target_row = start_row + row_idx
        # 遍历映射关系并写入数据
        for src_col_idx, target_col in column_mapping.items():
            # 获取源列的值
            value = row.iloc[src_col_idx]
            # 写入目标单元格
            sheet[f"{target_col}{target_row}"] = value

    sheet[f"Z{5}"].value = "井深"
    return sheet

# 读取埋深表返回成果表。
def maishen_table_get(sheet_w,sheet_y,input_path_xls):

    df_w, df_y = read_W_Y_sheets(input_path_xls) # 读取xls格式的埋深表
    
    if df_w is not None:
        print("loading———W埋深表")
        sheet_w = copy_df_to_existing_sheet(sheet_w,df_w)
    else:
        print(" W 表不存在")
    
    if df_y is not None:
        print("loading———Y埋深表")
        sheet_y = copy_df_to_existing_sheet(sheet_y,df_y)
    else:
        print(" Y 表不存在")

    return sheet_w,sheet_y

# 从xls数据库表获取数据
def read_W_Y_sheets(excel_path, sheet_name_w="W", sheet_name_y="Y"):
    """
    从 Excel 文件中读取 W 表和 Y 表，并返回两个 DataFrame。
    
    参数:
        excel_path (str): Excel 文件路径（.xls 或 .xlsx）。
        sheet_name_w (str): W 表的 Sheet 名称，默认为 "W"。
        sheet_name_y (str): Y 表的 Sheet 名称，默认为 "Y"。
    
    返回:
        tuple: (df_w, df_y)，分别为 W 表和 Y 表的 DataFrame。
        如果某个表不存在，对应的 DataFrame 为 None。
    
    异常:
        FileNotFoundError: 文件路径错误时抛出。
    """
    try:
        # 读取 Excel 文件的所有 Sheet 名称
        sheets = pd.ExcelFile(excel_path).sheet_names
        
        # 检查 W 表和 Y 表是否存在
        w_exists = sheet_name_w in sheets
        y_exists = sheet_name_y in sheets
        
        # 读取 W 表（如果存在）
        df_w = pd.read_excel(excel_path, sheet_name=sheet_name_w) if w_exists else None
        
        # 读取 Y 表（如果存在）
        df_y = pd.read_excel(excel_path, sheet_name=sheet_name_y) if y_exists else None
        
        return df_w, df_y
    
    except FileNotFoundError:
        raise FileNotFoundError(f"文件 {excel_path} 不存在，请检查路径！")
    except Exception as e:
        raise Exception(f"读取 Excel 文件时出错: {e}")
    
    return

def csv_to_sheet(sheet,xydata):
    for i in range(6,sheet.max_row+1):
        jingname = sheet[f'B{i}'].value
        yesfind = 0
        for j, point in enumerate(xydata[:], start=0):
            if strcompare_lower(jingname,point[0]):
                yesfind = 1
                sheet[f'G{i}'] = point[1]
                sheet[f'F{i}'] = point[2]
                sheet[f'H{i}'] = point[3]
                break
        if yesfind == 0 :
            print("【异常】：未找到该名称坐标数据 ：" + jingname)
    return sheet

def lxjgd_and_guanchang_get(sheet):
    for i in range(6,sheet.max_row+1):
        # C列不为空必有流向管底
        lxjing = sheet[f"C{i}"].value
        if lxjing is not None:
            gd = float(sheet[f'J{i}'].value) # 管底标高
            lxmaishen = float(sheet[f'X{i}'].value) # 流向埋深
            for j in range(6,sheet.max_row+1):
                jing = sheet[f"B{j}"].value
                if (jing == lxjing):
                    lxgd = round(float(sheet[f'H{j}'].value) - lxmaishen,3)
                    sheet[f'O{i}'].value = lxgd

                    lxjing_x = sheet[f'F{i}'].value
                    lxjing_y = sheet[f'G{i}'].value
                    jing_x = sheet[f'F{j}'].value
                    jing_y = sheet[f'G{j}'].value
                    guanchang = round(xy_to_dis(lxjing_x,lxjing_y,jing_x,jing_y),3)
                    sheet[f'Q{i}'].value = guanchang
                    break 
                
    return sheet

# 表格美化
def format_sheet(sheet):
    """
    统一格式化工作表：
    1. 字体：Calibri 10
    2. 对齐：上下左右居中
    3. 边框：A-P列，从第1行到最后一行添加线框
    
    参数:
    sheet: openpyxl的Worksheet对象
    
    返回:
    格式化后的Worksheet对象
    """
    # 定义字体样式
    font = Font(name='Calibri', size=10)
    
    # 定义对齐样式
    alignment = Alignment(horizontal='center', vertical='center')
    
    # 定义边框样式（细线）
    thin_border = Border(
        left=Side(style='thin'),
        right=Side(style='thin'),
        top=Side(style='thin'),
        bottom=Side(style='thin')
    )
    
    # 获取工作表的最大行数
    max_row = sheet.max_row
    
    # 遍历A-P列，从第1行到最后一行
    for row in sheet.iter_rows(min_row=6, max_row=max_row, 
                              min_col=1, max_col=18):  # A=1, P=16
        for cell in row:
            # 应用字体
            cell.font = font  
            # 应用对齐
            cell.alignment = alignment        
            # 应用边框
            cell.border = thin_border
    return sheet

def make_cgb(sheet,xydata):
    if sheet[f'B{6}'].value is None:
        print (sheet.title + "表格为空")
        return sheet
    else :
        sheet = csv_to_sheet(sheet,xydata) # 加载坐标数据
        for i in range(6,sheet.max_row+1):
            jingmian = float(sheet[f'H{i}'].value)
            jingshen = float(sheet[f'Z{i}'].value)
            jingdi = round(jingmian - jingshen,3)
            guandi = float(sheet[f'H{i}'].value) - float(sheet[f'K{i}'].value)
            sheet[f'A{i}'].value = i - 5 # 序号
            sheet[f'I{i}'].value = jingdi
            sheet[f'J{i}'].value = guandi
            # 流向管底和管长需要通过专门的函数进行更新。
            #sheet[f'O{i}'].value = lxguandi
            #sheet[f'Q{i}'].value = guanchang
        sheet = lxjgd_and_guanchang_get(sheet)
        print("已回填坐标表")
        # 表格美化
        sheet=format_sheet(sheet)
        print("W表格美化完成")
    return sheet

# 功能封装，便于调用
def database_to_cgb(input_path_xls,input_path_csv,output_template,output_path = None):
    if not output_path:
        if input_path_xls.endswith('.xls'):
            output_path = input_path_xls.replace('.xls', '__成果表.xlsx')
        else:
            output_path = input_path_xls + '_成果表.xlsx'
    # 读取文件
    workbook_cgb = openpyxl.load_workbook(output_template)
    sheet_w = workbook_cgb["W"] # 按名称获取
    sheet_y = workbook_cgb["Y"] # 按名称获取
    sheet_w,sheet_y = maishen_table_get(sheet_w,sheet_y,input_path_xls)
    xydata = read_points_from_csv(input_path_csv)
    sheet_w = make_cgb(sheet_w,xydata)
    sheet_y = make_cgb(sheet_y,xydata)
    workbook_cgb.save(output_path)
    print("———————————分割线———————————")
    print(f"处理完成！结果已保存到: {output_path}")

# 单独使用
if __name__ == "__main__":
    try:
        # 输入xls、csv、成果表模板
        input_path_xls = input("输入管线表路径: ").strip()
        if not os.path.exists(input_path_xls):
            print("路径错误，请检查路径")
        input_path_csv = input("输入井点表路径: ").strip()
        if not os.path.exists(input_path_csv):
            print("路径错误，请检查路径")
        output_template = input("输入成果表模板路径: ").strip()
        if not os.path.exists(output_template):
            print("路径错误，请检查路径")

        output_path = None
        if not output_path:
            if input_path_xls.endswith('.xls'):
                output_path = input_path_xls.replace('.xls', '__成果表.xlsx')
            else:
                output_path = input_path_xls + '_成果表.xlsx'
                
        # 读取文件
        workbook_cgb = openpyxl.load_workbook(output_template)
        sheet_w = workbook_cgb["W"] # 按名称获取
        sheet_y = workbook_cgb["Y"] # 按名称获取

        sheet_w,sheet_y = maishen_table_get(sheet_w,sheet_y,input_path_xls)
        xydata = read_points_from_csv(input_path_csv)
        
        sheet_w = make_cgb(sheet_w,xydata)
        sheet_y = make_cgb(sheet_y,xydata)

        # 保存结果
        workbook_cgb.save(output_path)
        print("———————————分割线———————————")
        print(f"处理完成！结果已保存到: {output_path}")
    except Exception as e:
        print(f"错误: {str(e)}")