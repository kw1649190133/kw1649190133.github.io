# 保留原始数据
# 20250714
# 将保存原始数据的函数从调坡比的程序中分离了出来，便于对比。

from openpyxl.styles import Font, Alignment, Border, Side
from openpyxl.utils import get_column_letter
import openpyxl
# 输入：管底标高、流向井管底、距离
def slope_ratio(gd,lxgd,d):

    depth_d = float(gd)-float(lxgd)  # 计算深度差
    pobi = depth_d / float(d)  # 计算坡度比
    return pobi
def red_mark(call):
    # 红色样式
    green_fill = openpyxl.styles.PatternFill(start_color="FF0000", end_color="FF0000", fill_type="solid")
    call.fill = green_fill
    return call
# 保存原始数据的函数
def save_data0(sheet):
    sheet[f'AA{5}'].value = "原井面"
    sheet[f'AB{5}'].value = "原井底"
    sheet[f'AC{5}'].value = "原管底"
    sheet[f'AD{5}'].value = "原埋深"
    sheet[f'AE{5}'].value = "原流向管底"
    sheet[f'S{5}'].value = "原始坡比"

    for j in range(6,sheet.max_row+1):
        sheet[f'AA{j}'].value = sheet[f'H{j}'].value # 井面
        sheet[f'AB{j}'].value = sheet[f'I{j}'].value # 井底
        if sheet[f'A{j}'].value is not None and sheet[f'J{j}'].value is not None and sheet[f'O{j}'].value is not None:
            gd = float(sheet[f'J{j}'].value) # 管底标高
            lxgd = float(sheet[f'O{j}'].value) # 流向井管底标高
            glength = float(sheet[f'Q{j}'].value) # 管长
            pobi = round(slope_ratio(gd, lxgd, glength), 4) # 计算坡比 (用流向高程算)
            
            sheet[f'AC{j}'].value = sheet[f'J{j}'].value
            sheet[f'AD{j}'].value = sheet[f'K{j}'].value
            sheet[f'AE{j}'].value = sheet[f'O{j}'].value
            sheet[f'S{j}'].value = pobi
            if(pobi<0):
                red_mark(sheet[f'S{j}'])
    return sheet

def save_in_workbook(workbook1):
    # 获取设计表的表名，检查W和Y是否存在
    sheet_names1 = workbook1.sheetnames

    if "W" in sheet_names1 :
        print('__Loading W sheet__')
        # 表格1是对比表,表2是测量成果
        sheet1w = workbook1["W"] # 按名称获取
        #数据处理
        sheet1w=save_data0(sheet1w)
    else:
        print("未找到W表")

    if "Y" in sheet_names1 :
        print('__Loading Y sheet__')
        sheet1y = workbook1["Y"] # 按名称获取
        #数据处理
        sheet1y=save_data0(sheet1y)
    else:
        print("未找到Y表")
    return workbook1

# 程序封装
def save_original_data(input_path1):
    try:
            # 读取文件
        workbook1 = openpyxl.load_workbook(input_path1)
        workbook1 = save_in_workbook(workbook1) 
        # 保存结果
        workbook1.save(input_path1)
        print("———————————分割线———————————")
        print(f"处理完成！结果已保存到: {input_path1}")
    except Exception as e:
        return f"错误：{str(e)}"

if __name__ == "__main__":
    try:
        #输入和输出（成果表）
        input_path1 = input("请输入施工成果表文件路径(.xlsx): ").strip()
            # 读取文件
        workbook1 = openpyxl.load_workbook(input_path1)
        workbook1 = save_in_workbook(workbook1) 
        # 保存结果
        workbook1.save(input_path1)
        print("———————————分割线———————————")
        print(f"处理完成！结果已保存到: {input_path1}")
    except Exception as e:
        print(f"错误: {str(e)}")

