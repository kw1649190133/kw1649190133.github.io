# 数据库绘图模块
import os
import sys
import pypyodbc
import matplotlib.pyplot as plt
import networkx as nx
import numpy as np
from collections import deque
from matplotlib.ticker import ScalarFormatter, FormatStrFormatter

# 设置中文字体支持
plt.rcParams['font.sans-serif'] = ['SimHei']  # 用来正常显示中文标签
plt.rcParams['axes.unicode_minus'] = False    # 用来正常显示负号

def visualize_drainage_network(mdb_path):
    """
    可视化排水管网数据
    
    参数:
    mdb_path (str): Access数据库(.mdb)文件路径
    
    返回:
    str: 可视化结果文件夹路径
    """
    # 检查文件是否存在
    if not os.path.exists(mdb_path):
        raise FileNotFoundError(f"数据库文件不存在: {mdb_path}")
    
    # 创建输出文件夹
    base_name = os.path.splitext(os.path.basename(mdb_path))[0]
    output_dir = os.path.join(os.path.dirname(mdb_path), f"{base_name}_plot")
    os.makedirs(output_dir, exist_ok=True)
    
    try:
        # 连接Access数据库
        conn_str = (
            r"DRIVER={Microsoft Access Driver (*.mdb, *.accdb)};"
            f"DBQ={mdb_path};"
        )
        conn = pypyodbc.connect(conn_str)
        cursor = conn.cursor()
        
        print("正在读取管点数据...")
        # 读取管点调查表数据
        cursor.execute("SELECT EXP_NO, SUR_H, WellDeep, X, Y FROM [管点调查表]")
        manhole_data = {}
        coordinates = {}  # 存储坐标用于总览图
        for row in cursor.fetchall():
            exp_no, sur_h, well_deep, x, y = row
            # 处理可能的空值
            sur_h = float(sur_h) if sur_h is not None and str(sur_h).strip() else None
            well_deep = float(well_deep) if well_deep is not None and str(well_deep).strip() else None
            x = float(x) if x is not None and str(x).strip() else 0
            y = float(y) if y is not None and str(y).strip() else 0
            
            manhole_data[exp_no] = {
                'surface_elevation': sur_h,
                'well_depth': well_deep
            }
            coordinates[exp_no] = (x, y)
        
        print("正在读取管线数据...")
        # 读取管线调查表数据
        cursor.execute("SELECT S_POINT, E_POINT, S_H, E_H, S_DEEP, E_DEEP FROM [管线调查表]")
        pipeline_data = []
        pipeline_graph = nx.DiGraph()  # 创建有向图用于路径分析
        
        for row in cursor.fetchall():
            s_point, e_point, s_h, e_h, s_deep, e_deep = row
            
            # 转换数据类型并处理空值
            s_h = float(s_h) if s_h is not None and str(s_h).strip() else None
            e_h = float(e_h) if e_h is not None and str(e_h).strip() else None
            s_deep = float(s_deep) if s_deep is not None and str(s_deep).strip() else None
            e_deep = float(e_deep) if e_deep is not None and str(e_deep).strip() else None
            
            # 计算管底高程
            start_bottom = s_h - s_deep if s_h is not None and s_deep is not None else None
            end_bottom = e_h - e_deep if e_h is not None and e_deep is not None else None
            
            pipeline = {
                'start_point': s_point,
                'end_point': e_point,
                'start_surface': s_h,
                'end_surface': e_h,
                'start_bottom': start_bottom,
                'end_bottom': end_bottom
            }
            
            pipeline_data.append(pipeline)
            
            # 添加到图结构中
            if s_point in manhole_data and e_point in manhole_data:
                pipeline_graph.add_edge(s_point, e_point, pipeline=pipeline)
        
        # 关闭数据库连接
        cursor.close()
        conn.close()
        
        print("正在生成管线纵断面图...")
        # 为每条完整路径生成纵断面图
        generated_paths = set()
        for node in pipeline_graph.nodes:
            if pipeline_graph.in_degree(node) == 0:  # 找到源头节点
                paths = find_all_paths(pipeline_graph, node)
                for path in paths:
                    # 创建路径标识符，避免重复生成
                    path_id = f"{path[0]}-{path[-1]}"
                    if path_id not in generated_paths:
                        generate_profile_plot(path, pipeline_graph, manhole_data, output_dir)
                        generated_paths.add(path_id)
        
        print("正在生成管网总览图...")
        # 生成管网总览图 - 修正坐标轴方向
        generate_overview_plot(manhole_data, pipeline_data, coordinates, output_dir, base_name)
        
        print(f"可视化完成! 结果保存在: {output_dir}")
        return output_dir
    
    except pypyodbc.Error as e:
        raise RuntimeError(f"数据库连接错误: {str(e)}")
    except Exception as e:
        raise RuntimeError(f"处理过程中发生错误: {str(e)}")

def find_all_paths(graph, start):
    """
    查找从起始节点到所有末端节点的完整路径
    
    参数:
    graph: 管网图结构
    start: 起始节点
    
    返回:
    list: 所有完整路径列表
    """
    paths = []
    stack = deque([(start, [start])])
    
    while stack:
        node, path = stack.popleft()
        
        # 如果当前节点是末端节点（没有出边），则添加路径
        if graph.out_degree(node) == 0:
            paths.append(path)
        else:
            # 遍历所有出边
            for neighbor in graph.successors(node):
                # 避免环路
                if neighbor not in path:
                    stack.append((neighbor, path + [neighbor]))
    
    return paths

def generate_profile_plot(path, graph, manhole_data, output_dir):
    """
    生成单条管线的纵断面图 - 优化高程点位置
    
    参数:
    path: 节点路径列表
    graph: 管网图结构
    manhole_data: 管点数据字典
    output_dir: 输出目录
    """
    if len(path) < 2:
        return
    
    # 准备绘图数据
    nodes = []
    surface_elevations = []
    
    # 存储每个节点的管道起点和终点高程
    node_bottoms = {node: {'start': None, 'end': None} for node in path}
    
    # 收集路径上每个节点的数据
    for i, node in enumerate(path):
        nodes.append(node)
        
        # 添加井面高程
        if node in manhole_data and manhole_data[node]['surface_elevation'] is not None:
            surface_elevations.append(manhole_data[node]['surface_elevation'])
        else:
            surface_elevations.append(0)
    
    # 收集管道数据
    for i in range(len(path) - 1):
        start_node = path[i]
        end_node = path[i+1]
        
        if graph.has_edge(start_node, end_node):
            pipeline = graph.edges[start_node, end_node]['pipeline']
            
            # 设置起点管底高程
            if pipeline['start_bottom'] is not None:
                node_bottoms[start_node]['start'] = pipeline['start_bottom']
            
            # 设置终点管底高程
            if pipeline['end_bottom'] is not None:
                node_bottoms[end_node]['end'] = pipeline['end_bottom']
    
    # 创建图形
    plt.figure(figsize=(15, 8))
    
    # 绘制井面高程线（棕色）
    plt.plot(nodes, surface_elevations, 'o-', color='saddlebrown', linewidth=2, markersize=8, label='井面高程')
    
    # 绘制管底高程点
    for i, node in enumerate(nodes):
        bottoms = node_bottoms[node]
        
        # 绘制起点管底高程（蓝色圆圈）
        if bottoms['start'] is not None:
            plt.plot(node, bottoms['start'], 'bo', markersize=8, label='起点管底' if i == 0 else "")
        
        # 绘制终点管底高程（蓝色方块）
        if bottoms['end'] is not None:
            plt.plot(node, bottoms['end'], 'bs', markersize=8, label='终点管底' if i == 0 else "")
    
    # 绘制管道连接线和节点内部连接线
    for i in range(len(path) - 1):
        start_node = path[i]
        end_node = path[i+1]
        
        if graph.has_edge(start_node, end_node):
            pipeline = graph.edges[start_node, end_node]['pipeline']
            
            # 绘制水平管道线（实线）
            if pipeline['start_bottom'] is not None and pipeline['end_bottom'] is not None:
                plt.plot([start_node, end_node], 
                         [pipeline['start_bottom'], pipeline['end_bottom']], 
                         'b-', linewidth=2, label='管底高程' if i == 0 else "")
    
    # 绘制节点内部的垂直连接线（虚线）
    for i, node in enumerate(nodes):
        bottoms = node_bottoms[node]
        
        # 检查节点是否有起点和终点高程
        if bottoms['end'] is not None and bottoms['start'] is not None:
            # 如果起点和终点高程不同，绘制虚线连接
            if abs(bottoms['end'] - bottoms['start']) > 0.001:
                plt.plot([node, node], 
                         [bottoms['end'], bottoms['start']], 
                         'b--', linewidth=1, alpha=0.7)
    
    # 添加高程标签
    for i, node in enumerate(nodes):
        if surface_elevations[i] is not None:
            plt.text(node, surface_elevations[i], f'{surface_elevations[i]:.2f}', 
                     fontsize=9, ha='right', va='bottom', color='saddlebrown')
        
        # 添加起点管底高程标签
        bottoms = node_bottoms[node]
        if bottoms['start'] is not None:
            plt.text(node, bottoms['start'], f'{bottoms["start"]:.2f}', 
                     fontsize=9, ha='left', va='top', color='blue')
        
        # 添加终点管底高程标签
        if bottoms['end'] is not None:
            plt.text(node, bottoms['end'], f'{bottoms["end"]:.2f}', 
                     fontsize=9, ha='right', va='top', color='blue')
    
    # 设置图表属性
    plt.title(f"管线纵断面图: {path[0]} - {path[-1]}", fontsize=16)
    plt.xlabel("节点名称", fontsize=12)
    plt.ylabel("高程 (米)", fontsize=12)
    plt.xticks(rotation=45, ha='right')
    plt.grid(True, linestyle='--', alpha=0.7)
    
    # 创建图例（避免重复标签）
    handles, labels = plt.gca().get_legend_handles_labels()
    by_label = dict(zip(labels, handles))
    plt.legend(by_label.values(), by_label.keys())
    
    # 自动调整布局
    plt.tight_layout()
    
    # 保存图像
    filename = f"{path[0]}-{path[-1]}.png"
    filepath = os.path.join(output_dir, filename)
    plt.savefig(filepath, dpi=300)
    plt.close()
    
    print(f"已生成纵断面图: {filename}")

def generate_overview_plot(manhole_data, pipeline_data, coordinates, output_dir, base_name):
    """
    生成管网总览图 - 修正坐标轴方向
    
    参数:
    manhole_data: 管点数据字典
    pipeline_data: 管线数据列表
    coordinates: 节点坐标字典
    output_dir: 输出目录
    base_name: 数据库基础名称
    """
    plt.figure(figsize=(15, 15))
    
    # 创建坐标系，禁用科学计数法
    plt.gca().xaxis.set_major_formatter(ScalarFormatter(useOffset=False))
    plt.gca().yaxis.set_major_formatter(ScalarFormatter(useOffset=False))
    plt.gca().xaxis.set_major_formatter(FormatStrFormatter('%.0f'))
    plt.gca().yaxis.set_major_formatter(FormatStrFormatter('%.0f'))
    
    # 修正坐标轴：X是北坐标，Y是东坐标
    # 在绘图时，北坐标应作为Y轴，东坐标作为X轴
    east_coords = []  # 东坐标 (原Y字段)
    north_coords = []  # 北坐标 (原X字段)
    node_positions = {}
    
    # 收集坐标数据
    for node, (north, east) in coordinates.items():
        east_coords.append(east)
        north_coords.append(north)
        node_positions[node] = (east, north)  # (东, 北)
    
    # 绘制管线
    for pipe in pipeline_data:
        start = pipe['start_point']
        end = pipe['end_point']
        
        if start in node_positions and end in node_positions:
            x1, y1 = node_positions[start]  # (东, 北)
            x2, y2 = node_positions[end]    # (东, 北)
            
            # 绘制管线
            plt.plot([x1, x2], [y1, y2], 'b-', linewidth=1, alpha=0.7)
    
    # 绘制管点并标注（减小点的大小）
    for node, (x, y) in node_positions.items():
        # 绘制管点（红色，大小为原来的1/2）
        plt.plot(x, y, 'ro', markersize=4)
        
        # 标注管点名称
        plt.text(x, y, node, fontsize=9, ha='center', va='bottom')
    
    # 设置图表属性
    plt.title(f"{base_name} - 排水管网总览图", fontsize=20)
    plt.xlabel("东坐标 (米)", fontsize=14)  # X轴是东坐标
    plt.ylabel("北坐标 (米)", fontsize=14)  # Y轴是北坐标
    plt.grid(True, linestyle='--', alpha=0.5)
    
    # 自动调整坐标范围
    all_x = [pos[0] for pos in node_positions.values()]  # 东坐标
    all_y = [pos[1] for pos in node_positions.values()]  # 北坐标
    
    x_min, x_max = min(all_x), max(all_x)
    y_min, y_max = min(all_y), max(all_y)
    
    # 添加10%的边距
    x_margin = (x_max - x_min) * 0.1
    y_margin = (y_max - y_min) * 0.1
    
    plt.xlim(x_min - x_margin, x_max + x_margin)
    plt.ylim(y_min - y_margin, y_max + y_margin)
    
    # 添加图例
    plt.plot([], [], 'ro', markersize=4, label='管点')
    plt.plot([], [], 'b-', linewidth=1, label='管线')
    plt.legend(loc='upper right')
    
    # 保存图像
    filename = f"{base_name}_管网总览图.png"
    filepath = os.path.join(output_dir, filename)
    plt.savefig(filepath, dpi=300, bbox_inches='tight')  # 确保比例尺不被裁剪
    plt.close()
    
    print(f"已生成管网总览图: {filename}")

# 功能封装
def MDB_plot(input_path):
    try:
        mdb_file = input_path
        output_folder = visualize_drainage_network(mdb_file)
        print(f"可视化结果保存在: {output_folder}")
    except Exception as e:
        print(f"错误: {str(e)}")

if __name__ == "__main__":
    try:
        mdb_file = input("输入MDB数据库文件路径: ").strip()
        if not os.path.exists(mdb_file):
            print("文件不存在，请检查路径")
        output_folder = visualize_drainage_network(mdb_file)
        print(f"可视化结果保存在: {output_folder}")
    except Exception as e:
        print(f"错误: {str(e)}")