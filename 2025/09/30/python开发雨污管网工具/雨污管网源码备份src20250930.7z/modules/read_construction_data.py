# 20250703
# 为了方便数据匹配，先从施工数据表中读取数据到对比表中，形成一个中间成果。
# 对比表直接使用空白模板，只需要调整施工成果表

import openpyxl
import os

# 检查测量成果是否重复
def dataisonly(unique_id, y_str, x_str, data_array):
    for item in data_array:
        if ((item[0]) == unique_id and (item[1]) == y_str and (item[2]) == x_str ):
            return 0
    # 如果未发现重复，则返回1
    return 1

# 测量数据获取。输入对比表、测量成果表

def measurement_data_get(sheet_com,sheet_m):
    row = 3 # 对比表的行指针
    count_com = 0 # 计数器，统计添加的记录数
    sheet_com_array = [["A","1","1"]] # 初始化对比表数组，存储已添加的序号、名称、横坐标Y、纵坐标X
    count3_not_only = 0 # 计数器，统计重复数据
# 循环一遍成果表，将非空数据添加到对比表
    print("已读取总行数: " + str(sheet_m.max_row))
    for j in range(6,sheet_m.max_row+1):
        # 检测序号列是否为空
        if sheet_m[f'A{j}'].value is not None and sheet_m[f'A{j}'].value is not None:
            # 检测是否重复，未发现重复则进行下一步赋值（这里还是选择保留重复检测程序）
            if dataisonly(sheet_m[f'B{j}'].value,sheet_m[f'G{j}'].value,sheet_m[f'F{j}'].value,sheet_com_array):
                # 如果未发现重复，则将数组添加到查重数组
                sheet_com_array.append([sheet_m[f'B{j}'].value,sheet_m[f'G{j}'].value,sheet_m[f'F{j}'].value])

                # 开始赋值
                # 序号，名称
                sheet_com[f'A{row}'].value = sheet_m[f'A{j}'].value #序号
                sheet_com[f'B{row}'].value = sheet_m[f'B{j}'].value #井名称

                # 横坐标Y 纵坐标X 井面高 井底高 计算井深 （补充一个井底标高）
                sheet_com[f'H{row}'].value = sheet_m[f'G{j}'].value #横坐标Y
                sheet_com[f'I{row}'].value = sheet_m[f'F{j}'].value #纵坐标X
                sheet_com[f'J{row}'].value = sheet_m[f'H{j}'].value #井面标高
                sheet_com[f'K{row}'].value = sheet_m[f'J{j}'].value #管底标高
                if (sheet_m[f'H{j}'].value is not None and sheet_m[f'I{j}'].value is not None):
                    jingshen = float(sheet_m[f'H{j}'].value)-float(sheet_m[f'I{j}'].value) #井深计算
                    sheet_com[f'L{row}'].value = "%.3f" % jingshen
                #sheet_com[f'Q{row}'].value = sheet_m[f'J{j}'].value #管底
                sheet_com[f'S{row}'].value = sheet_m[f'E{j}'].value #井类型

                count_com+=1 #计数器+1
                row+=1 #指针+1        
            else:
                count3_not_only+=1 #统计到重复数据
        else:
            print("第 " + str(j) + " 行数据为空，跳过")
        
    print("已添加数据： " + str(count_com) + " 条记录")    
    print("发现重复数据： " + str(count3_not_only) + " 条，已去除")         
    return sheet_com

# 封装函数
def read_construction_data(input_path1,input_path2,output_path =None):
    if not output_path:
        if input_path2.endswith('.xlsx'):
            output_path = input_path2.replace('.xlsx', '_load.xlsx')
        else:
            output_path = input_path2 + '_load.xlsx'

    # 读取文件
    workbook1 = openpyxl.load_workbook(input_path1)
    workbook2 = openpyxl.load_workbook(input_path2)

    # 获取设计表的表名，检查W和Y是否存在
    sheet_names2 = workbook2.sheetnames

    if "W" in sheet_names2 :
        print('__Loading W sheet__')
        # 表格1是对比表,表2是测量成果
        sheet1w = workbook1["W"] # 按名称获取
        sheet2w = workbook2["W"] # 按名称获取
        #数据处理
        sheet1w=measurement_data_get(sheet1w,sheet2w)
    else:
        print("设计数据未找到W表")

    if "Y" in sheet_names2 :
        sheet1y = workbook1["Y"] # 按名称获取
        sheet2y = workbook2["Y"] # 按名称获取
        #数据处理
        sheet1y=measurement_data_get(sheet1y,sheet2y)
    else:
        print("设计数据未找到Y表")


    # 保存结果
    workbook1.save(output_path)
    print("———————————分割线———————————")
    print(f"处理完成！结果已保存到: {output_path}")

if __name__ == "__main__":
    try:
        #输入和输出（对比表，成果表）
        input_path1 = input("请输入对比表模板文件路径(.xlsx): ").strip() 
        if not os.path.exists(input_path1):
                print("文件不存在，请检查路径")
        input_path2 = input("请输入施工成果表文件路径(.xlsx): ").strip() 
        if not os.path.exists(input_path2):
                print("文件不存在，请检查路径")
        output_path =None

        if output_path is None:
            if input_path2.endswith('.xlsx'):
                output_path = input_path2.replace('.xlsx', '_load.xlsx')
            else:
                output_path = input_path2 + '_load.xlsx'
            # 读取文件
            workbook1 = openpyxl.load_workbook(input_path1)
            workbook2 = openpyxl.load_workbook(input_path2)

        # 获取设计表的表名，检查W和Y是否存在
        sheet_names2 = workbook2.sheetnames

        if "W" in sheet_names2 :
            print('__Loading W sheet__')
            # 表格1是对比表,表2是测量成果
            sheet1w = workbook1["W"] # 按名称获取
            sheet2w = workbook2["W"] # 按名称获取
            #数据处理
            sheet1w=measurement_data_get(sheet1w,sheet2w)
        else:
            print("设计数据未找到W表")

        if "Y" in sheet_names2 :
            sheet1y = workbook1["Y"] # 按名称获取
            sheet2y = workbook2["Y"] # 按名称获取
            #数据处理
            sheet1y=measurement_data_get(sheet1y,sheet2y)
        else:
            print("设计数据未找到Y表")


        # 保存结果
        workbook1.save(output_path)
        print("———————————分割线———————————")
        print(f"处理完成！结果已保存到: {output_path}")
    except Exception as e:
        print(f"错误: {str(e)}")