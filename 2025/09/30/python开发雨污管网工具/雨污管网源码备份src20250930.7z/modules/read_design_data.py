# read_design_data_v3
from openpyxl import Workbook, load_workbook
from openpyxl.utils import get_column_letter
import re
import os

def fuzzy_match_header(header_value, target_headers):
    """
    模糊匹配表头名称
    忽略大小写、空格、特殊字符和单位差异
    
    参数:
    header_value: 实际表头值
    target_headers: 目标表头列表
    
    返回:
    匹配到的目标表头名称，或None
    """
    if not header_value:
        return None
    
    # 标准化字符串：移除单位、空格、特殊字符，转为小写
    def normalize(s):
        # 移除单位（括号内的内容）
        s = re.sub(r'\([^)]*\)', '', str(s))
        # 移除特殊字符和空格
        s = ''.join(filter(str.isalnum, s)).lower()
        return s
    
    norm_value = normalize(header_value)
    
    # 目标表头的标准化映射
    target_norms = {normalize(h): h for h in target_headers}
    
    # 完全匹配
    if norm_value in target_norms:
        return target_norms[norm_value]
    
    # 部分匹配（检查目标是否包含在实际表头中）
    for target_norm, target_header in target_norms.items():
        if target_norm in norm_value:
            return target_header
    
    # 部分匹配（检查实际表头是否包含在目标中）
    for target_norm, target_header in target_norms.items():
        if norm_value in target_norm:
            return target_header
    
    return None

def extract_and_integrate_well_data(input_sheet):
    """
    智能提取并整合井数据表格（带模糊表头匹配）
    从包含无关表头的表格中提取所需数据，合并多个数据块
    
    参数:
    input_sheet: 输入的Worksheet对象
    
    返回:
    整合后的新工作簿对象
    """
    # 创建新工作簿和工作表
    wb_out = Workbook()
    sheet_out = wb_out.active
    sheet_out.title = "整合井数据"
    
    # 目标列顺序
    target_headers = [
        "序号", "井编号", "横坐标y", "纵坐标x", 
        "井面标高(m)", "井底标高(m)", "井深(m)","节点类型"
    ]
    
    # 写入新表头
    for col_idx, header in enumerate(target_headers, 1):
        sheet_out.cell(row=1, column=col_idx, value=header)
    
    # 定义数据块范围 (A-I列和K-S列)
    data_blocks = [
        {"start_col": "A", "end_col": "I"},
        {"start_col": "K", "end_col": "S"}
    ]
    
    # 处理每个数据块
    output_row = 2  # 新表的数据起始行
    header_row = 1  # 表头所在行（假设为第1行）
    
    for block_idx, block in enumerate(data_blocks, 1):
        # 确定数据块列范围
        start_col = ord(block["start_col"]) - 64  # A=1
        end_col = ord(block["end_col"]) - 64
        
        # 获取数据块内的表头映射
        header_mapping = {}
        for col_idx in range(start_col, end_col + 1):
            col_letter = get_column_letter(col_idx)
            cell = input_sheet.cell(row=header_row, column=col_idx)
            header_value = cell.value
            
            # 模糊匹配目标表头
            matched_header = fuzzy_match_header(header_value, target_headers)
            if matched_header:
                # 只取第一次出现的表头
                if matched_header not in header_mapping:
                    header_mapping[matched_header] = col_letter
                    print(f"数据块{block_idx}: 列 {col_letter} '{header_value}' 匹配到 '{matched_header}'")
        
        # 如果没有找到任何目标表头，跳过此数据块
        if not header_mapping:
            print(f"数据块{block_idx}({block['start_col']}-{block['end_col']}) 未找到匹配表头")
            continue
        
        # 读取数据行
        data_row = header_row + 1
        data_count = 0
        
        while True:
            # 检查是否还有数据（以序号列作为判断）
            stop_processing = False
            if "序号" in header_mapping:
                serial_col = header_mapping["序号"]
                serial_value = input_sheet[f"{serial_col}{data_row}"].value
                if serial_value is None or serial_value == "":
                    stop_processing = True
            else:
                # 如果没有序号列，使用第一个目标列判断
                first_header = list(header_mapping.keys())[0]
                first_col = header_mapping[first_header]
                if input_sheet[f"{first_col}{data_row}"].value is None:
                    stop_processing = True
            
            if stop_processing:
                break
            
            # 提取当前行数据
            row_data = {}
            for header, col_letter in header_mapping.items():
                cell_value = input_sheet[f"{col_letter}{data_row}"].value
                row_data[header] = cell_value
            
            # 按目标顺序写入新表
            for col_idx, header in enumerate(target_headers, 1):
                value = row_data.get(header)
                sheet_out.cell(row=output_row, column=col_idx, value=value)
            
            output_row += 1
            data_count += 1
            data_row += 1
        
        print(f"数据块{block_idx} 提取了 {data_count} 行数据")

    print(f"总共提取了 {output_row-2} 行数据")
    return wb_out

# 标高自动补全
def biaogaobuquan(sheet):
    if sheet[f"E{2}"].value is None:
        for i in range(2,sheet.max_row+1):
            biaogao=float(sheet[f"F{i}"].value)+float(sheet[f"G{i}"].value)
            sheet[f"E{i}"].value=str(round(biaogao,3))
    return sheet

# 自动分类功能
def process_excel_file(wb):
    # 获取第一个工作表
    if not wb.sheetnames:
        print("工作簿中没有工作表！")
        return
    original_sheet = wb.active
    # 读取标题行（第一行）
    headers = [cell.value for cell in original_sheet[1]]
    # 准备分类存储数据
    w_data = []     # 存储W开头的数据
    y_data = []     # 存储Y开头的数据
    other_data = [] # 存储其他数据
    
    # 遍历数据行（从第二行开始）
    for row in original_sheet.iter_rows(min_row=2, values_only=True):
        if not row or len(row) < 2:  # 跳过空行或列数不足的行
            continue
            
        # 处理名称列（B列）并去除首尾空格
        name = str(row[1]).strip() if row[1] is not None else ""
        
        # 检查名称是否以W或Y开头（不区分大小写）
        if name.upper().startswith('W'):
            w_data.append(row)
        elif name.upper().startswith('Y'):
            y_data.append(row)
        else:
            other_data.append(row)
    
    # 删除原表
    wb.remove(original_sheet)
    
    # 创建W表并添加数据
    if w_data:
        ws_w = wb.create_sheet("W")
        ws_w.append(headers)
        for row in w_data:
            ws_w.append(row)
        for row in other_data:
            ws_w.append(row)
        # 补全标高
        ws_w = biaogaobuquan(ws_w)
    
    # 创建Y表并添加数据
    if y_data:  # 只有当有Y数据时才创建Y表
        ws_y = wb.create_sheet("Y")
        ws_y.append(headers)
        for row in y_data:
            ws_y.append(row)
        # 补全标高
        ws_y = biaogaobuquan(ws_y)
    # 保存更改到原文件
    return wb

def save_integrated_data(input_path, output_file):
    """
    完整处理流程：加载文件、处理数据、保存结果
    
    参数:
    input_path: 输入文件路径
    output_file: 输出文件路径
    """
    try:
        # 加载原始工作簿
        wb_in = load_workbook(input_path)

        # 这里只读取第一个工作表
        input_sheet = wb_in.active
        
        # 处理数据并获取新工作簿
        integrated_wb = extract_and_integrate_well_data(input_sheet)
        # 新表整理
        integrated_wb = process_excel_file(integrated_wb)
        # 保存结果
        integrated_wb.save(output_file)
        print(f"数据整合完成！已保存为 '{output_file}'")
        return True
    except Exception as e:
        print(f"处理失败: {str(e)}")
        return False

# 添加封装函数
def read_design_data(input_file,output_file =None):
    output_file =None
    if not output_file:
        if input_file.endswith('.xlsx'):
            output_file = input_file.replace('.xlsx', '_load.xlsx')
        else:
            output_file = input_file + '_load.xlsx'
    
    success = save_integrated_data(input_file, output_file)
    
    if success:
        print("操作成功完成！")
    else:
        print("处理过程中出现问题")

# 使用示例
if __name__ == "__main__":
    try:
        # 获取输入文件路径
        input_file = input("请输入设计表文件路径(.xlsx): ").strip() 
        if not os.path.exists(input_file):
            print("文件不存在，请检查路径")
        output_file =None
        if not output_file:
            if input_file.endswith('.xlsx'):
                output_file = input_file.replace('.xlsx', '_load.xlsx')
            else:
                output_file = input_file + '_load.xlsx'
        
        success = save_integrated_data(input_file, output_file)
        if success:
            print("操作成功完成！")
        else:
            print("处理过程中出现问题")
    except Exception as e:
        print(f"错误: {str(e)}")