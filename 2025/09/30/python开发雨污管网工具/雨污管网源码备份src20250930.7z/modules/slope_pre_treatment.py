# 堵点处理程序
# 这个程序专门处理调坡比算法无法覆盖的区域
from openpyxl.styles import Font, Alignment, Border, Side
from openpyxl.utils import get_column_letter
import openpyxl

def read_txt_to_array(file_path):
    """
    从文本文件中读取数据，每行作为一个字符串元素存入数组并返回
    
    参数:
    file_path (str): 文本文件路径
    
    返回:
    list: 包含文件每一行内容的字符串列表
    
    异常:
    FileNotFoundError: 如果文件不存在
    IOError: 如果读取文件时发生错误
    """
    lines = []  # 存储行的数组
    
    try:
        # 使用utf-8编码打开文件（自动处理不同操作系统换行符）
        with open(file_path, 'r', encoding='utf-8') as file:
            # 逐行读取文件内容
            for line in file:
                # 去除行尾换行符并添加到数组
                lines.append(line.rstrip('\n'))
                
        return lines
    
    except FileNotFoundError:
        raise FileNotFoundError(f"错误：文件不存在 - {file_path}")
    except UnicodeDecodeError:
        # 如果utf-8解码失败，尝试其他常见编码
        try:
            with open(file_path, 'r', encoding='latin-1') as file:
                return [line.rstrip('\n') for line in file]
        except Exception as e:
            raise IOError(f"解码错误：无法读取文件 - {str(e)}")
    except Exception as e:
        raise IOError(f"读取文件时发生错误：{str(e)}")

def is_in_blacklist(input_str, blacklist):
    """
    检查输入字符串是否在黑名单中
    
    参数:
    input_str (str): 要检查的字符串
    blacklist (list): 黑名单字符串列表
    
    返回:
    bool: 如果在黑名单中返回True，否则返回False
    """
    # 预处理输入字符串：去除首尾空白并转换为小写
    normalized_input = input_str.strip().lower()
    
    # 检查处理后的字符串是否在黑名单中
    # 同时检查黑名单中的每个条目（也进行标准化处理）
    return any(item.strip().lower() == normalized_input for item in blacklist)

def slope_ratio(gd,lxgd,d):

    depth_d = float(gd)-float(lxgd)  # 计算深度差
    pobi = depth_d / float(d)  # 计算坡度比
    return pobi
# 输入管径返回参考坡比
def cankaopobi_get(guanjing):
    if guanjing >= 400:
        return 0.001
    elif guanjing < 400:
        return 0.0015
    
# 对指定单元格修改填充色
def greed_mark(call):
    # 绿色样式
    green_fill = openpyxl.styles.PatternFill(start_color="00FF00",end_color="00FF00",fill_type="solid")
    call.fill = green_fill
    return call
def red_mark(call):
    # 红色样式
    green_fill = openpyxl.styles.PatternFill(start_color="FF0000", end_color="FF0000", fill_type="solid")
    call.fill = green_fill
    return call
def yellow_mark(call):
    #黄色样式
    yellow_fill = openpyxl.styles.PatternFill(start_color="FFFF00", end_color="FFFF00", fill_type="solid")
    call.fill = yellow_fill
    return call

# 计算流向高程
def sheet_lxgc_get(sheet):
    # 循环流向井列表C，当不为空时去找流向
    for i in range(6,sheet.max_row+1):
        lxj = sheet[f"C{i}"].value
        if lxj is not None:
            # 循环井列表B
            for j in range(6,sheet.max_row+1):
                jing = sheet[f"B{j}"].value # B列表井名称
                # 名称匹配上
                if lxj == jing:
                    # 考虑有的表格没有流向管底这一项，那就直接把流向高程作为流向管底。
                    if sheet[f"O{i}"].value is None:
                        sheet[f"Y{i}"].value = sheet[f"J{j}"].value
                        sheet[f"O{i}"].value = sheet[f"Y{i}"].value
                        greed_mark(sheet[f"O{i}"])
                    
                    else:
                        # 当井J是终点井的时候，将井底作为I井的流向高，否则正常将管底当做流向高程
                        if sheet[f"J{j}"].value is None :
                            sheet[f"Y{i}"].value = sheet[f"I{j}"].value
                        else : 
                            sheet[f"Y{i}"].value = sheet[f"J{j}"].value
                        # 当流向井不是终点井的时候，并且流向高程【低于】流向管底，那就更新流向井。
                        # 流向管底是可以高于对于井的管底的。所以当流向高程高于流向管底时，才进行更新。
                        if sheet[f"C{j}"].value is not None and float(sheet[f"Y{i}"].value) > float(sheet[f"O{i}"].value):
                            sheet[f"O{i}"].value = sheet[f"Y{i}"].value
                            greed_mark(sheet[f"O{i}"])
                    
    return sheet
    
# 从流向高程更新管底。输入表格，流向井名称，更新值，返回表格。
def sheet_lxgc_to_gd(sheet,lxjname,lxgc):
    key = 0
    print(lxjname + "__" + str(lxgc))
    for i in range(6,sheet.max_row+1):
        jing = sheet[f"B{i}"].value # B列表名称
        # 名称匹配
        if jing == lxjname:
            key = 1
            # 当被流向的井是终点井或孤立井，并且流向高程低于井深，则开挖井深      
            if sheet[f"C{i}"].value is None and float(lxgc) < float(sheet[f"I{i}"].value):
                sheet[f"I{i}"].value = lxgc
                greed_mark( sheet[f"I{i}"])
                print("【警告】井底已更新")
        # 当流向不是终点井，并且管底不同时
            if sheet[f"C{i}"].value is not None and float(lxgc) < float(sheet[f"J{i}"].value):
                sheet[f"J{i}"].value = lxgc # 否则更新管底
                greed_mark( sheet[f"J{i}"])
                print("管底已更新")
            # 更新井底
            if sheet[f"C{i}"].value is not None and float(sheet[f"J{i}"].value)<float(sheet[f"I{i}"].value):
                sheet[f"I{i}"].value = sheet[f"J{i}"].value
                red_mark( sheet[f"I{i}"])
                print("【警告】井底已更新")
            #else:
                #print (f"【警告，未找到{jing}流向井的井底标高】"
    if key == 1 :
        print ("已更新管底标高")
    else :
        print ("什么也没做")
    return sheet
    
# 坡度比计算和超限检查函数
def sheet_slope_check_back(sheet_m,heimingdan):
    sheet_m[f'T{5}'].value = "调整后坡比"
    sheet_m[f'U{5}'].value = "最低参考坡比"
    sheet_m[f'V{5}'].value = "调整后差值"
    sheet_m[f'W{5}'].value = "高度值差"
    # 循环一遍成果表，将非空数据添加到对比表
    print("已读取总行数: " + str(sheet_m.max_row))
    sheet_m = sheet_lxgc_get(sheet_m) #初始化流向高程
    for j in range(6,sheet_m.max_row+1):
        # 当流向高程不为0时才会进行数据处理
        jing = sheet_m[f'B{j}'].value
        lxj = sheet_m[f'C{j}'].value
        # 判断节点是否在黑名单中
        if is_in_blacklist(jing,heimingdan):
            print("找到黑名单节点： " + jing)
            gd = float(sheet_m[f'J{j}'].value) # 管底标高
            lxgd = float(sheet_m[f'O{j}'].value) # 流向井管底标高
            if sheet_m[f'L{j}'].value is None: # 有的没有管径
                gdiammeter = 300 #默认管径300
            else : gdiammeter = float(sheet_m[f'L{j}'].value) # 管径
            glength = float(sheet_m[f'Q{j}'].value) # 管长
            lxgc = float(sheet_m[f'Y{j}'].value) # 流向高程
            pobi = slope_ratio(gd, lxgc, glength) # 计算坡比(用流向高程算)
            cankaopobi = cankaopobi_get(gdiammeter) # 通过管径确定坡比最小值
            # （管底-流向管底）-（长度乘以设计坡比得到设计高度差），
            height_diff = round((gd-lxgd)-(glength*cankaopobi),3) # 计算高度值差(用流向高程算)
            sheet_m[f'T{j}'].value = pobi
            sheet_m[f'U{j}'].value = cankaopobi # 最低坡比
            sheet_m[f'V{j}'].value = pobi - cankaopobi # 计算坡比差值
            sheet_m[f'W{j}'].value = height_diff # 计算高度值差

            #if  height_diff < 0:
            new_xlgc = lxgc + height_diff
            sheet_m[f'Y{j}'].value = new_xlgc
            greed_mark(sheet_m[f'Y{j}'])
            sheet_m = sheet_lxgc_to_gd(sheet_m,sheet_m[f'C{j}'].value,new_xlgc)
            print("流向高程调整值： "+ str(height_diff))

    return sheet_m

def loading_and_processing(input_path1,heimingdan_path):
    workbook1 = openpyxl.load_workbook(input_path1)
    # 获取设计表的表名，检查W和Y是否存在
    sheet_names1 = workbook1.sheetnames
    heimingdan = read_txt_to_array(heimingdan_path)

    if "W" in sheet_names1 :
        print('__Loading W sheet__')
        # 表格1是对比表,表2是测量成果
        sheet1w = workbook1["W"] # 按名称获取
        #数据处理
        sheet1w=sheet_slope_check_back(sheet1w,heimingdan)
    else:
        print("未找到W表")

    if "Y" in sheet_names1 :
        print('__Loading Y sheet__')
        sheet1y = workbook1["Y"] # 按名称获取
        #数据处理
        sheet1y=sheet_slope_check_back(sheet1y,heimingdan)
    else:
        print("未找到Y表")
    return workbook1

# 程序封装-坡比预处理程序
def slope_pre_treatment(input_path1,heimingdan_path):
    try:
        #输入和输出（成果表）
        output_path = None
        if not output_path:
            if input_path1.endswith('.xlsx'):
                output_path = input_path1.replace('.xlsx', '_pre.xlsx')
            else:
                output_path = input_path1 + '_pre.xlsx'
        # 读取文件
        workbook1 = loading_and_processing(input_path1,heimingdan_path) 
        # 保存结果
        workbook1.save(output_path)
        print("———————————分割线———————————")
        print(f"处理完成！结果已保存到: {input_path1}")
    except Exception as e:
        return f"错误：{str(e)}"

if __name__ == "__main__":
    try:
        #输入和输出（成果表）
        input_path1 = input("请输入成果表文件路径(.xlsx): ").strip()
        heimingdan_path = input("请输入特殊调整节点表路径(.txt): ").strip()
        output_path = None
        if not output_path:
            if input_path1.endswith('.xlsx'):
                output_path = input_path1.replace('.xlsx', '_pre.xlsx')
            else:
                output_path = input_path1 + '_pre.xlsx'
            # 读取文件
        workbook1 = loading_and_processing(input_path1,heimingdan_path) 
        # 保存结果
        workbook1.save(output_path)
        print("———————————分割线———————————")
        print(f"处理完成！结果已保存到: {input_path1}")
    except Exception as e:
        print(f"错误: {str(e)}")