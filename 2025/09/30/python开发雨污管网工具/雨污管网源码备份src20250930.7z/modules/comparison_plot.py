import os
import pandas as pd
import networkx as nx
import matplotlib.pyplot as plt
import numpy as np
from openpyxl import load_workbook
import warnings
warnings.filterwarnings('ignore')

# 设置中文字体支持
plt.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei', 'DejaVu Sans']  # 用来正常显示中文标签
plt.rcParams['axes.unicode_minus'] = False  # 用来正常显示负号

def parse_pipeline_data(file_path):
    """
    解析管道数据Excel文件
    """
    # 检查Excel文件中是否有W表和Y表
    xl = pd.ExcelFile(file_path)
    available_sheets = xl.sheet_names
    
    datasets = {}
    
    # 读取W表（如果存在）
    if 'W' in available_sheets:
        try:
            # 直接使用列索引读取数据，跳过前5行
            w_data = pd.read_excel(file_path, sheet_name='W', header=None, skiprows=5)
            if not w_data.empty:
                # 使用列索引而不是列名
                # B列是起点名称 (索引1)
                # C列是终点名称 (索引2)
                # AC列是起点高程 (索引28)
                # AE列是终点高程 (索引30)
                # J列是起点高程 (索引9)
                # O列是终点高程 (索引14)
                # AU列是起点高程 (索引46)
                # AW列是终点高程 (索引48)
                
                # 重命名列以便处理
                w_data.columns = [f'col_{i}' for i in range(len(w_data.columns))]
                
                # 过滤掉空行
                w_data = w_data[w_data['col_1'].notna()]
                datasets['W'] = w_data
                print(f"W表读取成功，共{len(w_data)}行数据")
        except Exception as e:
            print(f"读取W表时出错: {e}")
    
    # 读取Y表（如果存在）
    if 'Y' in available_sheets:
        try:
            # 直接使用列索引读取数据，跳过前5行
            y_data = pd.read_excel(file_path, sheet_name='Y', header=None, skiprows=5)
            if not y_data.empty:
                # 使用列索引而不是列名
                y_data.columns = [f'col_{i}' for i in range(len(y_data.columns))]
                
                # 过滤掉空行
                y_data = y_data[y_data['col_1'].notna()]
                datasets['Y'] = y_data
                print(f"Y表读取成功，共{len(y_data)}行数据")
        except Exception as e:
            print(f"读取Y表时出错: {e}")
    
    return datasets

def build_pipeline_graph(data):
    """
    构建管道网络图
    """
    G = nx.DiGraph()
    
    for _, row in data.iterrows():
        start_node = row['col_1']  # B列 (索引1)
        end_node = row['col_2'] if pd.notna(row['col_2']) else None  # C列 (索引2)
        
        # 添加节点属性
        if start_node not in G:
            G.add_node(start_node)
        
        # 设置节点属性
        node_attrs = {
            'original_start_elev': row['col_28'],  # AC列 (索引28)
            'construction_start_elev': row['col_9'],  # J列 (索引9)
            'design_start_elev': row['col_46']  # AU列 (索引46)
        }
        nx.set_node_attributes(G, {start_node: node_attrs})
        
        # 如果是终点节点
        if end_node is None:
            continue
            
        # 添加终点节点
        if end_node not in G:
            G.add_node(end_node)
        
        # 添加边
        edge_attrs = {
            'original_start_elev': row['col_28'],  # AC列 (索引28)
            'original_end_elev': row['col_30'],    # AE列 (索引30)
            'construction_start_elev': row['col_9'],   # J列 (索引9)
            'construction_end_elev': row['col_14'],    # O列 (索引14)
            'design_start_elev': row['col_46'],    # AU列 (索引46)
            'design_end_elev': row['col_48']      # AW列 (索引48)
        }
        G.add_edge(start_node, end_node, **edge_attrs)
    
    return G

def find_complete_paths(G):
    """
    查找所有完整路径（从起始点到终点）
    """
    # 找到所有起始点（没有入边的节点）
    start_nodes = [node for node in G.nodes() if G.in_degree(node) == 0]
    complete_paths = []
    
    for start_node in start_nodes:
        # 找到所有终点（没有出边的节点）
        end_nodes = [node for node in G.nodes() if G.out_degree(node) == 0]
        
        # 使用DFS找到所有从起始点出发的路径
        for end_node in end_nodes:
            try:
                for path in nx.all_simple_paths(G, start_node, end_node):
                    complete_paths.append(path)
            except nx.NetworkXNoPath:
                continue
    
    return complete_paths

def plot_pipeline_path(G, path, output_path, title):
    """
    绘制单条管道路径的高程图
    """
    fig, ax = plt.subplots(figsize=(14, 8))
    
    # 准备数据
    nodes = path
    original_start_vals = []
    original_end_vals = []
    construction_start_vals = []
    construction_end_vals = []
    design_start_vals = []
    design_end_vals = []
    
    # 收集每个节点的数据
    for i, node in enumerate(nodes):
        # 获取节点数据
        node_data = G.nodes[node]
        original_start_vals.append(node_data.get('original_start_elev', np.nan))
        construction_start_vals.append(node_data.get('construction_start_elev', np.nan))
        design_start_vals.append(node_data.get('design_start_elev', np.nan))
        
        # 如果是最后一个节点，没有出边
        if i == len(nodes) - 1:
            original_end_vals.append(np.nan)
            construction_end_vals.append(np.nan)
            design_end_vals.append(np.nan)
        else:
            # 获取边数据
            next_node = nodes[i+1]
            if G.has_edge(node, next_node):
                edge_data = G[node][next_node]
                original_end_vals.append(edge_data.get('original_end_elev', np.nan))
                construction_end_vals.append(edge_data.get('construction_end_elev', np.nan))
                design_end_vals.append(edge_data.get('design_end_elev', np.nan))
            else:
                original_end_vals.append(np.nan)
                construction_end_vals.append(np.nan)
                design_end_vals.append(np.nan)
    
    # 确定y轴范围
    all_vals = original_start_vals + original_end_vals + construction_start_vals + construction_end_vals + design_start_vals + design_end_vals
    valid_vals = [v for v in all_vals if not np.isnan(v)]
    if valid_vals:
        y_min, y_max = min(valid_vals), max(valid_vals)
        y_range = y_max - y_min
        y_min -= y_range * 0.1
        y_max += y_range * 0.1
        ax.set_ylim(y_min, y_max)
    
    # 绘制原始数据
    for i in range(len(nodes)):
        # 绘制起点标记
        if not np.isnan(original_start_vals[i]):
            ax.plot(i, original_start_vals[i], 'o', color='gray', markersize=8, label='原始起点' if i == 0 else "")
        
        # 绘制终点标记
        if not np.isnan(original_end_vals[i]):
            ax.plot(i+1, original_end_vals[i], 's', color='gray', markersize=8, label='原始终点' if i == 0 else "")
        
        # 绘制管线
        if i < len(nodes) - 1 and not np.isnan(original_start_vals[i]) and not np.isnan(original_end_vals[i]):
            ax.plot([i, i+1], [original_start_vals[i], original_end_vals[i]], 'gray', linestyle='-', linewidth=2, label='原始数据' if i == 0 else "")
        
        # 绘制同一节点的起点和终点高程（用虚线连接）
        if i > 0 and not np.isnan(original_end_vals[i-1]) and not np.isnan(original_start_vals[i]):
            ax.plot([i, i], [original_end_vals[i-1], original_start_vals[i]], 'gray', linestyle='--', linewidth=1)
    
    # 绘制施工数据
    for i in range(len(nodes)):
        # 绘制起点标记
        if not np.isnan(construction_start_vals[i]):
            ax.plot(i, construction_start_vals[i], 'o', color='blue', markersize=8, label='施工起点' if i == 0 else "")
        
        # 绘制终点标记
        if not np.isnan(construction_end_vals[i]):
            ax.plot(i+1, construction_end_vals[i], 's', color='blue', markersize=8, label='施工终点' if i == 0 else "")
        
        # 绘制管线
        if i < len(nodes) - 1 and not np.isnan(construction_start_vals[i]) and not np.isnan(construction_end_vals[i]):
            ax.plot([i, i+1], [construction_start_vals[i], construction_end_vals[i]], 'blue', linestyle='-', linewidth=2, label='施工数据' if i == 0 else "")
        
        # 绘制同一节点的起点和终点高程（用虚线连接）
        if i > 0 and not np.isnan(construction_end_vals[i-1]) and not np.isnan(construction_start_vals[i]):
            ax.plot([i, i], [construction_end_vals[i-1], construction_start_vals[i]], 'blue', linestyle='--', linewidth=1)
    
    # 绘制设计数据
    for i in range(len(nodes)):
        # 绘制起点标记
        if not np.isnan(design_start_vals[i]):
            ax.plot(i, design_start_vals[i], 'o', color='green', markersize=8, label='设计起点' if i == 0 else "")
        
        # 绘制终点标记
        if not np.isnan(design_end_vals[i]):
            ax.plot(i+1, design_end_vals[i], 's', color='green', markersize=8, label='设计终点' if i == 0 else "")
        
        # 绘制管线
        if i < len(nodes) - 1 and not np.isnan(design_start_vals[i]) and not np.isnan(design_end_vals[i]):
            ax.plot([i, i+1], [design_start_vals[i], design_end_vals[i]], 'green', linestyle='-', linewidth=2, label='设计数据' if i == 0 else "")
        
        # 绘制同一节点的起点和终点高程（用虚线连接）
        if i > 0 and not np.isnan(design_end_vals[i-1]) and not np.isnan(design_start_vals[i]):
            ax.plot([i, i], [design_end_vals[i-1], design_start_vals[i]], 'green', linestyle='--', linewidth=1)
    
    # 设置图表属性
    ax.set_xlabel('节点名称')
    ax.set_ylabel('高程 (m)')
    ax.set_title(title)
    ax.set_xticks(range(len(nodes)))
    ax.set_xticklabels(nodes, rotation=45, ha='right')
    
    # 添加图例（只添加一次）
    handles, labels = ax.get_legend_handles_labels()
    by_label = dict(zip(labels, handles))
    ax.legend(by_label.values(), by_label.keys(), loc='best')
    
    ax.grid(True, linestyle='--', alpha=0.7)
    
    # 保存图表
    plt.tight_layout()
    plt.savefig(output_path, dpi=300, bbox_inches='tight')
    plt.close()

# 功能封装
def comparison_plot(excel_file_path):
    """
    主功能函数：处理Excel文件并生成所有图表
    """
    # 检查文件是否存在
    if not os.path.exists(excel_file_path):
        print(f"文件不存在: {excel_file_path}")
        return
    
    # 解析数据
    datasets = parse_pipeline_data(excel_file_path)
    
    if not datasets:
        print("Excel文件中没有找到W表或Y表，或者两个表都为空")
        return
    
    # 创建输出文件夹
    base_name = os.path.splitext(os.path.basename(excel_file_path))[0]
    output_dir = os.path.join(os.path.dirname(excel_file_path), f"{base_name}_construction_plot")
    os.makedirs(output_dir, exist_ok=True)
    
    # 处理每个工作表
    for sheet_name, data in datasets.items():
        print(f"处理 {sheet_name} 表，共 {len(data)} 行数据")
        
        # 构建管道网络图
        G = build_pipeline_graph(data)
        print(f"构建的图有 {G.number_of_nodes()} 个节点和 {G.number_of_edges()} 条边")
        
        # 查找所有完整路径
        paths = find_complete_paths(G)
        
        if not paths:
            print(f"在{sheet_name}表中没有找到完整的管道路径")
            continue
        
        print(f"在{sheet_name}表中找到 {len(paths)} 条完整路径")
        
        # 为每条路径创建图表
        for i, path in enumerate(paths):
            if len(path) < 2:
                continue
                
            title = f"{path[0]}—{path[-1]}"
            filename = f"{title}.png"
            output_path = os.path.join(output_dir, filename)
            
            print(f"正在生成图表 {i+1}/{len(paths)}: {title}")
            plot_pipeline_path(G, path, output_path, title)
    
    print(f"所有图表已保存到: {output_dir}")

if __name__ == "__main__":
    excel_file_path = input("请输入Excel文件路径: ").strip()
    comparison_plot(excel_file_path)