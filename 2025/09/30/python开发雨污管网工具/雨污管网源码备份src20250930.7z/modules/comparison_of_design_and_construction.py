#成果表匹配设计表 v1
import os
from openpyxl import Workbook, load_workbook
from openpyxl.utils import get_column_letter
import re

# 输入两组xy，返回距离
def xy_to_dis(x1, y1, x2, y2):
    return ((float(x2) - float(x1)) ** 2 + (float(y2) - float(y1)) ** 2) ** 0.5

# 字符串清理空格
def strc(s):
    if not isinstance(s, str) or not s:
        return s
    return s.replace(" ","")

# 字符串比较不区分大小写
def strcompare_lower(a,b):
    if strc(a).lower() ==strc(b).lower():
        return 1
    else:
        return 0
    
def remove_first_hyphen_before_digits(sheet):
    """
    处理表格中的ID字段：移除第一次出现数字之前的第一个横杠
    
    参数:
    sheet: openpyxl Worksheet对象
    
    返回:
    处理后的Worksheet对象
    """
    # 定义检测和处理的函数
    def process_id(id_str):
        """
        处理单个ID字符串：只移除第一个数字前的第一个横杠
        """
        if not isinstance(id_str, str) or not id_str:
            return id_str
        
        # 查找第一个数字的位置
        match = re.search(r'\d', id_str)
        if not match:
            return id_str  # 没有数字，直接返回
        
        first_digit_pos = match.start()
        
        # 在数字前部分查找第一个横杠的位置
        prefix = id_str[:first_digit_pos]
        hyphen_pos = prefix.find('-')
        
        # 如果找到横杠，只移除第一个横杠
        if hyphen_pos != -1:
            # 构建新字符串：横杠前部分 + 横杠后部分 + 数字及之后部分
            new_prefix = prefix[:hyphen_pos] + prefix[hyphen_pos+1:]
            return new_prefix + id_str[first_digit_pos:]
        
        return id_str
    
    # 处理B列（第二列）的所有单元格
    for row in range(2, sheet.max_row + 1):  # 从第二行开始
        cell = sheet.cell(row=row, column=2)  # 第二列是B列
        
        # 处理当前单元格的ID
        original_id = cell.value
        processed_id = process_id(original_id)
        
        # 如果ID有变化，更新单元格值
        if original_id != processed_id:
            cell.value = processed_id
            print(f"行 {row}: '{original_id}' -> '{processed_id}'")
    
    return sheet

def biaogaobuquan(sheet):
    if sheet[f"E{2}"].value is None:
        for i in range(2,sheet.max_row+1):
            biaogao=float(sheet[f"F{i}"].value)+float(sheet[f"G{i}"].value)
            sheet[f"E{i}"].value=str(round(biaogao,3))
    return sheet

# 成果表初始化
def init_cgb(cgb):
    # 在这里进行成果表的初始化操作
    # 标题初始化
    cgb[f"AP{5}"].value = "设计名称"
    cgb[f"AQ{5}"].value = "流向井"
    cgb[f"AR{5}"].value = "设计x"
    cgb[f"AS{5}"].value = "设计y"
    cgb[f"AT{5}"].value = "设计井面"
    cgb[f"AU{5}"].value = "设计管底"
    cgb[f"AV{5}"].value = "设计埋深"
    cgb[f"AW{5}"].value = "流向管底"
    cgb[f"AX{5}"].value = "节点类型"
    cgb[f"AY{5}"].value = "平面差"
    cgb[f"AZ{5}"].value = "地面标高差"
    cgb[f"BA{5}"].value = "管底标高差"
    cgb[f"BB{5}"].value = "埋深差"
    cgb[f"BC{5}"].value = "井面修正"
    cgb[f"BD{5}"].value = "管底修正"
    cgb[f"BE{5}"].value = "埋深修正"

    return cgb

# 成果表匹配设计数据，并计算误差
def original_data_compart(cgb,sjb):
    # 成果表初始化
    cgb = init_cgb(cgb)
    # 设计表初始化（去横线）
    sjb = remove_first_hyphen_before_digits(sjb)
    sjb = biaogaobuquan(sjb)

    print("已读取总行数: " + str(cgb.max_row-5))
    # 循环成果表
    for i in range(6,cgb.max_row+1):
        start_name = cgb[f"B{i}"].value
        end_name = cgb[f"C{i}"].value
        # 循环设计表，查找匹配项
        for j in range(2,sjb.max_row+1):
            sjb_name = strc(sjb[f"B{j}"].value)
            # 匹配起始井，并且不是空值。
            if cgb[f"B{i}"].value is not None and strcompare_lower(start_name,sjb_name) :
                # 获取设计表数据
                sjb_x = strc(sjb[f"D{j}"].value)
                sjb_y = strc(sjb[f"C{j}"].value)
                sjb_jmbg = strc(sjb[f"E{j}"].value)
                sjb_gdbg = strc(sjb[f"F{j}"].value)
                sjb_ms = strc(sjb[f"G{j}"].value)
                sjb_jdlx = strc(sjb[f"H{j}"].value)
                xy_d = round(xy_to_dis(cgb[f"F{i}"].value,cgb[f"G{i}"].value,sjb_x,sjb_y),3)
                jmbg_d = round(float(cgb[f"H{i}"].value) - float(sjb_jmbg),3)
                # 因为终点井没有管底和埋深，井底就是管底
                if cgb[f"J{i}"].value is None:
                    gdbg_d = round(float(cgb[f"I{i}"].value) - float(sjb_gdbg),3) # 成果-设计
                    ms_d = round(float(cgb[f"H{i}"].value) - float(cgb[f"I{i}"].value) - float(sjb_ms),3) #成果-设计
                else:
                    gdbg_d = round(float(cgb[f"J{i}"].value) - float(sjb_gdbg),3)
                    ms_d = round(float(cgb[f"K{i}"].value) - float(sjb_ms),3)
                cgb[f"AP{i}"].value = sjb_name
                cgb[f"AR{i}"].value = sjb_x
                cgb[f"AS{i}"].value = sjb_y
                cgb[f"AT{i}"].value = sjb_jmbg
                cgb[f"AU{i}"].value = sjb_gdbg
                cgb[f"AV{i}"].value = sjb_ms
                cgb[f"AX{i}"].value = sjb_jdlx
                # 误差写入
                cgb[f"AY{i}"].value = xy_d
                cgb[f"AZ{i}"].value = jmbg_d
                cgb[f"BA{i}"].value = gdbg_d
                cgb[f"BB{i}"].value = ms_d
            # 匹配流向井
            if cgb[f"C{i}"].value is not None and strcompare_lower(end_name,sjb_name):
                sjb_lxgdbg = sjb[f"F{j}"].value
                cgb[f"AQ{i}"].value = sjb_name
                cgb[f"AW{i}"].value = sjb_lxgdbg
    return cgb

# 功能封装
def comparison_of_design_and_construction(file_path_cgb,file_path_sjb):
    if file_path_cgb.endswith('.xlsx'):
        output_file = file_path_cgb.replace('.xlsx', '_设计对比.xlsx')
    else:
        output_file = file_path_cgb + '_设计对比.xlsx'

    # 读取Excel文件
    cgb = load_workbook(file_path_cgb)
    sjb = load_workbook(file_path_sjb)

    if "W" in cgb :
        print('__Loading W sheet__')
        cgb_w = cgb["W"] # 按名称获取
        if "W" in sjb :
            sjb_w = sjb["W"] # 按名称获取
            #数据处理
            cgb_w=original_data_compart(cgb_w,sjb_w)
        else:
            print("设计数据未找到W表")
    else:
        print("成果数据未找到W表")

    if "Y" in cgb :
        print('__Loading Y sheet__')
        cgb_y = cgb["Y"] # 按名称获取
        if "Y" in sjb :
            sjb_y = sjb["Y"] # 按名称获取
            #数据处理
            cgb_y=original_data_compart(cgb_y,sjb_y)
        else:
            print("设计数据未找到Y表")
    else:
        print("成果数据未找到Y表")

    # 保存结果
    cgb.save(output_file)
    print("———————————分割线———————————")
    print(f"处理完成！结果已保存到: {output_file}")

# 主函数
def main():

    # 获取输入文件路径
    file_path_cgb = input("请输入成果表Excel文件路径: ").strip()
    if not os.path.exists(file_path_cgb):
        print("成果表文件不存在，请检查路径")
        return
    file_path_sjb = input("请输入设计表Excel文件路径: ").strip()
    if not os.path.exists(file_path_sjb):
        print("设计表文件不存在，请检查路径")
        return
    # max_error = float(input("请输入误差阈值: ").strip())
    comparison_of_design_and_construction(file_path_cgb,file_path_sjb)

if __name__ == "__main__":
    main()