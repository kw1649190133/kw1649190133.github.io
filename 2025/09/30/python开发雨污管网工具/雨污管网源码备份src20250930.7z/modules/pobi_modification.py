# 坡度比计算和超限检查
# -*- coding: utf-8 -*-
# 20250704
# 1.计算坡比，标记逆流的管道和坡比不足的管道。
# 2.计算管底深度不足的部分，修改原始数据，进行迭代计算直到没有错误。

# 20250705
# 1.完善其他数据的联动修改，当深度变化<2cm时，修改井面标高。当深度变化>2cm时，修改埋深，检查井深是否>=管深，同步修改井深。
# 2.优化数据输入输出，从文件夹批量导入成果表，批量输出成果。【代办】
# 3.修复了重大逻辑错误，更新流向井标高，避免刻舟求剑。

# 20250707
# 1.保留原始数据、添加对比数据
# 2.添加对成果表进行格式化处理，清除空行，清除重复项。
# 3.优化了调整算法，确保井面不要被改过头。
# 4.修改了错误的逻辑，流向井的管底并不能当做终点井管底使用，终点井的井深才是真正的管底。

# 20250708
# 重构坡比修改算法，修复逻辑错误
# 只修改前井

# 20250709
# 流向管底这一项可能是空的，添加了自动填充机制，当它是空的就直接拿流向高程当管底。
# 加入白名单，不修改白名单中的记录。【但是用不上】

# 20250710
# 修改核心逻辑，修正逻辑错误。
# 目前基于贪心算法的坡比调整，在遇到及个别的异常数据时就会导致一连串的过度调整，
# 要想在全局层面控制一个变化量，就需要引入新的数学模型，将调整结果与原数据进行拟合，计算偏差量。

# 20250711
# 又加回了调后井原则，当管底修改超过0.5米时就调整后井。
# 目前基于前井的剩余可调整值来判断是否需要调整后井，当前井余量较多时就优先调整前井。

# 20250810
# 修复管径识别错误导致程序崩溃的问题，当管径无法识别时默认0.0015坡比

import openpyxl
import re
import os
from openpyxl.styles import Font, Alignment, Border, Side
from openpyxl.utils import get_column_letter

# 检查测量成果是否重复
def dataisonly(unique_id, y_str, x_str, data_array):
    for item in data_array:
        if ((item[0]) == unique_id and (item[1]) == y_str and (item[2]) == x_str ):
            return 0
    # 如果未发现重复，则返回1
    return 1

def clean_and_renumber_sheet(sheet):
    """
    处理工作表：
    1. 检查B列ID是否空白
    2. 检查B、F、G三列是否同时重复
    3. 删除问题行
    4. 重新排列第一列序号
    :param sheet: openpyxl的Worksheet对象
    :return: 处理后的Worksheet对象
    """
    # 获取最大行数
    max_row = sheet.max_row
    
    # 用于记录已出现的B-F-G组合和需要删除的行
    seen_combinations = set()
    rows_to_delete = []
    
    # 检查数据行（假设第1行是标题）
    for row in range(6, max_row + 1):
        b_value = sheet[f'B{row}'].value
        f_value = sheet[f'F{row}'].value
        g_value = sheet[f'G{row}'].value
        
        # 检查B列是否空白
        if b_value is None or str(b_value).strip() == "":
            rows_to_delete.append(row)
            continue
        
        # 检查B-F-G组合是否重复
        combination = (b_value, f_value, g_value)
        if combination in seen_combinations:
            rows_to_delete.append(row)
        else:
            seen_combinations.add(combination)
    
    # 从下往上删除行（避免行号变化问题）
    for row in sorted(rows_to_delete, reverse=True):
        sheet.delete_rows(row)
    
    # 重新排列序号列（A列）
    for row in range(6, sheet.max_row + 1):
        sheet[f'A{row}'] = row - 5  # 新序号从1开始
    print("发现并删除空白和重复条目： " + str(len(rows_to_delete)))
    return sheet

# 坡比计算
# 输入：管底标高、流向井管底、距离
def slope_ratio(gd,lxgd,d):

    depth_d = float(gd)-float(lxgd)  # 计算深度差
    pobi = depth_d / float(d)  # 计算坡度比
    return pobi
def cankaopobi_get(guanjing):
    try:
        # 尝试将输入转换为浮点数
        guanjing_f = float(guanjing)
        
        # 根据数值大小返回不同结果
        return 0.001 if guanjing_f >= 400 else 0.0015
    
    except (ValueError, TypeError):
        # 处理无法转换的情况：
        # 1. 非数字字符串（如 "abc"）
        # 2. 空值（None）
        # 3. 其他无法转换为数字的类型
        return 0.0015

# 计算流向高程
def sheet_lxgc_get(sheet):
    # 循环流向井列表C，当不为空时去找流向
    for i in range(6,sheet.max_row+1):
        lxj = sheet[f"C{i}"].value
        if lxj is not None:
            # 循环井列表B
            for j in range(6,sheet.max_row+1):
                jing = sheet[f"B{j}"].value # B列表井名称
                # 名称匹配上
                if lxj == jing:
                    # 考虑有的表格没有流向管底这一项，那就直接把流向高程作为流向管底。
                    if sheet[f"O{i}"].value is None:
                        sheet[f"Y{i}"].value = sheet[f"J{j}"].value
                        sheet[f"O{i}"].value = sheet[f"Y{i}"].value
                        greed_mark(sheet[f"O{i}"])
                    
                    else:
                        # 当井J是终点井的时候，将井底作为I井的流向高，否则正常将管底当做流向高程
                        if sheet[f"J{j}"].value is None :
                            sheet[f"Y{i}"].value = sheet[f"I{j}"].value
                        else : 
                            sheet[f"Y{i}"].value = sheet[f"J{j}"].value
                        # 当流向井不是终点井的时候，并且流向高程【低于】流向管底，那就更新流向井。
                        # 流向管底是可以高于对于井的管底的。所以当流向高程高于流向管底时，才进行更新。
                        if sheet[f"C{j}"].value is not None and float(sheet[f"Y{i}"].value) > float(sheet[f"O{i}"].value):
                            sheet[f"O{i}"].value = sheet[f"Y{i}"].value
                            greed_mark(sheet[f"O{i}"])
                    
    return sheet

# 从流向高程更新管底。输入表格，流向井名称，更新值，返回表格。
def sheet_lxgc_to_gd(sheet,lxjname,lxgc):
    key = 0
    print(lxjname + "__" + str(lxgc))
    for i in range(6,sheet.max_row+1):
        jing = sheet[f"B{i}"].value # B列表名称
        # 名称匹配
        if jing == lxjname:
            key = 1
            # 当被流向的井是终点井或孤立井，并且流向高程低于井深，则开挖井深      
            if sheet[f"C{i}"].value is None and float(lxgc) < float(sheet[f"I{i}"].value):
                sheet[f"I{i}"].value = lxgc
                greed_mark( sheet[f"I{i}"])
                print("【警告】井底已更新")
        # 当流向不是终点井，并且管底不同时
            if sheet[f"C{i}"].value is not None and float(lxgc) < float(sheet[f"J{i}"].value):
                sheet[f"J{i}"].value = lxgc # 否则更新管底
                greed_mark( sheet[f"J{i}"])
                print("管底已更新")
            # 更新井底
            if sheet[f"C{i}"].value is not None and float(sheet[f"J{i}"].value)<float(sheet[f"I{i}"].value):
                sheet[f"I{i}"].value = sheet[f"J{i}"].value
                red_mark( sheet[f"I{i}"])
                print("【警告】井底已更新")
            #else:
                #print (f"【警告，未找到{jing}流向井的井底标高】"
    if key == 1 :
        print ("已更新管底标高")
    else :
        print ("什么也没做")
    return sheet

def sheet_gd_to_lxgc(sheet,jingname,gd):
    key = 0
    #print(jingname + "__" + str(gd))
    for i in range(6,sheet.max_row+1):
        lxjname = sheet[f"C{i}"].value # B列表名称
        if lxjname is not None:
            # 名称匹配
            if jingname == lxjname :
                key = 1
                sheet[f"Y{i}"].value = gd
    """            
    if key == 1 :
        print ("已更新流向高程")
    else :
        print ("流向高程不更新")
    """
    return sheet

# 最后检查一次流向管底高度
def sheet_lxgd_chake(sheet,baimingdan):
    for i in range(6,sheet.max_row+1):
        if (in_baimingdan(sheet[f'B{i}'].value,sheet[f'C{i}'].value,baimingdan)):
            continue
        if sheet[f"O{i}"].value is not None:
            gd = float(sheet[f'J{i}'].value) # 管底标高
            lxgd = float(sheet[f'O{i}'].value) # 流向井管底标高
            glength = float(sheet[f'Q{i}'].value) # 管长
            lxgc = float(sheet[f'Y{i}'].value) # 流向高程
            pobi = slope_ratio(gd, lxgd, glength) # 计算坡比(用流向高程算)
            cankaopobi = float(sheet[f'U{i}'].value) # 通过管径确定坡比最小值
            height_diff = round((gd-lxgd)-(glength*cankaopobi),3) # 计算高度值差(用流向高程算)
            if pobi < cankaopobi:
                # 当流向管底和流向高程很接近的时候，直接让它等于流向高程，否则就计算一下新的管底
                if lxgd-lxgc<0.01:
                    sheet[f"O{i}"].value = lxgc
                    greed_mark(sheet[f"O{i}"])
                else:
                    new_lxgd = lxgd + height_diff
                    sheet[f"O{i}"].value = new_lxgd
                    yellow_mark(sheet[f"O{i}"])
    return sheet

# 流向井埋深，出结果时算一次。
def sheet_lxjmaishen_get(sheet):
    sheet[f'X{5}'].value = "流向井埋深"
    for i in range(6,sheet.max_row+1):
        lxjing = sheet[f"C{i}"].value # C列表名称
        if lxjing is not None: # 跳过空值
            for j in range(6,sheet.max_row+1):
                jing = sheet[f"B{j}"].value # B列表井名称
                # 排除掉重点井和流向终点井的埋深
                if lxjing == jing:
                    maishen_end = float(sheet[f"H{j}"].value) - float(sheet[f"O{i}"].value)
                    sheet[f"X{i}"].value = maishen_end
                    break
                #else:
                    #print (f"【警告，未找到{jing}流向井的井底标高】"
    #print ("已计算流向井埋深")
    return sheet

# 表格美化
def format_sheet(sheet):
    """
    统一格式化工作表：
    1. 字体：Calibri 10
    2. 对齐：上下左右居中
    3. 边框：A-P列，从第1行到最后一行添加线框
    
    参数:
    sheet: openpyxl的Worksheet对象
    
    返回:
    格式化后的Worksheet对象
    """
    # 定义字体样式
    font = Font(name='Calibri', size=10)
    # 定义对齐样式
    alignment = Alignment(horizontal='center', vertical='center')  
    # 定义边框样式（细线）
    thin_border = Border(
        left=Side(style='thin'),
        right=Side(style='thin'),
        top=Side(style='thin'),
        bottom=Side(style='thin')
    )
    # 获取工作表的最大行数
    max_row = sheet.max_row   
    # 遍历A-P列，从第1行到最后一行
    for row in sheet.iter_rows(min_row=1, max_row=max_row, 
                              min_col=20, max_col=22):  # A=1, P=16
        for cell in row:
            # 应用字体
            cell.font = font  
            # 应用对齐
            cell.alignment = alignment        
            # 应用边框
            cell.border = thin_border
    # 遍历R-S列，从第1行到最后一行
    for row in sheet.iter_rows(min_row=2, max_row=max_row, 
                              min_col=18, max_col=19):  # A=1, P=16
        for cell in row:
            # 应用字体
            cell.font = font
            # 应用对齐
            cell.alignment = alignment
            # 应用边框
            cell.border = thin_border    
    return sheet    

# 警告标记
def woring_mark(sheet_m):
    red_fill = openpyxl.styles.PatternFill(start_color="FF0000", end_color="FF0000", fill_type="solid")
    yellow_fill = openpyxl.styles.PatternFill(start_color="FFFF00", end_color="FFFF00", fill_type="solid")
    for j in range(6,sheet_m.max_row+1):
        if  sheet_m[f'T{j}'].value is not None:
            pobi=float(sheet_m[f'T{j}'].value)
            if pobi < 0 :
                sheet_m[f'T{j}'].fill = red_fill  # 红色
        if sheet_m[f'V{j}'].value is not None:
            cankaopobi=float(sheet_m[f'V{j}'].value)
            if cankaopobi < 0 :
                sheet_m[f'V{j}'].fill = yellow_fill  # 黄色
    return sheet_m

# 错误检查机制，当发现表格中有坡比异常时就不通过
def have_error(sheet_m,baimingdan):
    error=0
    for j in range(6, sheet_m.max_row + 1):
        # 白名单机制
        if(in_baimingdan(sheet_m[f'B{j}'].value,sheet_m[f'C{j}'].value,baimingdan)):
            continue

        if sheet_m[f'T{j}'].value is not None:
            pobi = float(sheet_m[f'T{j}'].value)
            if pobi < 0:
                error += 1
        if sheet_m[f'W{j}'].value is not None:
            height_diff = float(sheet_m[f'W{j}'].value)
            if height_diff < 0:
                error += 1
    if error > 0:
        return True
    return False

# 对指定单元格修改填充色
def greed_mark(call):
    # 绿色样式
    green_fill = openpyxl.styles.PatternFill(start_color="00FF00",end_color="00FF00",fill_type="solid")
    call.fill = green_fill
    return call
def red_mark(call):
    # 红色样式
    green_fill = openpyxl.styles.PatternFill(start_color="FF0000", end_color="FF0000", fill_type="solid")
    call.fill = green_fill
    return call
def yellow_mark(call):
    #黄色样式
    yellow_fill = openpyxl.styles.PatternFill(start_color="FFFF00", end_color="FFFF00", fill_type="solid")
    call.fill = yellow_fill
    return call
def cyan_mark(call):
    #青色样式
    cyan_fill = openpyxl.styles.PatternFill(start_color="00FFFF", end_color="00FFFF", fill_type="solid")
    call.fill = cyan_fill
    return call


# 白名单判断
def in_baimingdan(well_a,well_b,baimingdan):
    for item in baimingdan:
        if (item['well1']==well_a and item['well2'] == well_b):
            return True
    return False
# 白名单获取
def extract_baimingdan_data(file_path):
    """
    从文本文件中提取井名称对和标高高差数据
    
    参数:
        file_path (str): 文本文件的路径
        
    返回:
        list: 包含井名称对和标高高差数据的列表，每个元素是一个字典，
             包含'well1', 'well2', 'elevation_diff'三个键
    """
    # 初始化
    data = [{"well1": "A1","well2":"B1","elevation_diff":1 }]
    try:
        with open(file_path, 'r') as file:
            for line in file:
                line = line.strip()
                if not line:  # 跳过空行
                    continue
                # 使用正则表达式提取数据
                pattern = r'([^-]+)--([^:]+):出现倒流并管底标高高差(-?\d+\.\d+)大于或等于'
                match = re.search(pattern, line)
                if match:
                    well1 = match.group(1)
                    well2 = match.group(2)
                    elevation_diff = float(match.group(3))
                    # 将提取的数据添加到结果列表中
                    data.append({
                        'well1': well1,
                        'well2': well2,
                        'elevation_diff': elevation_diff
                    })
                else:
                    print(f"警告: 无法从行 '{line}' 中提取数据")
        if data:
            print("白名单获取:")
            for item in data:
                print(f"{item['well1']}--{item['well2']}, 标高高差: {item['elevation_diff']}")
        else:
            print("未找到数据或提取过程出错")
        return data
    except FileNotFoundError:
        print(f"错误: 文件 '{file_path}' 未找到")
        return data
    except Exception as e:
        print(f"处理文件时出错: {str(e)}")
        return data
    
# 判断上一个井的高差冗余是否支持前井调整，支持则返回true。
def before_high_diff_check(sheet,jingname,high_d):
    for j in range(6,sheet.max_row+1):
        if jingname == sheet[f'C{j}'].value:
            if sheet[f'V{j}'].value is None:
                return False
            high_diff_before = round(sheet[f'V{j}'].value,3)
            if high_d + high_diff_before < 0:
                return False
    return True


# 坡度比计算和超限检查函数
def sheet_slope_check(sheet_m,baimingdan):
    sheet_m[f'T{5}'].value = "调整后坡比"
    sheet_m[f'U{5}'].value = "最低参考坡比"
    sheet_m[f'V{5}'].value = "调整后差值"
    sheet_m[f'W{5}'].value = "高度值差"
    sheet_m[f'Y{5}'].value = "流向高"

    sheet_m=sheet_lxgc_get(sheet_m) # 获取流向高程

# 循环一遍成果表，将非空数据添加到对比表
    print("已读取总行数: " + str(sheet_m.max_row))
    for j in range(6,sheet_m.max_row+1):
        #print("正在处理第 " + str(j) + " 行数据")
        # 白名单检测，当识别到白名单数据时跳过本次循环
        if sheet_m[f'C{j}'].value is not None:
            if (in_baimingdan(sheet_m[f'B{j}'].value,sheet_m[f'C{j}'].value,baimingdan)):
                print("发现白名单数据："+ sheet_m[f'B{j}'].value +" -- " + sheet_m[f'C{j}'].value)
                cyan_mark(sheet_m[f'B{j}'])
                cyan_mark(sheet_m[f'C{j}'])
                continue

        # 当流向高程不为0时才会进行数据处理
        if sheet_m[f'A{j}'].value is not None and sheet_m[f'Y{j}'].value is not None :          
            jingmian = float(sheet_m[f'H{j}'].value) # 井面标高
            jingdi = float(sheet_m[f'I{j}'].value) # 井底标高
            maishen = float(sheet_m[f'K{j}'].value) # 埋深
            gd = float(sheet_m[f'J{j}'].value) # 管底标高
            lxgd = float(sheet_m[f'O{j}'].value) # 流向井管底标高
            gdiammeter = float(sheet_m[f'L{j}'].value) # 管径
            glength = float(sheet_m[f'Q{j}'].value) # 管长
            lxgc = float(sheet_m[f'Y{j}'].value) # 流向高程
            pobi = slope_ratio(gd, lxgc, glength) # 计算坡比(用流向高程算)
            cankaopobi = cankaopobi_get(gdiammeter) # 通过管径确定坡比最小值
            # （管底-流向管底）-（长度乘以设计坡比得到设计高度差），
            height_diff = round((gd-lxgc)-(glength*cankaopobi),3) # 计算高度值差(用流向高程算)
            sheet_m[f'T{j}'].value = pobi
            sheet_m[f'U{j}'].value = cankaopobi # 最低坡比
            sheet_m[f'V{j}'].value = pobi - cankaopobi # 计算坡比差值
            sheet_m[f'W{j}'].value = height_diff # 计算高度值差

            # change
            #计算积累差
            jingmian_d_max = 0.05
            jingmian_d = abs(float(sheet_m[f'H{j}'].value) - float(sheet_m[f'AA{j}'].value)) #已经修改的高度
            gd_d = abs(float(sheet_m[f'J{j}'].value) - float(sheet_m[f'AC{j}'].value)) #已经修改的高度
            # 井面可以升高2cm以内，当超过2cm时，超过的部分修改埋深。最后检查井底是否高于管底。
            if  -0.1<height_diff < 0:
                
                # 如果高度值差小于0，说明管底标高不足，需要修改管底标高
                new_gd = round((gd - height_diff + 0.001),3) # 计算新的管底标高，四舍五入
                sheet_m[f'J{j}'].value = new_gd # 更新管底标高
                greed_mark(sheet_m[f'J{j}']) # 修改管底标高单元格颜色
                
                # 当需要修改的高度和已经修改的高度没有超限时（确保井面不要改过头）
                if (-jingmian_d_max <= height_diff < 0) and jingmian_d <= 0.001:  
                    new_jingmian = new_gd + maishen  # 计算新的井面标高，向下取整保留3位小数
                    sheet_m[f'H{j}'].value = new_jingmian # 更新井面标高
                    greed_mark(sheet_m[f'H{j}']) # 修改井面标高单元格颜色

                # 对半改的情况
                elif height_diff < -jingmian_d_max and jingmian_d <0.001:
                    new_jingmian = round(jingmian+jingmian_d_max,3)# 计算新的井面标高
                    new_maishen = round(new_jingmian-new_gd,3)
                    sheet_m[f'H{j}'].value = new_jingmian # 更新井面标高
                    sheet_m[f'K{j}'].value = new_maishen # 更新埋深
                    greed_mark(sheet_m[f'H{j}']) # 修改井面标高单元格颜色
                    greed_mark(sheet_m[f'K{j}']) # 修改埋深单元格颜色
                
                else :  # 如果高度值差小于-2cm，则修改井面标高
                    #new_jingmian = round(jingmian + 0.02,3)# 计算新的井面标高
                    new_maishen = round(jingmian-new_gd,3) # 计算新的埋深
                    #sheet_m[f'H{j}'].value = new_jingmian # 更新井面标高
                    sheet_m[f'K{j}'].value = new_maishen # 更新埋深
                    #greed_mark(sheet_m[f'H{j}']) # 修改井面标高单元格颜色
                    greed_mark(sheet_m[f'K{j}']) # 修改埋深单元格颜色

                """
                # 不改井面，只改埋深
                new_maishen = round(jingmian-new_gd,3) # 计算新的埋深
                sheet_m[f'K{j}'].value = new_maishen # 更新埋深
                greed_mark(sheet_m[f'K{j}'])
                """
                # print("已修改第 "+str(j)+" 行，编号：" + sheet_m[f'B{j}'].value)
                # 在修改完每一个数据之后都要更新流向井的管底
                # sheet_m = sheet_lxgd_gengxin(sheet_m) # 更新流向井数据
            
            # 当高度差值超过10CM，只修改埋深。
            elif -0.5< height_diff <= -0.1:
                #print(sheet_m[f'C{j}'].value + "高度差超过10CM，直接修改埋深")
                new_gd = gd - height_diff
                new_maishen = round(jingmian-new_gd,3) # 计算新的埋深
                
                sheet_m[f'J{j}'].value = new_gd # 管底更新
                sheet_m[f'K{j}'].value = new_maishen # 更新埋深
                greed_mark(sheet_m[f'J{j}'])
                greed_mark(sheet_m[f'K{j}'])
                sheet_m = sheet_gd_to_lxgc(sheet_m,sheet_m[f'B{j}'].value,sheet_m[f'J{j}'].value) # 将流向高程的新数值更到管底和井底。
            
            elif height_diff <= -0.5 and before_high_diff_check(sheet_m,sheet_m[f'B{j}'].value,height_diff):
                new_gd = gd - height_diff
                new_maishen = round(jingmian-new_gd,3) # 计算新的埋深
                sheet_m[f'J{j}'].value = new_gd # 管底更新
                sheet_m[f'K{j}'].value = new_maishen # 更新埋深
                greed_mark(sheet_m[f'J{j}'])
                greed_mark(sheet_m[f'K{j}'])
                sheet_m = sheet_gd_to_lxgc(sheet_m,sheet_m[f'B{j}'].value,sheet_m[f'J{j}'].value) # 将流向高程的新数值更到管底和井底。
                print("【！警告！】异常，调整值超过0.5m")

            elif height_diff <= -0.5 and before_high_diff_check(sheet_m,sheet_m[f'B{j}'].value,height_diff is False) :
                new_xlgc = lxgc + height_diff
                sheet_m[f'Y{j}'].value = new_xlgc
                sheet_m = sheet_lxgc_to_gd(sheet_m,sheet_m[f'C{j}'].value,new_xlgc)
                print("【！！！警告！！！！】严重异常，开挖后井")
            
        else:
            #print("第 " + str(j) + " 行数据为空，跳过")
            continue
    
    # sheet_m = sheet_lxgd_gengxin(sheet_m) # 更新流向井数据

    # sheet_m = woring_mark(sheet_m) #错误标记
    return sheet_m

def sheet_slope_change(sheet_m):

    #迭代前准备
    print("数据初始化")
    sheet_m = clean_and_renumber_sheet(sheet_m) #清除空白和重复数据
    # sheet_m = save_data0(sheet_m) #保留原始值
    
    baimingdan_path = None
    if baimingdan_path is None:
        baimingdan = []
    else :
        baimingdan = extract_baimingdan_data(baimingdan_path) #获取白名单

    round_count=0  # 循环次数
    # do-while 循环模拟
    while(True):
        # 检查坡比
        round_count += 1
        print(f"————第 {round_count} 次迭代————")
        sheet_slope_check(sheet_m,baimingdan)
        if have_error(sheet_m,baimingdan) is False:
            print("已完成坡比修改，退出循环")
            break
        
        
        # 检查是否超过最大迭代次数
        if round_count > 20:  # 假设最大迭代次数为20
            print("【警告！】超过20次迭代，退出循环")
            break
    sheet_m = sheet_lxgd_chake(sheet_m,baimingdan) # 检查流向管底
    sheet_m = sheet_lxjmaishen_get(sheet_m) #更新流向井埋深
    sheet_m = data_compare(sheet_m) #计算比较结果
    
    return sheet_m

# 保存原始数据的函数
def save_data0(sheet):
    sheet[f'AA{5}'].value = "原井面"
    sheet[f'AB{5}'].value = "原井底"
    sheet[f'AC{5}'].value = "原管底"
    sheet[f'AD{5}'].value = "原埋深"
    sheet[f'AE{5}'].value = "原流向管底"
    sheet[f'S{5}'].value = "原始坡比"

    sheet = sheet_lxgc_get(sheet) # 初始化流向高程

    for j in range(6,sheet.max_row+1):
        sheet[f'AA{j}'].value = sheet[f'H{j}'].value # 井面
        sheet[f'AB{j}'].value = sheet[f'I{j}'].value # 井底
        if sheet[f'A{j}'].value is not None and sheet[f'J{j}'].value is not None and sheet[f'O{j}'].value is not None:
            gd = float(sheet[f'J{j}'].value) # 管底标高
            lxgd = float(sheet[f'O{j}'].value) # 流向井管底标高
            lxgc = float(sheet[f'Y{j}'].value) # 流向井管底高程（流向高程）
            glength = float(sheet[f'Q{j}'].value) # 管长
            pobi = round(slope_ratio(gd, lxgd, glength), 4) # 计算坡比 (用流向高程算)
            pobi_lxgc = round(slope_ratio(gd, lxgc, glength), 4)  #计算坡比 (用流向管底算)
            
            sheet[f'AC{j}'].value = sheet[f'J{j}'].value
            sheet[f'AD{j}'].value = sheet[f'K{j}'].value
            sheet[f'AE{j}'].value = sheet[f'O{j}'].value
            sheet[f'S{j}'].value = pobi
            if(pobi<0):
                red_mark(sheet[f'S{j}'])
    return sheet
# 计算对比数据
def data_compare(sheet):
    sheet[f'AF{5}'].value = "井面变化"
    sheet[f'AG{5}'].value = "井底变化"
    sheet[f'AH{5}'].value = "管底变化"
    sheet[f'AI{5}'].value = "埋深变化"
    sheet[f'AJ{5}'].value = "后埋深变化"
    for j in range(6,sheet.max_row+1):
        jingmian_d = round(float(sheet[f'H{j}'].value) - float(sheet[f'AA{j}'].value),3)
        jingdi_d = round(float(sheet[f'I{j}'].value) - float(sheet[f'AB{j}'].value),3)
        sheet[f'AF{j}'].value = jingmian_d # 井面
        sheet[f'AG{j}'].value = jingdi_d
        
        if sheet[f'AC{j}'].value is not None:
            guandi_d = round(float(sheet[f'J{j}'].value) - float(sheet[f'AC{j}'].value),3)
            maishen_d = round(float(sheet[f'K{j}'].value) - float(sheet[f'AD{j}'].value),3)
            lxgd_d = round(float(sheet[f'O{j}'].value) - float(sheet[f'AE{j}'].value),3)
            sheet[f'AH{j}'].value = guandi_d
            sheet[f'AI{j}'].value = maishen_d 
            sheet[f'AJ{j}'].value = lxgd_d
            if abs(guandi_d)>=0.001:
                if abs(guandi_d)>=0.1:
                    yellow_mark(sheet[f'AH{j}'])
                else :greed_mark(sheet[f'AH{j}'])
            if abs(maishen_d)>=0.001:
                if abs(maishen_d)>=0.1:
                    yellow_mark(sheet[f'AI{j}'])
                else:greed_mark(sheet[f'AI{j}'])
            if abs(maishen_d)>=0.001:
                if abs(maishen_d)>=0.1:
                    yellow_mark(sheet[f'AJ{j}'])
                else:greed_mark(sheet[f'AJ{j}'])
        if abs(jingmian_d)>=0.001:
                greed_mark(sheet[f'AF{j}'])
        if abs(jingdi_d)>=0.001:
            red_mark(sheet[f'AG{j}'])

    return sheet

# 封装函数
def pobi_modification(input_path1,output_path = None,baimingdan_path = None):
    if not output_path:
        if input_path1.endswith('.xlsx'):
            output_path = input_path1.replace('.xlsx', '_result.xlsx')
        else:
            output_path = input_path1 + '_result.xlsx'
    # 读取文件
    workbook1 = openpyxl.load_workbook(input_path1)
    # 获取设计表的表名，检查W和Y是否存在
    sheet_names1 = workbook1.sheetnames

    if "W" in sheet_names1 :
        print('__Loading W sheet__')
        # 表格1是对比表,表2是测量成果
        sheet1w = workbook1["W"] # 按名称获取
        #数据处理
        sheet1w=sheet_slope_change(sheet1w)
    else:
        print("设计数据未找到W表")

    if "Y" in sheet_names1 :
        print('__Loading Y sheet__')
        sheet1y = workbook1["Y"] # 按名称获取
        #数据处理
        sheet1y=sheet_slope_change(sheet1y)
    else:
        print("设计数据未找到Y表")

    # 保存结果
    workbook1.save(output_path)
    print("———————————分割线———————————")
    print(f"处理完成！结果已保存到: {output_path}")

if __name__ == "__main__":
    
    #输入和输出（成果表）
    # 获取输入文件路径
    input_path1 = input("请输入成果表文件路径: ").strip()
    if not os.path.exists(input_path1):
        print("文件不存在，请检查路径")
    output_path = None

    # 获取白名单
    baimingdan_path = None

    if not output_path:
        if input_path1.endswith('.xlsx'):
            output_path = input_path1.replace('.xlsx', '_result.xlsx')
        else:
            output_path = input_path1 + '_result.xlsx'
        # 读取文件
        workbook1 = openpyxl.load_workbook(input_path1)

    # 获取设计表的表名，检查W和Y是否存在
    sheet_names1 = workbook1.sheetnames

    if "W" in sheet_names1 :
        print('__Loading W sheet__')
        # 表格1是对比表,表2是测量成果
        sheet1w = workbook1["W"] # 按名称获取
        #数据处理
        sheet1w=sheet_slope_change(sheet1w)
    else:
        print("设计数据未找到W表")

    if "Y" in sheet_names1 :
        print('__Loading Y sheet__')
        sheet1y = workbook1["Y"] # 按名称获取
        #数据处理
        sheet1y=sheet_slope_change(sheet1y)
    else:
        print("设计数据未找到Y表")

    # 保存结果
    workbook1.save(output_path)
    print("———————————分割线———————————")
    print(f"处理完成！结果已保存到: {output_path}")