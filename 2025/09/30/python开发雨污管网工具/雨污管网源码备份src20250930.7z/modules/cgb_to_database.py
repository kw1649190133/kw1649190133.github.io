# 20250705
# 实现成果表的批量转换，变成支持导入到数据库的格式

# 20250712
# 添加调用函数

# 20250927
# 补充了埋深计算函数，方便用户在不进行调坡比的时候直接转数据库格式。

import os
from openpyxl import load_workbook
from openpyxl import Workbook
def find_excel_files_with_keyword(folder_path, keyword):
    """
    查找文件夹中包含特定关键词的所有Excel文件路径
    :param folder_path: 要搜索的文件夹路径
    :param keyword: 要匹配的关键词(不区分大小写)
    :return: 包含匹配文件路径的列表
    """
    matched_files = []
    
    # 遍历文件夹中的所有文件
    for filename in os.listdir(folder_path):
        # 检查是否是Excel文件且包含关键词(不区分大小写)
        if filename.lower().endswith(('.xlsx', '.xlsm', '.xls')) and keyword.lower() in filename.lower():
            # 获取完整文件路径
            file_path = os.path.join(folder_path, filename)
            matched_files.append(file_path)
    # 打印结果
    print(f"找到 {len(matched_files)} 个包含'{keyword}'的Excel文件:")
    for file in matched_files:
        print(file)
    return matched_files

def add_sheet_to_workbook(source_sheet, target_wb, new_sheet_name=None):
    """
    将源工作表完整复制到目标工作簿
    :param source_sheet: 要添加的工作表对象
    :param target_wb: 目标工作簿对象
    :param new_sheet_name: 新工作表名称(可选)
    :return: 新创建的工作表对象
    """
    # 创建新工作表并命名
    new_sheet_name = new_sheet_name or source_sheet.title
    new_sheet = target_wb.create_sheet(new_sheet_name)
    
    # 复制所有单元格数据和样式
    for row in source_sheet.iter_rows():
        for cell in row:
            new_cell = new_sheet.cell(
                row=cell.row, 
                column=cell.column, 
                value=cell.value
            )
            if cell.has_style:
                new_cell.font = cell.font.copy()
                new_cell.border = cell.border.copy()
                new_cell.fill = cell.fill.copy()
                new_cell.number_format = cell.number_format
                new_cell.alignment = cell.alignment.copy()
    
    # 复制列宽
    for col_letter, dimension in source_sheet.column_dimensions.items():
        new_sheet.column_dimensions[col_letter].width = dimension.width
    
    # 复制行高
    for row_num, dimension in source_sheet.row_dimensions.items():
        new_sheet.row_dimensions[row_num].height = dimension.height
    
    return new_sheet

# 对列表中的excel文件进行处理并保存
# 输入文件列表、输出模板表。
def process_excel_files(file_list, output_template):
    # 
    try:
        # 加载输出模板工作簿
        workbook_template = load_workbook(output_template)
        sheet_template_W = workbook_template["W"]  # 获取模板的活动工作表W  
        sheet_template_Y = workbook_template["Y"]  # 获取模板的活动工作表Y
        for file in file_list:
            print(f"正在处理文件: {file}")

            # 打开Excel文件
            workbook = load_workbook(file)

            # 获取设计表的表名，检查W和Y是否存在
            sheet_names = workbook.sheetnames

            # 创建空白xy工作簿
            workbook_xy_out = Workbook()
            workbook_xy_out.remove(workbook_xy_out.worksheets[0])
            workbook_ms_out = Workbook()
            workbook_ms_out.remove(workbook_ms_out.worksheets[0])

            if "W" in sheet_names :
                print('__Loading W sheet__')
                sheet1w = workbook["W"] # 按名称获取
                #数据处理
                sheet1w_xy=make_xy_table(sheet1w)  # 调用转换函数
                sheet1w_ms=make_ms_table(sheet1w, sheet_template_W)  # 调用埋深表转换函数
                add_sheet_to_workbook(sheet1w_xy, workbook_xy_out, new_sheet_name="W")
                add_sheet_to_workbook(sheet1w_ms, workbook_ms_out, new_sheet_name="W")
            else:
                print("设计数据未找到W表")

            if "Y" in sheet_names :
                print('__Loading Y sheet__')
                sheet1y = workbook["Y"] # 按名称获取
                #数据处理
                sheet1y_xy=make_xy_table(sheet1y)  # 调用转换函数
                sheet1y_ms=make_ms_table(sheet1y, sheet_template_Y)  # 调用埋深表转换函数
                add_sheet_to_workbook(sheet1y_xy, workbook_xy_out, new_sheet_name="Y")
                add_sheet_to_workbook(sheet1y_ms, workbook_ms_out, new_sheet_name="Y")
            else:
                print("设计数据未找到Y表")

            # 保存处理后的工作表到新的Excel文件
            output_file_xy = file.replace('.xlsx', '_xy.xlsx')
            workbook_xy_out.save(output_file_xy)
            output_file_ms = file.replace('.xlsx', '_ms.xlsx')
            workbook_ms_out.save(output_file_ms)
            print(f"处理完成，已保存到: {output_file_xy} 和 {output_file_ms}")
    except Exception as e:
            print(f"处理失败: {str(e)}")
            return False

# 
def make_xy_table(sheet):
    wb_out = Workbook()  # 创建一个新的工作簿用于输出
    sheet_out = wb_out.active  # 获取活动工作表
    sheet_out.title = "W"  # 设置工作表标题
    raw=1 # 初始化行计数器  
    for i in range(6,sheet.max_row+1):

        sheet_out[f'A{raw}'].value = sheet[f'B{i}'].value  # 井编号
        sheet_out[f'C{raw}'].value = sheet[f'G{i}'].value   # 横坐标Y
        sheet_out[f'D{raw}'].value = sheet[f'F{i}'].value   # 纵坐标X
        sheet_out[f'E{raw}'].value = sheet[f'H{i}'].value   # 井面标高
        raw += 1
    # 在这里添加转换逻辑
    # 例如，读取sheet数据，修改格式，保存到output_template
    return sheet_out  # 返回处理后的工作表

# 返回埋深表
def make_ms_table(sheet, output_template):
    sheet_out = output_template  # 使用提供的模板工作表
    sheet=sheet_lxjmaishen_get(sheet) # 埋深计算函数
    """
    将指定的Excel工作表转换为埋深表格式
    :param sheet: 要处理的工作表
    :param output_template: 输出模板路径
    """
    sheetname = sheet.title
    raw=3 # 初始化行计数器
    for i in range(6,sheet.max_row+1):
        jingshen = round(float(sheet[f'H{i}'].value)-float(sheet[f'I{i}'].value),3)
        sheet_out[f'A{raw}'].value = sheetname  # 井编号
        sheet_out[f'B{raw}'].value = sheet[f'B{i}'].value # 井名称
        sheet_out[f'C{raw}'].value = sheet[f'C{i}'].value # 流向井名称
        sheet_out[f'D{raw}'].value = sheet[f'M{i}'].value # 管材质
        sheet_out[f'F{raw}'].value = sheet[f'L{i}'].value # 管径
        sheet_out[f'K{raw}'].value = sheet[f'N{i}'].value # 埋设方式
        sheet_out[f'L{raw}'].value = sheet[f'D{i}'].value # 点特征
        sheet_out[f'M{raw}'].value = sheet[f'E{i}'].value # 附属物
        sheet_out[f'N{raw}'].value = sheet[f'K{i}'].value # 起点埋深
        sheet_out[f'O{raw}'].value = sheet[f'X{i}'].value # 终点埋深
        sheet_out[f'U{raw}'].value = jingshen # 井深

        if sheet[f'AM{i}'].value  is not None and sheet[f'AN{i}'].value is not None:
            sheet_out[f'V{raw}'].value = sheet[f'AM{i}'].value # 井盖尺寸
            sheet_out[f'W{raw}'].value = sheet[f'AN{i}'].value # 井盖类型
        # 井盖尺寸、井盖材质在成果表中没有，不赋值。
        raw+=1
    # 在这里添加转换逻辑
    # 例如，读取sheet数据，修改格式，保存到output_template
    return sheet_out  # 返回处理后的工作表

# 流向井埋深，出结果时算一次。
def sheet_lxjmaishen_get(sheet):
    sheet[f'X{5}'].value = "流向井埋深"
    for i in range(6,sheet.max_row+1):
        lxjing = sheet[f"C{i}"].value # C列表名称
        if lxjing is not None: # 跳过空值
            for j in range(6,sheet.max_row+1):
                jing = sheet[f"B{j}"].value # B列表井名称
                # 排除掉重点井和流向终点井的埋深
                if lxjing == jing:
                    maishen_end = float(sheet[f"H{j}"].value) - float(sheet[f"O{i}"].value)
                    sheet[f"X{i}"].value = maishen_end
                    break
                #else:
                    #print (f"【警告，未找到{jing}流向井的井底标高】"
    #print ("已计算流向井埋深")
    return sheet

# 功能封装
def cgb_to_database(search_folder,output_template,search_keyword="成果表"):
    # 调用函数获取匹配文件列表
    found_files = find_excel_files_with_keyword(search_folder, search_keyword)
    # 处理找到的Excel文件
    if not found_files:
        print("没有找到包含关键词的Excel文件。")
    else:
        # 调用处理函数
        process_excel_files(found_files,output_template)

# 单独使用
if __name__ == "__main__":
    try:
        # 指定文件夹路径和关键词
        search_folder = input("输入成果表文件夹路径: ").strip()
        if not os.path.exists(search_folder):
            print("路径错误，请检查路径")
        search_keyword = "成果表"  # 要搜索的关键词
        # 坐标值空白模板路径
        output_template = input("输入管线表模板路径: ").strip()
        if not os.path.exists(output_template):
            print("路径错误，请检查路径")

        # 调用函数获取匹配文件列表
        found_files = find_excel_files_with_keyword(search_folder, search_keyword)
        
        # 处理找到的Excel文件
        if not found_files:
            print("没有找到包含关键词的Excel文件。")
        else:
            # 调用处理函数
            process_excel_files(found_files,output_template)
    except Exception as e:
        print(f"错误: {str(e)}")